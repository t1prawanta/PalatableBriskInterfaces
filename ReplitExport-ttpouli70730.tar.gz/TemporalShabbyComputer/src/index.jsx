import React, { useState, useEffect, useCallback } from 'react';

// --- ABIs & CONFIGURATION ---
// ABI สำหรับโทเค็นมาตรฐาน ERC-20
const ERC20_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function balanceOf(address) view returns (uint256)",
  "function transfer(address to, uint amount)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function decimals() view returns (uint8)"
];

// ABI สำหรับ Uniswap V2 Router
const ROUTER_ABI = [
    "function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)",
    "function swapTokensForExactTokens(uint amountOut, uint amountInMax, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)",
    "function getAmountsOut(uint amountIn, address[] calldata path) public view returns (uint[] memory amounts)"
];


// ที่อยู่ Smart Contract และข้อมูลเครือข่าย
const chains = {
  // ข้อมูลสำหรับ Bridge และ Balances
  mintme: { name: "MintMe", api: "https://api.mintme.com/wallet/balance", type: "api", symbol: "MINT", nativeAddress: "0x0000000000000000000000000000000000000000" },
  cronos: { name: "Cronos", rpc: "https://evm.cronos.org", contract: "0x6aB6d61428fde767387c5AEc82C092BDBCF1ab7A", abi: ERC20_ABI, symbol: "CRO", chainId: 25 },
  polygon: { name: "Polygon", rpc: "https://polygon-rpc.com", contract: "0x7D1AfA7B718a287236e768D37D5b8d2d4107bc05", abi: ERC20_ABI, symbol: "MATIC", chainId: 137 },
  // ข้อมูลสำหรับ DEX บนเครือข่าย MintMe
  mintmeDEX: {
    name: "MintMe DEX",
    router: "0xa6c72da53025c5291d326fadc5a1277aa21fef2c",
    weth: "0x067fa59cd5d5cd62be16c8d1df0d80e35a1d88dc",
    bone: "0x9D8dd79F2d4ba9E1C3820d7659A5F5D2FA1C22eF"
  }
};

// --- CONVERTER REGISTRY ABI & ADDRESS ---
const registryAbi = [{"constant":false,"inputs":[{"name":"token","type":"address"},{"name":"index","type":"uint32"}],"name":"unregisterConverter","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"tokens","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"acceptOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"token","type":"address"},{"name":"index","type":"uint32"}],"name":"converterAddress","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"converter","type":"address"}],"name":"tokenAddress","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"tokenCount","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"token","type":"address"}],"name":"converterCount","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"token","type":"address"},{"name":"converter","type":"address"}],"name":"registerConverter","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"newOwner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"token","type":"address"},{"indexed":false,"name":"address","type":"address"}],"name":"ConverterAddition","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"token","type":"address"},{"indexed":false,"name":"address","type":"address"}],"name":"ConverterRemoval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"prevOwner","type":"address"},{"indexed":true,"name":"_newOwner","type":"address"}],"name":"OwnerUpdate","type":"event"}];
const registryContractAddress = "0x89456efA718884f48b51f4790557B4981ffC0aa2";


// --- REACT COMPONENTS ---

// คอมโพเนนต์สำหรับตัวเลือกเครือข่าย
function ChainSelector({ selected, onChange, disabledChains = [] }) {
  return (
    <select 
      value={selected} 
      onChange={e => onChange(e.target.value)}
      className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
    >
      {Object.keys(chains).map(chainKey => (
        <option key={chainKey} value={chainKey} disabled={disabledChains.includes(chainKey)}>
          {chains[chainKey].name}
        </option>
      ))}
    </select>
  );
}

// คอมโพเนนต์สำหรับแสดงยอดคงเหลือของโทเค็น
function TokenBalance({ balances, isLoading }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-white">
      {Object.entries(balances).map(([chainKey, balance]) => (
        <div key={chainKey} className="p-4 bg-gray-800 rounded-xl shadow-lg transform hover:scale-105 transition-transform">
          <h3 className="text-lg font-bold text-indigo-400">{chains[chainKey].name}</h3>
          {isLoading ? (
            <div className="h-6 bg-gray-700 rounded-md animate-pulse mt-2"></div>
          ) : (
            <p className="text-2xl font-mono">
              {balance !== null && balance !== undefined ? parseFloat(balance).toFixed(4) : 'N/A'} <span className="text-sm text-gray-400">{chains[chainKey].symbol}</span>
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

// คอมโพเนนต์สำหรับลงทะเบียน Converter
function ConverterRegistry({ web3, userAccount, registryContract, showModal }) {
    const [tokenAddress, setTokenAddress] = useState('');
    const [converterAddress, setConverterAddress] = useState('');
    const [status, setStatus] = useState("สถานะ: รอการดำเนินการ");
    const [isRegistering, setIsRegistering] = useState(false);

    const registerConverter = async () => {
        if (!userAccount) {
            showModal("กรุณาเชื่อมต่อกระเป๋าเงินก่อนดำเนินการ", true);
            return;
        }
        if (!tokenAddress || !converterAddress) {
            setStatus("สถานะ: กรุณากรอกข้อมูลให้ครบถ้วน ❌");
            return;
        }
        
        setIsRegistering(true);
        try {
            setStatus("สถานะ: กำลังส่งธุรกรรม... ⏳");
            const result = await registryContract.methods.registerConverter(tokenAddress, converterAddress).send({ from: userAccount });
            console.log("Transaction result:", result);
            setStatus("สถานะ: ลงทะเบียนเรียบร้อย ✅");
            showModal("ลงทะเบียน Converter เรียบร้อยแล้ว!");
        } catch (err) {
            console.error("Error registering converter:", err);
            const errorMessage = err.message ? err.message.split('\n')[0] : 'เกิดข้อผิดพลาดในการทำธุรกรรม';
            setStatus(`สถานะ: ผิดพลาดในการลงทะเบียน ❌ - ${errorMessage}`);
            showModal(`เกิดข้อผิดพลาด: ${errorMessage}`, true);
        } finally {
            setIsRegistering(false);
        }
    };

    return (
        <div className="p-6 bg-gray-800 rounded-xl shadow-2xl">
            <h2 className="text-2xl font-semibold mb-6 text-white text-center">ลงทะเบียน Converter</h2>
            <p className="text-gray-400 mb-4">กรอกที่อยู่ Token และ Converter ที่คุณต้องการลงทะเบียน</p>
            <div className="space-y-4">
                <input
                    type="text"
                    id="tokenAddress"
                    placeholder="ที่อยู่ Token (e.g., 0x...)"
                    value={tokenAddress}
                    onChange={(e) => setTokenAddress(e.target.value)}
                    className="w-full p-3 rounded-lg border-2 border-gray-600 bg-gray-700 text-white focus:outline-none focus:border-blue-500 transition duration-300"
                />
                <input
                    type="text"
                    id="converterAddress"
                    placeholder="ที่อยู่ Converter (e.g., 0x...)"
                    value={converterAddress}
                    onChange={(e) => setConverterAddress(e.target.value)}
                    className="w-full p-3 rounded-lg border-2 border-gray-600 bg-gray-700 text-white focus:outline-none focus:border-blue-500 transition duration-300"
                />
                <button
                    onClick={registerConverter}
                    disabled={isRegistering || !userAccount}
                    className="w-full bg-green-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-green-700 transition duration-300 shadow-md disabled:bg-gray-500 disabled:cursor-not-allowed"
                >
                    {isRegistering ? 'กำลังลงทะเบียน...' : 'ลงทะเบียน'}
                </button>
                <p className={`text-center font-bold ${status.includes('❌') ? 'text-red-400' : status.includes('⏳') ? 'text-yellow-400' : 'text-green-400'}`}>
                    {status}
                </p>
            </div>
        </div>
    );
}

// --- NEW COMPONENT: DEX Swap ---
function DexSwap({ web3, userAccount, showModal }) {
    const [fromToken, setFromToken] = useState(chains.mintmeDEX.weth);
    const [toToken, setToToken] = useState(chains.mintmeDEX.bone);
    const [amount, setAmount] = useState('1');
    const [isSwapping, setIsSwapping] = useState(false);
    const [status, setStatus] = useState("สถานะ: กรอกจำนวนเพื่อแลกเปลี่ยน");

    const handleSwap = async () => {
        if (!userAccount || !web3) {
            showModal("กรุณาเชื่อมต่อ Wallet ก่อนดำเนินการ", true);
            return;
        }

        if (fromToken === toToken || parseFloat(amount) <= 0) {
            setStatus("สถานะ: กรุณาเลือกโทเค็นหรือกรอกจำนวนที่ถูกต้อง ❌");
            return;
        }

        setIsSwapping(true);
        setStatus("สถานะ: กำลังเตรียมธุรกรรม... ⏳");

        try {
            const routerContract = new web3.eth.Contract(ROUTER_ABI, chains.mintmeDEX.router);
            const tokenContract = new web3.eth.Contract(ERC20_ABI, fromToken);

            const decimals = await tokenContract.methods.decimals().call();
            const amountInWei = web3.utils.toWei(amount, 'ether'); // สมมติ 18 decimals

            // Step 1: Approve the Router to spend your tokens
            setStatus("สถานะ: กำลังร้องขอการอนุมัติ... ⏳");
            await tokenContract.methods.approve(chains.mintmeDEX.router, amountInWei).send({ from: userAccount });
            setStatus("สถานะ: อนุมัติสำเร็จ! กำลังสลับโทเค็น... ⏳");

            // Step 2: Perform the Swap
            const path = [fromToken, toToken];
            const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes from now

            await routerContract.methods.swapExactTokensForTokens(
                amountInWei,
                0, // amountOutMin, setting to 0 for simplicity
                path,
                userAccount,
                deadline
            ).send({ from: userAccount });

            setStatus("สถานะ: แลกเปลี่ยนสำเร็จ! ✅");
            showModal("การสลับโทเค็นสำเร็จแล้ว!");
        } catch (error) {
            console.error("DEX Swap failed:", error);
            const errorMessage = error.message ? error.message.split('\n')[0] : 'เกิดข้อผิดพลาดในการทำธุรกรรม';
            setStatus(`สถานะ: ผิดพลาดในการสลับ ❌ - ${errorMessage}`);
            showModal(`เกิดข้อผิดพลาด: ${errorMessage}`, true);
        } finally {
            setIsSwapping(false);
        }
    };

    return (
        <div className="p-6 bg-gray-800 rounded-xl shadow-2xl">
            <h2 className="text-2xl font-semibold mb-6 text-white text-center">DEX Swap บน MintMe</h2>
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">จาก</label>
                    <select
                        value={fromToken}
                        onChange={e => setFromToken(e.target.value)}
                        className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                    >
                        <option value={chains.mintmeDEX.weth}>WETH</option>
                        <option value={chains.mintmeDEX.bone}>$BONE</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">ไปยัง</label>
                    <select
                        value={toToken}
                        onChange={e => setToToken(e.target.value)}
                        className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                    >
                        <option value={chains.mintmeDEX.weth}>WETH</option>
                        <option value={chains.mintmeDEX.bone}>$BONE</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="amount" className="block text-sm font-medium text-gray-400 mb-2">จำนวน</label>
                    <input
                        id="amount"
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="0.0"
                        className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                </div>
                <button
                    onClick={handleSwap}
                    disabled={isSwapping || !userAccount}
                    className="w-full bg-green-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-green-700 transition duration-300 shadow-md disabled:bg-gray-500 disabled:cursor-not-allowed"
                >
                    {isSwapping ? 'กำลังสลับ...' : 'สลับโทเค็น'}
                </button>
                <p className={`text-center font-bold ${status.includes('❌') ? 'text-red-400' : status.includes('⏳') ? 'text-yellow-400' : 'text-green-400'}`}>
                    {status}
                </p>
            </div>
        </div>
    );
}

// --- MAIN APP COMPONENT ---
export default function App() {
  const [balances, setBalances] = useState({ mintme: null, cronos: null, polygon: null });
  const [fromChain, setFromChain] = useState("cronos");
  const [toChain, setToChain] = useState("polygon");
  const [amount, setAmount] = useState("10");
  const [isLoadingBalances, setIsLoadingBalances] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  
  const [web3, setWeb3] = useState(null);
  const [userAccount, setUserAccount] = useState(null);
  const [registryContract, setRegistryContract] = useState(null);
  const [message, setMessage] = useState("กรุณาเชื่อมต่อ Wallet ของคุณ");
  const [currentView, setCurrentView] = useState("bridge"); // 'bridge', 'registry', 'dex'

  const showModal = useCallback((msg, isError = false) => {
    setMessage(msg);
  }, []);

  const fetchMintMeBalance = async (address) => {
    try {
      const response = await fetch(`${chains.mintme.api}/${address}`);
      const data = await response.json();
      if (data && data.balance) {
        return data.balance;
      }
      return 'N/A';
    } catch (error) {
      console.error("Error fetching MintMe balance:", error);
      return 'Error';
    }
  };

  const fetchEvmBalance = async (chainKey, address) => {
    try {
      const currentChainId = await window.ethereum.request({ method: 'eth_chainId' });
      if (parseInt(currentChainId, 16) !== chains[chainKey].chainId) {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: web3.utils.toHex(chains[chainKey].chainId) }],
        });
      }

      const web3Provider = new window.Web3(window.ethereum);
      const contract = new web3Provider.eth.Contract(chains[chainKey].abi, chains[chainKey].contract);
      const balance = await contract.methods.balanceOf(address).call();
      
      return web3Provider.utils.fromWei(balance, 'ether');
    } catch (error) {
      console.error(`Error fetching ${chainKey} balance:`, error);
      return 'Error';
    }
  };

  const handleSyncBalances = useCallback(async () => {
    if (!userAccount) {
      setMessage("กรุณาเชื่อมต่อ Wallet เพื่อซิงค์ยอดคงเหลือ");
      return;
    }
    setIsLoadingBalances(true);
    setMessage("กำลังซิงค์ยอดคงเหลือทุกเชน...");
    try {
        const newBalances = {
          mintme: await fetchMintMeBalance(userAccount),
          cronos: await fetchEvmBalance('cronos', userAccount),
          polygon: await fetchEvmBalance('polygon', userAccount),
        };
        setBalances(newBalances);
        setMessage("ซิงค์ยอดคงเหลือสำเร็จ!");
    } catch (error) {
        console.error("Failed to sync balances:", error);
        setMessage("เกิดข้อผิดพลาดในการซิงค์ยอดคงเหลือ");
    }
    setIsLoadingBalances(false);
  }, [userAccount]);

  const handleSwap = async () => {
    if (!userAccount) {
      setMessage("กรุณาเชื่อมต่อ Wallet ก่อนทำการสลับ");
      return;
    }
    if (parseFloat(amount) <= 0 || !amount) {
      setMessage("กรุณาใส่จำนวนที่ถูกต้องเพื่อสลับ");
      return;
    }
    if (fromChain === toChain) {
      setMessage("เชนต้นทางและปลายทางต้องไม่ซ้ำกัน");
      return;
    }
    setIsSwapping(true);
    setMessage(`กำลังสลับ ${amount} ${chains[fromChain].symbol} จาก ${chains[fromChain].name} ไปยัง ${chains[toChain].name}...`);
    
    try {
        const fromChainInfo = chains[fromChain];
        const bridgeContractAddress = "0xYourBridgeContractAddressHere";

        if (fromChainInfo.type === 'api') {
            setMessage("การสลับจาก MintMe ไปยัง EVM ต้องทำผ่าน MintMe API หรือ DApp Bridge โดยเฉพาะ");
            await new Promise(resolve => setTimeout(resolve, 3000));
        } else {
            const provider = new window.Web3(window.ethereum);
            const tokenContract = new provider.eth.Contract(fromChainInfo.abi, fromChainInfo.contract);
            const amountInWei = provider.utils.toWei(amount, 'ether');

            setMessage("กำลังร้องขอการอนุมัติโทเค็น...");
            await tokenContract.methods.approve(bridgeContractAddress, amountInWei).send({ from: userAccount });
            setMessage("การอนุมัติสำเร็จ! กำลังส่งโทเค็นไปยัง Bridge...");
            
            // await bridgeContract.methods.swap(fromChain, toChain, amountInWei).send({ from: userAccount });
        }
        
        setMessage(`ธุรกรรมส่งไปที่เครือข่ายแล้ว! กรุณาตรวจสอบสถานะใน Wallet ของคุณ`);
    } catch (error) {
        console.error("Swap failed:", error);
        setMessage("เกิดข้อผิดพลาดระหว่างการสลับ");
    }
    
    setIsSwapping(false);
  };

  const connectWallet = async () => {
    if (typeof window.ethereum === 'undefined') {
      showModal("กรุณาติดตั้ง MetaMask เพื่อใช้งานแอปพลิเคชันนี้", true);
      return;
    }

    try {
      const _web3 = new window.Web3(window.ethereum);
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      const _userAccount = accounts[0];
      
      const _registryContract = new _web3.eth.Contract(registryAbi, registryContractAddress);
      
      setWeb3(_web3);
      setUserAccount(_userAccount);
      setRegistryContract(_registryContract);

      setMessage(`เชื่อมต่อสำเร็จ: ${_userAccount.substring(0, 6)}...${_userAccount.substring(_userAccou