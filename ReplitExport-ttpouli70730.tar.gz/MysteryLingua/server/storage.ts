import { 
  type Game, 
  type Player, 
  type Message, 
  type VocabularyWord, 
  type PlayerProgress,
  type InsertGame, 
  type InsertPlayer, 
  type InsertMessage,
  type InsertVocabularyWord,
  type InsertPlayerProgress,
  type MysteryScenario,
  type CharacterAbility
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Game methods
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: string): Promise<Game | undefined>;
  getActiveGames(): Promise<Game[]>;
  updateGame(id: string, updates: Partial<Game>): Promise<Game | undefined>;
  deleteGame(id: string): Promise<boolean>;

  // Player methods
  createPlayer(player: InsertPlayer): Promise<Player>;
  getPlayer(id: string): Promise<Player | undefined>;
  getGamePlayers(gameId: string): Promise<Player[]>;
  updatePlayer(id: string, updates: Partial<Player>): Promise<Player | undefined>;
  deletePlayer(id: string): Promise<boolean>;

  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getGameMessages(gameId: string): Promise<Message[]>;

  // Vocabulary methods
  getVocabularyWords(language?: string, difficulty?: string): Promise<VocabularyWord[]>;
  createVocabularyWord(word: InsertVocabularyWord): Promise<VocabularyWord>;

  // Player progress methods
  getPlayerProgress(playerId: string): Promise<PlayerProgress[]>;
  updatePlayerProgress(progress: InsertPlayerProgress): Promise<PlayerProgress>;
}

export class MemStorage implements IStorage {
  private games: Map<string, Game>;
  private players: Map<string, Player>;
  private messages: Map<string, Message>;
  private vocabularyWords: Map<string, VocabularyWord>;
  private playerProgress: Map<string, PlayerProgress>;

  constructor() {
    this.games = new Map();
    this.players = new Map();
    this.messages = new Map();
    this.vocabularyWords = new Map();
    this.playerProgress = new Map();
    this.initializeVocabulary();
  }

  private initializeVocabulary() {
    const words: VocabularyWord[] = [
      {
        id: randomUUID(),
        word: "suspect",
        language: "French",
        pronunciation: "/sus.pɛkt/",
        meaning: "suspicious person",
        difficulty: "intermediate",
        category: "crime"
      },
      {
        id: randomUUID(),
        word: "evidencia",
        language: "Spanish",
        pronunciation: "/e.βi.ˈðen.θja/",
        meaning: "evidence, proof",
        difficulty: "intermediate",
        category: "investigation"
      },
      {
        id: randomUUID(),
        word: "Dieb",
        language: "German",
        pronunciation: "/diːp/",
        meaning: "thief, burglar",
        difficulty: "beginner",
        category: "crime"
      }
    ];

    words.forEach(word => this.vocabularyWords.set(word.id, word));
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = randomUUID();
    const game: Game = {
      ...insertGame,
      id,
      createdAt: new Date(),
    };
    this.games.set(id, game);
    return game;
  }

  async getGame(id: string): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async getActiveGames(): Promise<Game[]> {
    return Array.from(this.games.values()).filter(game => game.status !== "completed");
  }

  async updateGame(id: string, updates: Partial<Game>): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (!game) return undefined;
    
    const updatedGame = { ...game, ...updates };
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  async deleteGame(id: string): Promise<boolean> {
    return this.games.delete(id);
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = randomUUID();
    const abilities = this.getCharacterAbilities(insertPlayer.characterType);
    const player: Player = {
      ...insertPlayer,
      id,
      abilities,
      joinedAt: new Date(),
    };
    this.players.set(id, player);
    return player;
  }

  private getCharacterAbilities(characterType: string): CharacterAbility[] {
    const abilities: Record<string, CharacterAbility[]> = {
      detective: [
        {
          id: "forensic-analysis",
          name: "Forensic Analysis",
          description: "Analyze physical evidence and crime scenes",
          cooldown: 0,
          ready: true
        },
        {
          id: "crime-scene-scan",
          name: "Crime Scene Scan",
          description: "Reveal hidden clues in the environment",
          cooldown: 2,
          ready: false
        }
      ],
      linguist: [
        {
          id: "universal-translate",
          name: "Universal Translate",
          description: "Translate clues and decode messages",
          cooldown: 0,
          ready: true
        },
        {
          id: "cipher-breaking",
          name: "Cipher Breaking",
          description: "Decode encrypted messages and symbols",
          cooldown: 1,
          ready: true
        }
      ],
      historian: [
        {
          id: "research-archive",
          name: "Research Archive",
          description: "Access historical context and information",
          cooldown: 0,
          ready: true
        },
        {
          id: "cultural-context",
          name: "Cultural Context",
          description: "Provide cultural and historical insights",
          cooldown: 1,
          ready: true
        }
      ]
    };
    return abilities[characterType] || [];
  }

  async getPlayer(id: string): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async getGamePlayers(gameId: string): Promise<Player[]> {
    return Array.from(this.players.values()).filter(player => player.gameId === gameId);
  }

  async updatePlayer(id: string, updates: Partial<Player>): Promise<Player | undefined> {
    const player = this.players.get(id);
    if (!player) return undefined;
    
    const updatedPlayer = { ...player, ...updates };
    this.players.set(id, updatedPlayer);
    return updatedPlayer;
  }

  async deletePlayer(id: string): Promise<boolean> {
    return this.players.delete(id);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getGameMessages(gameId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.gameId === gameId)
      .sort((a, b) => a.timestamp!.getTime() - b.timestamp!.getTime());
  }

  async getVocabularyWords(language?: string, difficulty?: string): Promise<VocabularyWord[]> {
    let words = Array.from(this.vocabularyWords.values());
    
    if (language) {
      words = words.filter(word => word.language === language);
    }
    
    if (difficulty) {
      words = words.filter(word => word.difficulty === difficulty);
    }
    
    return words;
  }

  async createVocabularyWord(insertWord: InsertVocabularyWord): Promise<VocabularyWord> {
    const id = randomUUID();
    const word: VocabularyWord = {
      ...insertWord,
      id,
    };
    this.vocabularyWords.set(id, word);
    return word;
  }

  async getPlayerProgress(playerId: string): Promise<PlayerProgress[]> {
    return Array.from(this.playerProgress.values()).filter(progress => progress.playerId === playerId);
  }

  async updatePlayerProgress(insertProgress: InsertPlayerProgress): Promise<PlayerProgress> {
    const existingProgress = Array.from(this.playerProgress.values())
      .find(p => p.playerId === insertProgress.playerId && p.wordId === insertProgress.wordId);
    
    if (existingProgress) {
      const updatedProgress = { ...existingProgress, ...insertProgress, lastPracticed: new Date() };
      this.playerProgress.set(existingProgress.id, updatedProgress);
      return updatedProgress;
    } else {
      const id = randomUUID();
      const progress: PlayerProgress = {
        ...insertProgress,
        id,
        lastPracticed: new Date(),
      };
      this.playerProgress.set(id, progress);
      return progress;
    }
  }
}

export const storage = new MemStorage();
