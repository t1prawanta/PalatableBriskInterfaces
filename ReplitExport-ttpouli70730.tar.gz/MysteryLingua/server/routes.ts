import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertGameSchema, 
  insertPlayerSchema, 
  insertMessageSchema,
  type MysteryScenario 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Game routes
  app.get("/api/games", async (req, res) => {
    try {
      const games = await storage.getActiveGames();
      res.json(games);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch games" });
    }
  });

  app.get("/api/games/:id", async (req, res) => {
    try {
      const game = await storage.getGame(req.params.id);
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch game" });
    }
  });

  app.post("/api/games", async (req, res) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      
      // Add default mystery scenario if not provided
      if (!gameData.mysteryScenario) {
        gameData.mysteryScenario = getDefaultMysteryScenario();
      }
      
      const game = await storage.createGame(gameData);
      res.status(201).json(game);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid game data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create game" });
      }
    }
  });

  app.patch("/api/games/:id", async (req, res) => {
    try {
      const updates = req.body;
      const game = await storage.updateGame(req.params.id, updates);
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Failed to update game" });
    }
  });

  // Player routes
  app.get("/api/games/:gameId/players", async (req, res) => {
    try {
      const players = await storage.getGamePlayers(req.params.gameId);
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch players" });
    }
  });

  app.post("/api/games/:gameId/players", async (req, res) => {
    try {
      const playerData = insertPlayerSchema.parse({ 
        ...req.body, 
        gameId: req.params.gameId 
      });
      const player = await storage.createPlayer(playerData);
      res.status(201).json(player);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid player data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create player" });
      }
    }
  });

  app.patch("/api/players/:id", async (req, res) => {
    try {
      const updates = req.body;
      const player = await storage.updatePlayer(req.params.id, updates);
      if (!player) {
        return res.status(404).json({ message: "Player not found" });
      }
      res.json(player);
    } catch (error) {
      res.status(500).json({ message: "Failed to update player" });
    }
  });

  // Message routes
  app.get("/api/games/:gameId/messages", async (req, res) => {
    try {
      const messages = await storage.getGameMessages(req.params.gameId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/games/:gameId/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse({
        ...req.body,
        gameId: req.params.gameId,
      });
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  // Vocabulary routes
  app.get("/api/vocabulary", async (req, res) => {
    try {
      const { language, difficulty } = req.query;
      const words = await storage.getVocabularyWords(
        language as string,
        difficulty as string
      );
      res.json(words);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vocabulary" });
    }
  });

  // Player progress routes
  app.get("/api/players/:playerId/progress", async (req, res) => {
    try {
      const progress = await storage.getPlayerProgress(req.params.playerId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch player progress" });
    }
  });

  app.post("/api/players/:playerId/progress", async (req, res) => {
    try {
      const progressData = {
        ...req.body,
        playerId: req.params.playerId,
      };
      const progress = await storage.updatePlayerProgress(progressData);
      res.status(201).json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to update player progress" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getDefaultMysteryScenario(): MysteryScenario {
  return {
    title: "The Museum Heist",
    description: "The priceless 'Codex Mysterium' has vanished from the museum's main gallery. Security footage shows suspicious activity around closing time. Work together to examine clues and solve vocabulary puzzles in multiple languages to crack the case!",
    sceneImage: "https://images.unsplash.com/photo-1554907984-15263bfd63bd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    sceneDescription: "An elegant museum gallery with classical paintings and ancient artifacts. The main display case stands empty where the Codex Mysterium once resided.",
    clues: [
      {
        id: "ancient-vase",
        type: "physical",
        title: "Fingerprints Found",
        description: "Partial prints on the display case",
        content: "Clear fingerprint evidence found on the glass display case. The prints appear fresh and don't match museum staff records.",
        position: { x: 20, y: 16 },
        vocabularyWords: ["fingerprint", "evidence", "display"],
        discovered: true
      },
      {
        id: "security-camera",
        type: "witness",
        title: "Witness Statement 🇫🇷",
        description: "J'ai vu un homme suspect...",
        content: "J'ai vu un homme suspect près du musée hier soir. Il portait un manteau noir et regardait souvent autour de lui.",
        language: "French",
        position: { x: 24, y: 28 },
        vocabularyWords: ["suspect", "homme", "noir"],
        discovered: true
      },
      {
        id: "guest-book",
        type: "document",
        title: "Guest Book Entry",
        description: "Suspicious signature in the guest book",
        content: "A mysterious entry signed only as 'M.S.' with an unusual symbol instead of a proper signature.",
        position: { x: 32, y: 20 },
        vocabularyWords: ["signature", "mysterious", "symbol"],
        discovered: false
      }
    ],
    solution: "The thief is Dr. Marcus Sterling, a former museum curator who knew the security system and had access to the building after hours."
  };
}
