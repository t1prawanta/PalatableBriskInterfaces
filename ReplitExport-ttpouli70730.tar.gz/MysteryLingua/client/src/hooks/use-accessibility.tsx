import { useState, useEffect, createContext, useContext } from "react";

interface AccessibilitySettings {
  fontSize: number;
  highContrast: boolean;
  ttsEnabled: boolean;
  keyboardNavigation: boolean;
}

interface AccessibilityContextType {
  settings: AccessibilitySettings;
  updateSetting: <K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => void;
  speak: (text: string) => void;
  announceStatus: (message: string) => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    const saved = localStorage.getItem("accessibility-settings");
    return saved ? JSON.parse(saved) : {
      fontSize: 16,
      highContrast: false,
      ttsEnabled: false,
      keyboardNavigation: false,
    };
  });

  const [statusElement, setStatusElement] = useState<HTMLElement | null>(null);

  useEffect(() => {
    // Create or find status element for screen reader announcements
    let element = document.getElementById("accessibility-status");
    if (!element) {
      element = document.createElement("div");
      element.id = "accessibility-status";
      element.setAttribute("aria-live", "polite");
      element.setAttribute("aria-atomic", "true");
      element.className = "sr-only";
      document.body.appendChild(element);
    }
    setStatusElement(element);

    // Apply font size
    document.documentElement.style.fontSize = `${settings.fontSize}px`;

    // Apply high contrast
    document.documentElement.classList.toggle("high-contrast", settings.highContrast);

    // Save settings
    localStorage.setItem("accessibility-settings", JSON.stringify(settings));

    // Keyboard navigation detection
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Tab") {
        setSettings(prev => ({ ...prev, keyboardNavigation: true }));
        document.body.classList.add("keyboard-navigation");
      }
    };

    const handleMouseDown = () => {
      setSettings(prev => ({ ...prev, keyboardNavigation: false }));
      document.body.classList.remove("keyboard-navigation");
    };

    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleMouseDown);

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleMouseDown);
    };
  }, [settings.fontSize, settings.highContrast]);

  const updateSetting = <K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const speak = (text: string) => {
    if (settings.ttsEnabled && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      speechSynthesis.speak(utterance);
    }
  };

  const announceStatus = (message: string) => {
    if (statusElement) {
      statusElement.textContent = message;
    }
  };

  return (
    <AccessibilityContext.Provider value={{
      settings,
      updateSetting,
      speak,
      announceStatus,
    }}>
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error("useAccessibility must be used within AccessibilityProvider");
  }
  return context;
}
