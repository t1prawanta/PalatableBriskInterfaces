import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Game, Player, Message, InsertGame, InsertPlayer, InsertMessage } from "@shared/schema";

export function useGameState(gameId: string) {
  const queryClient = useQueryClient();

  const gameQuery = useQuery<Game>({
    queryKey: ["/api/games", gameId],
    enabled: !!gameId,
  });

  const playersQuery = useQuery<Player[]>({
    queryKey: ["/api/games", gameId, "players"],
    enabled: !!gameId,
  });

  const messagesQuery = useQuery<Message[]>({
    queryKey: ["/api/games", gameId, "messages"],
    enabled: !!gameId,
    refetchInterval: 2000, // Poll for new messages
  });

  const createPlayerMutation = useMutation({
    mutationFn: async (playerData: Omit<InsertPlayer, "gameId">) => {
      const res = await apiRequest("POST", `/api/games/${gameId}/players`, playerData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games", gameId, "players"] });
    },
  });

  const updatePlayerMutation = useMutation({
    mutationFn: async ({ playerId, updates }: { playerId: string; updates: Partial<Player> }) => {
      const res = await apiRequest("PATCH", `/api/players/${playerId}`, updates);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games", gameId, "players"] });
    },
  });

  const updateGameMutation = useMutation({
    mutationFn: async (updates: Partial<Game>) => {
      const res = await apiRequest("PATCH", `/api/games/${gameId}`, updates);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games", gameId] });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: Omit<InsertMessage, "gameId">) => {
      const res = await apiRequest("POST", `/api/games/${gameId}/messages`, messageData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games", gameId, "messages"] });
    },
  });

  return {
    game: gameQuery.data,
    players: playersQuery.data || [],
    messages: messagesQuery.data || [],
    isLoading: gameQuery.isLoading || playersQuery.isLoading,
    createPlayer: createPlayerMutation.mutate,
    updatePlayer: updatePlayerMutation.mutate,
    updateGame: updateGameMutation.mutate,
    sendMessage: sendMessageMutation.mutate,
    isCreatingPlayer: createPlayerMutation.isPending,
    isSendingMessage: sendMessageMutation.isPending,
  };
}

export function useGames() {
  const queryClient = useQueryClient();

  const gamesQuery = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  const createGameMutation = useMutation({
    mutationFn: async (gameData: InsertGame) => {
      const res = await apiRequest("POST", "/api/games", gameData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games"] });
    },
  });

  return {
    games: gamesQuery.data || [],
    isLoading: gamesQuery.isLoading,
    createGame: createGameMutation.mutate,
    isCreatingGame: createGameMutation.isPending,
  };
}
