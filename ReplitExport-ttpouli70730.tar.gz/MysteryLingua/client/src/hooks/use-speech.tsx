import { useCallback } from "react";
import { useAccessibility } from "./use-accessibility";

export function useSpeech() {
  const { settings } = useAccessibility();

  const speak = useCallback((text: string, options?: {
    rate?: number;
    pitch?: number;
    volume?: number;
    lang?: string;
  }) => {
    if (!settings.ttsEnabled || !('speechSynthesis' in window)) {
      return;
    }

    // Cancel any ongoing speech
    speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    if (options) {
      utterance.rate = options.rate || 1;
      utterance.pitch = options.pitch || 1;
      utterance.volume = options.volume || 1;
      utterance.lang = options.lang || 'en-US';
    }

    speechSynthesis.speak(utterance);
  }, [settings.ttsEnabled]);

  const speakWord = useCallback((word: string, language: string, pronunciation?: string) => {
    if (!settings.ttsEnabled) return;

    const langCodes: Record<string, string> = {
      'French': 'fr-FR',
      'Spanish': 'es-ES',
      'German': 'de-DE',
      'English': 'en-US',
    };

    const text = pronunciation ? `${word}. ${pronunciation}` : word;
    speak(text, { lang: langCodes[language] || 'en-US' });
  }, [speak, settings.ttsEnabled]);

  return {
    speak,
    speakWord,
    isSupported: 'speechSynthesis' in window,
    isEnabled: settings.ttsEnabled,
  };
}
