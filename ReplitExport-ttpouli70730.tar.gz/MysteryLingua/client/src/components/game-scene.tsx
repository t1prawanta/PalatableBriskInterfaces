import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Eye, Book } from "lucide-react";
import type { Game, Clue } from "@shared/schema";
import { useAccessibility } from "@/hooks/use-accessibility";

interface GameSceneProps {
  game: Game;
  onClueClick: (clueId: string) => void;
}

export function GameScene({ game, onClueClick }: GameSceneProps) {
  const { announceStatus } = useAccessibility();
  const { mysteryScenario, currentTurn, maxTurns, discoveredClues } = game;

  const handleClueClick = (clue: Clue) => {
    if (!clue.discovered && !discoveredClues.includes(clue.id)) {
      announceStatus(`Examining ${clue.title}. New clue discovered!`);
      onClueClick(clue.id);
    }
  };

  const getClueIcon = (type: string) => {
    switch (type) {
      case 'physical':
        return <Search className="h-4 w-4" />;
      case 'witness':
        return <Eye className="h-4 w-4" />;
      case 'document':
        return <Book className="h-4 w-4" />;
      default:
        return <Search className="h-4 w-4" />;
    }
  };

  const getClueColors = (index: number) => {
    const colors = [
      'bg-primary hover:bg-primary-dark border-primary pattern-primary',
      'bg-secondary hover:bg-secondary-dark border-secondary pattern-secondary',
      'bg-accent hover:bg-accent-dark border-accent pattern-accent'
    ];
    return colors[index % colors.length];
  };

  return (
    <Card className="shadow-lg border-2 border-gray-200">
      <div className="bg-gray-800 text-white px-4 py-3 flex items-center justify-between">
        <h2 className="font-bold text-lg flex items-center">
          <Search className="mr-2 h-5 w-5" aria-hidden="true" />
          Mystery Scene
        </h2>
        <Badge variant="secondary" className="bg-accent text-white">
          Turn {currentTurn}/{maxTurns}
        </Badge>
      </div>

      <div className="relative">
        <img
          src={mysteryScenario.sceneImage}
          alt={mysteryScenario.sceneDescription}
          className="w-full h-64 object-cover"
        />
        
        {mysteryScenario.clues.map((clue, index) => {
          const isDiscovered = clue.discovered || discoveredClues.includes(clue.id);
          const colorClasses = getClueColors(index);
          
          return clue.position ? (
            <Button
              key={clue.id}
              size="sm"
              onClick={() => handleClueClick(clue)}
              className={`absolute w-8 h-8 rounded-full text-white focus:ring-2 focus:ring-accent focus:ring-offset-2 ${colorClasses} ${
                !isDiscovered ? 'animate-pulse' : ''
              }`}
              style={{
                left: `${clue.position.x}%`,
                top: `${clue.position.y}%`,
              }}
              aria-label={`${isDiscovered ? 'Examine' : 'Discover'} ${clue.title} - Interactive clue location`}
            >
              {getClueIcon(clue.type)}
            </Button>
          ) : null;
        })}
      </div>

      <CardContent className="p-4 bg-gray-50">
        <div className="mb-4">
          <h3 className="font-bold text-lg mb-2">{mysteryScenario.title}</h3>
          <p className="text-gray-700 leading-relaxed">
            <strong>Current Situation:</strong> {mysteryScenario.description}
          </p>
        </div>

        {/* Discovered Clues */}
        <div className="space-y-4">
          <h4 className="font-bold text-lg flex items-center">
            <Eye className="mr-2 h-5 w-5 text-secondary" />
            Discovered Clues
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mysteryScenario.clues
              .filter(clue => clue.discovered || discoveredClues.includes(clue.id))
              .map((clue, index) => {
                const borderColor = index % 3 === 0 ? 'border-primary' : 
                                   index % 3 === 1 ? 'border-secondary' : 'border-accent';
                const bgColor = index % 3 === 0 ? 'bg-blue-50' : 
                                index % 3 === 1 ? 'bg-green-50' : 'bg-orange-50';
                
                return (
                  <div
                    key={clue.id}
                    className={`${bgColor} border-l-4 ${borderColor} p-3 rounded focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2 transform hover:scale-102 transition-transform cursor-pointer`}
                    tabIndex={0}
                    role="button"
                    aria-label={`Clue: ${clue.title}. ${clue.description}`}
                    onClick={() => announceStatus(`Selected clue: ${clue.title}. ${clue.content}`)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        announceStatus(`Selected clue: ${clue.title}. ${clue.content}`);
                      }
                    }}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`text-lg mt-1 ${
                        index % 3 === 0 ? 'text-primary' : 
                        index % 3 === 1 ? 'text-secondary' : 'text-accent'
                      }`}>
                        {getClueIcon(clue.type)}
                      </div>
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900">{clue.title}</h5>
                        <p className="text-sm text-gray-600 mt-1">{clue.description}</p>
                        <div className="mt-2 flex flex-wrap gap-1">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs text-white ${
                              index % 3 === 0 ? 'bg-primary' : 
                              index % 3 === 1 ? 'bg-secondary' : 'bg-accent'
                            }`}
                          >
                            {clue.type.charAt(0).toUpperCase() + clue.type.slice(1)}
                          </Badge>
                          {clue.language && (
                            <Badge variant="outline" className="text-xs">
                              {clue.language}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
          
          {mysteryScenario.clues.filter(clue => clue.discovered || discoveredClues.includes(clue.id)).length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Search className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No clues discovered yet. Click on the hotspots in the scene to investigate!</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
