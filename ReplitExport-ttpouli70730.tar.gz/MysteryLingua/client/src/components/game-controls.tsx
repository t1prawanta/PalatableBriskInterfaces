import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Lightbulb, Clock, Trophy, Star } from "lucide-react";
import type { Game } from "@shared/schema";
import { useAccessibility } from "@/hooks/use-accessibility";

interface GameControlsProps {
  game: Game;
  canTakeAction: boolean;
  onTakeAction: () => void;
  onGetHint: () => void;
}

export function GameControls({ 
  game, 
  canTakeAction, 
  onTakeAction, 
  onGetHint 
}: GameControlsProps) {
  const { announceStatus } = useAccessibility();
  
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleTakeAction = () => {
    onTakeAction();
    announceStatus("Taking game action. Processing your move...");
  };

  const handleGetHint = () => {
    onGetHint();
    announceStatus("Requesting hint. Additional guidance will be provided.");
  };

  const getDifficultyLevel = (level: number) => {
    if (level <= 2) return "Beginner";
    if (level <= 4) return "Intermediate";
    return "Advanced";
  };

  return (
    <Card className="shadow-lg border-2 border-gray-200">
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <Button
              onClick={handleTakeAction}
              disabled={!canTakeAction}
              className="bg-primary hover:bg-primary-dark text-white px-6 py-3 font-medium focus:ring-2 focus:ring-accent focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Take your turn action in the game"
            >
              <Play className="mr-2 h-4 w-4" aria-hidden="true" />
              Take Action
            </Button>
            
            <Button
              variant="outline"
              onClick={handleGetHint}
              className="border-2 border-accent text-accent hover:bg-accent hover:text-white px-6 py-3 font-medium focus:ring-2 focus:ring-accent focus:ring-offset-2"
              aria-label="Request a hint to help solve the mystery"
            >
              <Lightbulb className="mr-2 h-4 w-4" aria-hidden="true" />
              Get Hint
            </Button>
          </div>
          
          <div className="flex items-center space-x-6 text-sm text-gray-600">
            <div className="flex items-center space-x-2" role="status">
              <Clock className="h-4 w-4 text-accent" aria-hidden="true" />
              <span>
                Time Left: 
                <strong className="text-gray-900 ml-1">
                  {formatTime(game.timeLeft)}
                </strong>
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Trophy className="h-4 w-4 text-secondary" aria-hidden="true" />
              <span>
                Score: 
                <strong className="text-gray-900 ml-1">2,450</strong>
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Star className="h-4 w-4 text-accent" aria-hidden="true" />
              <span>
                Difficulty: 
                <strong className="text-gray-900 ml-1">
                  {getDifficultyLevel(game.level)}
                </strong>
              </span>
            </div>
          </div>
        </div>
        
        {!canTakeAction && (
          <div className="mt-3 p-2 bg-yellow-50 border-l-4 border-yellow-400 rounded">
            <p className="text-sm text-yellow-800">
              <strong>Waiting for your turn.</strong> Other players are currently taking their actions.
            </p>
          </div>
        )}
        
        {game.timeLeft <= 60 && (
          <div className="mt-3 p-2 bg-red-50 border-l-4 border-red-400 rounded" role="alert">
            <p className="text-sm text-red-800">
              <strong>Time is running out!</strong> Less than 1 minute remaining.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
