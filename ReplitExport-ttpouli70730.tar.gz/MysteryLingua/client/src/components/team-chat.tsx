import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { MessageCircle, Send, User } from "lucide-react";
import type { Message, Player } from "@shared/schema";
import { useAccessibility } from "@/hooks/use-accessibility";

interface TeamChatProps {
  messages: Message[];
  players: Player[];
  currentPlayerId?: string;
  onSendMessage: (content: string) => void;
  isLoading?: boolean;
}

export function TeamChat({ 
  messages, 
  players, 
  currentPlayerId, 
  onSendMessage, 
  isLoading = false 
}: TeamChatProps) {
  const [messageText, setMessageText] = useState("");
  const { announceStatus } = useAccessibility();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageText.trim() && currentPlayerId) {
      onSendMessage(messageText.trim());
      setMessageText("");
      announceStatus("Message sent to team chat");
    }
  };

  const getPlayerName = (playerId: string) => {
    const player = players.find(p => p.id === playerId);
    return player?.username || "Unknown Player";
  };

  const getPlayerCharacter = (playerId: string) => {
    const player = players.find(p => p.id === playerId);
    return player?.characterType || "player";
  };

  const getPlayerColor = (playerId: string) => {
    const player = players.find(p => p.id === playerId);
    switch (player?.characterType) {
      case 'detective':
        return 'text-primary';
      case 'linguist':
        return 'text-secondary';
      case 'historian':
        return 'text-accent';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <Card className="shadow-lg border-2 border-gray-200">
      <CardHeader className="bg-gray-800 text-white">
        <h3 className="font-bold text-lg flex items-center">
          <MessageCircle className="mr-2 h-5 w-5" aria-hidden="true" />
          Team Chat
        </h3>
      </CardHeader>
      
      <CardContent className="p-0">
        <div 
          className="h-32 p-3 overflow-y-auto bg-gray-50 text-sm"
          role="log"
          aria-label="Team chat messages"
          aria-live="polite"
        >
          <div className="space-y-2">
            {messages.map((message) => {
              const playerName = getPlayerName(message.playerId);
              const playerColor = getPlayerColor(message.playerId);
              const isCurrentPlayer = message.playerId === currentPlayerId;
              
              return (
                <div key={message.id} className="flex items-start space-x-2">
                  <User className={`${playerColor} mt-1 h-4 w-4`} aria-hidden="true" />
                  <div className="flex-1">
                    <div className="flex items-baseline space-x-2">
                      <strong className={playerColor}>
                        {playerName}{isCurrentPlayer ? ' (You)' : ''}:
                      </strong>
                      <span className="text-xs text-gray-500">
                        {new Date(message.timestamp!).toLocaleTimeString()}
                      </span>
                    </div>
                    <span className="text-gray-700">{message.content}</span>
                  </div>
                </div>
              );
            })}
            
            {messages.length === 0 && (
              <div className="text-center text-gray-500 py-4">
                <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No messages yet. Start the conversation!</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="p-3 border-t">
          <form onSubmit={handleSubmit} className="flex space-x-2">
            <Input
              type="text"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 focus:ring-2 focus:ring-primary"
              aria-label="Team chat message input"
              disabled={!currentPlayerId || isLoading}
            />
            <Button
              type="submit"
              disabled={!messageText.trim() || !currentPlayerId || isLoading}
              className="bg-primary hover:bg-primary-dark text-white focus:ring-2 focus:ring-accent"
              aria-label="Send message"
            >
              <Send className="h-4 w-4" aria-hidden="true" />
            </Button>
          </form>
          
          {!currentPlayerId && (
            <p className="text-xs text-gray-500 mt-2">
              Join the game to participate in team chat
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
