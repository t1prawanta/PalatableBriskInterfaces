import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { GraduationCap, Volume2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { VocabularyWord } from "@shared/schema";
import { useAccessibility } from "@/hooks/use-accessibility";
import { useSpeech } from "@/hooks/use-speech";

interface VocabularyPanelProps {
  gameLevel?: number;
}

export function VocabularyPanel({ gameLevel = 1 }: VocabularyPanelProps) {
  const { announceStatus } = useAccessibility();
  const { speakWord, isEnabled: ttsEnabled } = useSpeech();
  
  const { data: vocabularyWords = [] } = useQuery<VocabularyWord[]>({
    queryKey: ["/api/vocabulary"],
  });

  const handleWordClick = (word: VocabularyWord) => {
    announceStatus(`Studying vocabulary word: ${word.word} in ${word.language}. ${word.meaning}`);
  };

  const handlePronunciation = (word: VocabularyWord, e: React.MouseEvent) => {
    e.stopPropagation();
    if (ttsEnabled) {
      speakWord(word.word, word.language, word.pronunciation);
    }
  };

  const getBorderColor = (index: number) => {
    const colors = ['border-accent', 'border-primary', 'border-secondary'];
    return colors[index % colors.length];
  };

  const getBgColor = (index: number) => {
    const colors = ['bg-orange-50', 'bg-blue-50', 'bg-green-50'];
    return colors[index % colors.length];
  };

  const getLanguageFlag = (language: string) => {
    const flags: Record<string, string> = {
      'French': '🇫🇷',
      'Spanish': '🇪🇸',
      'German': '🇩🇪',
      'English': '🇺🇸',
    };
    return flags[language] || '🌐';
  };

  // Calculate progress (mock calculation)
  const totalWords = 15;
  const learnedWords = Math.min(7, vocabularyWords.length);
  const progressPercent = Math.round((learnedWords / totalWords) * 100);

  return (
    <Card className="shadow-lg border-2 border-gray-200">
      <CardHeader className="bg-secondary text-white pattern-secondary">
        <h3 className="font-bold text-lg flex items-center">
          <GraduationCap className="mr-2 h-5 w-5" aria-hidden="true" />
          Learn Words
        </h3>
      </CardHeader>
      
      <CardContent className="p-4">
        <p className="text-sm text-gray-600 mb-4">
          Master these words to unlock advanced clues!
        </p>
        
        <div className="space-y-3">
          {vocabularyWords.map((word, index) => (
            <div
              key={word.id}
              className={`${getBgColor(index)} border-l-4 ${getBorderColor(index)} p-3 rounded cursor-pointer focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2 transform hover:scale-102 transition-transform`}
              tabIndex={0}
              role="button"
              aria-label={`${word.language} vocabulary word: ${word.word}. Pronunciation: ${word.pronunciation}. Meaning: ${word.meaning}`}
              onClick={() => handleWordClick(word)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleWordClick(word);
                }
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span role="img" aria-label={`${word.language} flag`}>
                      {getLanguageFlag(word.language)}
                    </span>
                    <p className="font-bold text-gray-900">
                      {word.word}
                    </p>
                    <span className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded">
                      {word.language}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">
                    {word.pronunciation} - {word.meaning}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => handlePronunciation(word, e)}
                  className={`p-2 hover:bg-gray-200 focus:ring-2 focus:ring-accent ${
                    index % 3 === 0 ? 'text-accent hover:text-accent-dark' : 
                    index % 3 === 1 ? 'text-primary hover:text-primary-dark' : 
                    'text-secondary hover:text-secondary-dark'
                  }`}
                  aria-label={`Play pronunciation for ${word.word}`}
                  disabled={!ttsEnabled}
                >
                  <Volume2 className="h-4 w-4" aria-hidden="true" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        {vocabularyWords.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <GraduationCap className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Loading vocabulary words...</p>
          </div>
        )}

        {/* Progress Tracker */}
        <div className="mt-4 p-3 bg-gray-50 rounded">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">
              Learning Progress
            </span>
            <span className="text-sm font-bold text-primary">
              {learnedWords}/{totalWords} words
            </span>
          </div>
          <Progress 
            value={progressPercent} 
            className="w-full h-2"
            aria-label={`Learning progress: ${progressPercent} percent complete`}
          />
          <div className="mt-1 text-xs text-gray-500 text-center">
            {progressPercent}% mastered
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
