import { Button } from "@/components/ui/button";
import { useAccessibility } from "@/hooks/use-accessibility";
import { TextIcon, Contrast, Volume2 } from "lucide-react";

export function AccessibilityControls() {
  const { settings, updateSetting, announceStatus } = useAccessibility();

  const handleFontSizeChange = () => {
    const newSize = settings.fontSize >= 24 ? 14 : settings.fontSize + 2;
    updateSetting("fontSize", newSize);
    announceStatus(`Font size changed to ${newSize} pixels`);
  };

  const handleContrastToggle = () => {
    const newContrast = !settings.highContrast;
    updateSetting("highContrast", newContrast);
    announceStatus(`High contrast mode ${newContrast ? 'enabled' : 'disabled'}`);
  };

  const handleTTSToggle = () => {
    const newTTS = !settings.ttsEnabled;
    updateSetting("ttsEnabled", newTTS);
    announceStatus(`Text-to-speech ${newTTS ? 'enabled' : 'disabled'}`);
  };

  return (
    <div className="bg-primary text-white px-4 py-2 text-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <span className="font-medium" aria-label="Accessibility Controls">
          🌟 Accessibility Options
        </span>
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleFontSizeChange}
            className="hover:bg-primary-dark px-2 py-1 text-white hover:text-white focus:ring-2 focus:ring-accent focus:ring-offset-2"
            aria-label={`Current font size: ${settings.fontSize}px. Click to increase font size`}
          >
            <TextIcon className="h-4 w-4 mr-1" aria-hidden="true" />
            Font Size
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleContrastToggle}
            className={`hover:bg-primary-dark px-2 py-1 text-white hover:text-white focus:ring-2 focus:ring-accent focus:ring-offset-2 ${
              settings.highContrast ? 'bg-primary-dark' : ''
            }`}
            aria-label={`High contrast mode ${settings.highContrast ? 'enabled' : 'disabled'}. Click to toggle`}
          >
            <Contrast className="h-4 w-4 mr-1" aria-hidden="true" />
            Contrast
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleTTSToggle}
            className={`hover:bg-primary-dark px-2 py-1 text-white hover:text-white focus:ring-2 focus:ring-accent focus:ring-offset-2 ${
              settings.ttsEnabled ? 'bg-primary-dark' : ''
            }`}
            aria-label={`Text-to-speech ${settings.ttsEnabled ? 'enabled' : 'disabled'}. Click to toggle`}
          >
            <Volume2 className="h-4 w-4 mr-1" aria-hidden="true" />
            Audio
          </Button>
        </div>
      </div>
    </div>
  );
}
