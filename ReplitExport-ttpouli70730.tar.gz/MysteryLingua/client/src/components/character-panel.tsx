import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, UserCheck, Clock, Zap } from "lucide-react";
import type { Player } from "@shared/schema";
import { useAccessibility } from "@/hooks/use-accessibility";

interface CharacterPanelProps {
  players: Player[];
  currentPlayerId?: string;
  onCharacterSelect: (playerId: string) => void;
}

export function CharacterPanel({ players, currentPlayerId, onCharacterSelect }: CharacterPanelProps) {
  const { announceStatus } = useAccessibility();

  const handleCharacterSelect = (player: Player) => {
    onCharacterSelect(player.id);
    announceStatus(`${player.characterType.charAt(0).toUpperCase() + player.characterType.slice(1)} character selected and activated`);
  };

  const getCharacterIcon = (type: string) => {
    switch (type) {
      case 'detective':
        return '🕵️';
      case 'linguist':
        return '🗣️';
      case 'historian':
        return '📜';
      default:
        return '👤';
    }
  };

  const getCharacterDescription = (type: string) => {
    switch (type) {
      case 'detective':
        return 'Analyze physical evidence and crime scenes';
      case 'linguist':
        return 'Translate clues and decode messages';
      case 'historian':
        return 'Research historical context and artifacts';
      default:
        return 'General investigation abilities';
    }
  };

  return (
    <Card className="shadow-lg border-2 border-gray-200">
      <CardHeader className="bg-accent text-white pattern-accent">
        <h3 className="font-bold text-lg flex items-center">
          <Users className="mr-2 h-5 w-5" aria-hidden="true" />
          Your Characters
        </h3>
      </CardHeader>
      <CardContent className="p-4 space-y-4">
        {players.map((player) => {
          const isActive = player.id === currentPlayerId;
          const cardClasses = isActive 
            ? 'bg-blue-50 border-2 border-primary' 
            : 'bg-gray-50 border-2 border-gray-300 hover:border-gray-400';

          return (
            <div
              key={player.id}
              className={`${cardClasses} rounded-lg p-3 cursor-pointer focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2 transform hover:scale-102 transition-all`}
              tabIndex={0}
              role="button"
              aria-label={`${player.characterType.charAt(0).toUpperCase() + player.characterType.slice(1)} character ${isActive ? '- Selected' : '- Available'}`}
              onClick={() => handleCharacterSelect(player)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleCharacterSelect(player);
                }
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="text-lg" role="img" aria-label={`${player.characterType} icon`}>
                    {getCharacterIcon(player.characterType)}
                  </span>
                  <h4 className={`font-bold ${isActive ? 'text-gray-900' : 'text-gray-700'}`}>
                    {player.characterType.charAt(0).toUpperCase() + player.characterType.slice(1)}
                  </h4>
                </div>
                {isActive && (
                  <Badge className="bg-primary text-white text-xs">
                    <UserCheck className="h-3 w-3 mr-1" />
                    ACTIVE
                  </Badge>
                )}
              </div>
              
              <p className={`text-sm mb-3 ${isActive ? 'text-gray-600' : 'text-gray-500'}`}>
                {getCharacterDescription(player.characterType)}
              </p>
              
              <div className="space-y-2">
                {player.abilities.map((ability) => (
                  <div key={ability.id} className="flex items-center space-x-2">
                    <Zap className={`h-4 w-4 ${isActive ? 'text-primary' : 'text-gray-400'}`} />
                    <span className={`text-sm font-medium ${isActive ? 'text-gray-900' : 'text-gray-600'}`}>
                      {ability.name}
                    </span>
                    {ability.ready ? (
                      <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                        Ready
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs bg-yellow-100 text-yellow-800">
                        <Clock className="h-3 w-3 mr-1" />
                        {ability.cooldown} turns
                      </Badge>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-3 pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm">
                  <span className={`font-medium ${isActive ? 'text-gray-700' : 'text-gray-500'}`}>
                    Score: {player.score}
                  </span>
                  <span className={`font-medium ${isActive ? 'text-gray-700' : 'text-gray-500'}`}>
                    {player.username}
                  </span>
                </div>
              </div>
            </div>
          );
        })}

        {players.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No characters available. Join the game to select a character!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
