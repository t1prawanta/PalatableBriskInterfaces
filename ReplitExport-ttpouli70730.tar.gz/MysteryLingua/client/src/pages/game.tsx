import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { AccessibilityControls } from "@/components/accessibility-controls";
import { GameScene } from "@/components/game-scene";
import { CharacterPanel } from "@/components/character-panel";
import { TeamChat } from "@/components/team-chat";
import { VocabularyPanel } from "@/components/vocabulary-panel";
import { GameControls } from "@/components/game-controls";
import { useGameState } from "@/hooks/use-game-state";
import { useAccessibility } from "@/hooks/use-accessibility";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GameProps {
  params: {
    id: string;
  };
}

export default function Game({ params }: GameProps) {
  const [, setLocation] = useLocation();
  const [currentPlayerId, setCurrentPlayerId] = useState<string>();
  const { announceStatus } = useAccessibility();
  const { toast } = useToast();
  
  const gameId = params.id;
  const urlParams = new URLSearchParams(window.location.search);
  const username = urlParams.get('username');

  const {
    game,
    players,
    messages,
    isLoading,
    createPlayer,
    updatePlayer,
    updateGame,
    sendMessage,
    isCreatingPlayer,
    isSendingMessage,
  } = useGameState(gameId);

  // Auto-join game if username is provided and player doesn't exist
  useEffect(() => {
    if (game && username && !isLoading && players.length === 0) {
      // Check if user already joined
      const existingPlayer = players.find(p => p.username === username);
      if (!existingPlayer) {
        // Auto-select detective as default character
        createPlayer({
          username,
          characterType: 'detective',
          isActive: true,
          score: 0,
          abilities: [], // Will be set by server
        });
      } else {
        setCurrentPlayerId(existingPlayer.id);
      }
    }
  }, [game, username, players, createPlayer, isLoading]);

  // Set current player when players load
  useEffect(() => {
    if (username && players.length > 0 && !currentPlayerId) {
      const player = players.find(p => p.username === username);
      if (player) {
        setCurrentPlayerId(player.id);
      }
    }
  }, [players, username, currentPlayerId]);

  if (!username) {
    setLocation('/');
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading game...</p>
        </div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Game Not Found</h1>
          <p className="text-gray-600 mb-4">The requested game could not be found.</p>
          <Button onClick={() => setLocation('/')} className="bg-primary hover:bg-primary-dark">
            Return to Lobby
          </Button>
        </div>
      </div>
    );
  }

  const handleCharacterSelect = (playerId: string) => {
    setCurrentPlayerId(playerId);
  };

  const handleClueClick = (clueId: string) => {
    if (currentPlayerId && game) {
      const newDiscoveredClues = [...game.discoveredClues, clueId];
      updateGame({
        discoveredClues: newDiscoveredClues,
      });
      toast({
        title: "Clue Discovered!",
        description: "You found a new piece of evidence.",
      });
    }
  };

  const handleSendMessage = (content: string) => {
    if (currentPlayerId) {
      sendMessage({
        playerId: currentPlayerId,
        content,
      });
    }
  };

  const handleTakeAction = () => {
    announceStatus("Processing your action...");
    toast({
      title: "Action Taken",
      description: "Your move has been processed.",
    });
  };

  const handleGetHint = () => {
    announceStatus("Hint: Look for clues that match your character's abilities.");
    toast({
      title: "Hint",
      description: "Look for clues that match your character's abilities.",
    });
  };

  const canTakeAction = currentPlayerId && game.status === 'active';

  return (
    <div className="min-h-screen bg-gray-50">
      <AccessibilityControls />
      
      {/* Game Header */}
      <header className="bg-white shadow-sm border-b-4 border-primary">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">
                Mystery Language Quest
              </h1>
              <Badge className="bg-secondary text-white pattern-secondary">
                {game.mysteryScenario.title}
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right text-sm">
                <p className="text-gray-600">Players Online</p>
                <p className="font-bold text-lg">{players.length}/{game.maxPlayers}</p>
              </div>
              <Button 
                variant="outline"
                className="border-accent text-accent hover:bg-accent hover:text-white"
              >
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Game Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Game Scene */}
          <div className="lg:col-span-2">
            <GameScene game={game} onClueClick={handleClueClick} />
          </div>
          
          {/* Character Selection */}
          <div className="lg:col-span-1">
            <CharacterPanel 
              players={players}
              currentPlayerId={currentPlayerId}
              onCharacterSelect={handleCharacterSelect}
            />
          </div>
          
          {/* Team Chat & Vocabulary */}
          <div className="lg:col-span-1">
            <TeamChat
              messages={messages}
              players={players}
              currentPlayerId={currentPlayerId}
              onSendMessage={handleSendMessage}
              isLoading={isSendingMessage}
            />
            <div className="mt-6">
              <VocabularyPanel gameLevel={game.level} />
            </div>
          </div>
        </div>
        
        {/* Game Controls */}
        <div className="mt-8">
          <GameControls
            game={game}
            canTakeAction={!!canTakeAction}
            onTakeAction={handleTakeAction}
            onGetHint={handleGetHint}
          />
        </div>
      </main>

      {/* Screen Reader Status Updates */}
      <div id="accessibility-status" aria-live="polite" aria-atomic="true" className="sr-only">
        {/* Dynamic status updates for screen readers */}
      </div>
    </div>
  );
}
