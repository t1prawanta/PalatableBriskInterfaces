import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useGames } from "@/hooks/use-game-state";
import { useAccessibility } from "@/hooks/use-accessibility";
import { Link } from "wouter";
import { Users, Play, Plus, Search } from "lucide-react";
import type { InsertGame } from "@shared/schema";

export default function Lobby() {
  const [username, setUsername] = useState("");
  const [gameForm, setGameForm] = useState({
    name: "",
    maxPlayers: 6,
    level: 1,
  });
  const [showCreateForm, setShowCreateForm] = useState(false);
  
  const { games, isLoading, createGame, isCreatingGame } = useGames();
  const { announceStatus } = useAccessibility();

  const handleCreateGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gameForm.name.trim()) return;

    const gameData: InsertGame = {
      name: gameForm.name,
      maxPlayers: gameForm.maxPlayers,
      level: gameForm.level,
      currentTurn: 1,
      maxTurns: 12,
      timeLeft: 600,
      status: "waiting",
      mysteryScenario: undefined as any, // Will be set by server
      discoveredClues: [],
    };

    createGame(gameData);
    setGameForm({ name: "", maxPlayers: 6, level: 1 });
    setShowCreateForm(false);
    announceStatus(`Created new game: ${gameForm.name}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'waiting':
        return 'bg-yellow-100 text-yellow-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyLevel = (level: number) => {
    if (level <= 2) return "Beginner";
    if (level <= 4) return "Intermediate";
    return "Advanced";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            <Search className="inline-block mr-3 h-10 w-10 text-primary" />
            Mystery Language Quest
          </h1>
          <p className="text-lg text-gray-600">
            Collaborate with other players to solve mysteries while learning new languages
          </p>
        </div>

        {/* Username Input */}
        {!username && (
          <Card className="max-w-md mx-auto mb-8">
            <CardHeader>
              <CardTitle>Join the Adventure</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={(e) => {
                e.preventDefault();
                const input = (e.target as HTMLFormElement).username as HTMLInputElement;
                if (input.value.trim()) {
                  setUsername(input.value.trim());
                  announceStatus(`Welcome, ${input.value.trim()}!`);
                }
              }}>
                <div className="space-y-4">
                  <Input
                    name="username"
                    placeholder="Enter your username"
                    required
                    className="focus:ring-2 focus:ring-primary"
                    aria-label="Enter your username"
                  />
                  <Button type="submit" className="w-full bg-primary hover:bg-primary-dark">
                    Continue
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {username && (
          <>
            {/* Welcome Message */}
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                Welcome back, {username}!
              </h2>
              <p className="text-gray-600">Choose a game to join or create your own mystery</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Game List */}
              <div className="lg:col-span-2">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-900">Available Games</h3>
                  <Button
                    onClick={() => setShowCreateForm(!showCreateForm)}
                    className="bg-accent hover:bg-accent-dark text-white"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create Game
                  </Button>
                </div>

                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <Card key={i} className="animate-pulse">
                        <CardContent className="p-6">
                          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                          <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {games.map((game) => (
                      <Card key={game.id} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <h4 className="font-bold text-lg text-gray-900">{game.name}</h4>
                            <Badge className={getStatusColor(game.status)}>
                              {game.status}
                            </Badge>
                          </div>
                          
                          <div className="space-y-2 mb-4">
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                              <Users className="h-4 w-4" />
                              <span>Players: 0/{game.maxPlayers}</span>
                            </div>
                            <div className="text-sm text-gray-600">
                              Level {game.level} - {getDifficultyLevel(game.level)}
                            </div>
                            <div className="text-sm text-gray-600">
                              Turn {game.currentTurn}/{game.maxTurns}
                            </div>
                          </div>

                          <Link href={`/game/${game.id}?username=${encodeURIComponent(username)}`}>
                            <Button 
                              className="w-full bg-primary hover:bg-primary-dark"
                              disabled={game.status === 'completed'}
                            >
                              <Play className="mr-2 h-4 w-4" />
                              {game.status === 'waiting' ? 'Join Game' : 'Spectate'}
                            </Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {!isLoading && games.length === 0 && (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                      <h4 className="text-xl font-semibold text-gray-900 mb-2">
                        No games available
                      </h4>
                      <p className="text-gray-600 mb-4">
                        Be the first to create a mystery adventure!
                      </p>
                      <Button
                        onClick={() => setShowCreateForm(true)}
                        className="bg-accent hover:bg-accent-dark"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Create First Game
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Create Game Form */}
              <div className="lg:col-span-1">
                {showCreateForm && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Create New Game</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleCreateGame} className="space-y-4">
                        <div>
                          <label htmlFor="game-name" className="block text-sm font-medium text-gray-700 mb-1">
                            Game Name
                          </label>
                          <Input
                            id="game-name"
                            value={gameForm.name}
                            onChange={(e) => setGameForm(prev => ({ ...prev, name: e.target.value }))}
                            placeholder="Enter game name"
                            required
                            className="focus:ring-2 focus:ring-primary"
                          />
                        </div>

                        <div>
                          <label htmlFor="max-players" className="block text-sm font-medium text-gray-700 mb-1">
                            Max Players
                          </label>
                          <Select 
                            value={gameForm.maxPlayers.toString()} 
                            onValueChange={(value) => setGameForm(prev => ({ ...prev, maxPlayers: parseInt(value) }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="2">2 Players</SelectItem>
                              <SelectItem value="4">4 Players</SelectItem>
                              <SelectItem value="6">6 Players</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label htmlFor="difficulty" className="block text-sm font-medium text-gray-700 mb-1">
                            Difficulty Level
                          </label>
                          <Select 
                            value={gameForm.level.toString()} 
                            onValueChange={(value) => setGameForm(prev => ({ ...prev, level: parseInt(value) }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">Level 1 - Beginner</SelectItem>
                              <SelectItem value="2">Level 2 - Beginner</SelectItem>
                              <SelectItem value="3">Level 3 - Intermediate</SelectItem>
                              <SelectItem value="4">Level 4 - Intermediate</SelectItem>
                              <SelectItem value="5">Level 5 - Advanced</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <Button 
                          type="submit" 
                          className="w-full bg-accent hover:bg-accent-dark"
                          disabled={isCreatingGame || !gameForm.name.trim()}
                        >
                          {isCreatingGame ? 'Creating...' : 'Create Game'}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                )}

                {/* Game Rules */}
                <Card className={showCreateForm ? 'mt-6' : ''}>
                  <CardHeader>
                    <CardTitle>How to Play</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-gray-600 space-y-2">
                    <p>• Choose a character with unique abilities</p>
                    <p>• Collaborate to discover clues in the mystery scene</p>
                    <p>• Learn vocabulary words to unlock advanced clues</p>
                    <p>• Use team chat to coordinate with other players</p>
                    <p>• Solve the mystery before time runs out!</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
