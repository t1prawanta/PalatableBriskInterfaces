# Overview

This is an educational multiplayer mystery game that combines language learning with collaborative investigation gameplay. Players work together to solve mysteries while learning vocabulary in different languages. The application features real-time collaboration, character-based gameplay with unique abilities, and progressive language learning through contextual vocabulary integration.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Comprehensive component system built on Radix UI primitives with shadcn/ui styling
- **Styling**: Tailwind CSS with custom design system including theme variables for colors, typography, and accessibility
- **Routing**: Client-side routing using Wouter for lightweight navigation
- **State Management**: TanStack Query for server state management with custom hooks for game state
- **Accessibility**: Built-in accessibility features including screen reader support, keyboard navigation, high contrast mode, text-to-speech, and font size controls

## Backend Architecture
- **Framework**: Express.js server with TypeScript
- **API Design**: RESTful API endpoints for games, players, messages, and vocabulary management
- **Storage**: In-memory storage implementation with interface-based design for easy database migration
- **Development**: Vite middleware integration for hot reloading in development mode
- **Build**: ESBuild for server-side bundling and deployment

## Data Storage Solutions
- **ORM**: Drizzle ORM configured for PostgreSQL with schema-first approach
- **Database**: PostgreSQL (via Neon serverless) for production data persistence
- **Schema**: Comprehensive data models for games, players, messages, vocabulary words, and player progress
- **Migrations**: Drizzle Kit for database schema management and migrations

## Authentication and Authorization
- **Session Management**: PostgreSQL session storage using connect-pg-simple
- **Player Management**: Game-based player creation and management without traditional user accounts
- **Access Control**: Game-specific player permissions and character-based abilities

## Game Logic and Features
- **Mystery System**: Structured mystery scenarios with clues, characters, and progression mechanics
- **Character Classes**: Detective, linguist, and historian roles with unique abilities and gameplay mechanics
- **Real-time Features**: Message polling for team chat and game state updates
- **Vocabulary Integration**: Multi-language vocabulary system with difficulty levels and pronunciation support
- **Accessibility Integration**: Text-to-speech for vocabulary learning and comprehensive screen reader support

# External Dependencies

## Database and Infrastructure
- **Neon Database**: Serverless PostgreSQL database for production data storage
- **Drizzle ORM**: Type-safe database operations and schema management

## UI and Component Libraries  
- **Radix UI**: Comprehensive set of accessible React primitives for complex UI components
- **Tailwind CSS**: Utility-first CSS framework for responsive design and theming
- **Lucide React**: Icon library for consistent iconography throughout the application

## Development and Build Tools
- **Vite**: Fast build tool with hot module replacement for development
- **ESBuild**: Fast JavaScript bundler for production builds
- **TypeScript**: Type safety across the entire application stack

## State Management and API
- **TanStack Query**: Server state management with caching, background updates, and optimistic updates
- **React Hook Form**: Form state management with validation
- **Zod**: Runtime type validation for API requests and responses

## Accessibility and User Experience
- **Speech Synthesis API**: Browser-native text-to-speech for vocabulary pronunciation
- **Screen Reader Support**: ARIA labels and live regions for status announcements
- **Keyboard Navigation**: Full keyboard accessibility throughout the application

## Additional Features
- **Wouter**: Lightweight client-side routing
- **Date-fns**: Date manipulation and formatting utilities
- **Class Variance Authority**: Type-safe utility for conditional CSS classes