import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/index.html", "./client/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        primary: {
          DEFAULT: "var(--primary)",
          dark: "var(--primary-dark)",
          foreground: "var(--primary-foreground)",
        },
        secondary: {
          DEFAULT: "var(--secondary)",
          dark: "var(--secondary-dark)",
          foreground: "var(--secondary-foreground)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          dark: "var(--accent-dark)",
          foreground: "var(--accent-foreground)",
        },
        card: {
          DEFAULT: "var(--card)",
          foreground: "var(--card-foreground)",
        },
        popover: {
          DEFAULT: "var(--popover)",
          foreground: "var(--popover-foreground)",
        },
        muted: {
          DEFAULT: "var(--muted)",
          foreground: "var(--muted-foreground)",
        },
        destructive: {
          DEFAULT: "var(--destructive)",
          foreground: "var(--destructive-foreground)",
        },
        border: "var(--border)",
        input: "var(--input)",
        ring: "var(--ring)",
        chart: {
          "1": "var(--chart-1)",
          "2": "var(--chart-2)",
          "3": "var(--chart-3)",
          "4": "var(--chart-4)",
          "5": "var(--chart-5)",
        },
        sidebar: {
          DEFAULT: "var(--sidebar-background)",
          foreground: "var(--sidebar-foreground)",
          primary: "var(--sidebar-primary)",
          "primary-foreground": "var(--sidebar-primary-foreground)",
          accent: "var(--sidebar-accent)",
          "accent-foreground": "var(--sidebar-accent-foreground)",
          border: "var(--sidebar-border)",
          ring: "var(--sidebar-ring)",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "Inter", "system-ui", "sans-serif"],
        serif: ["var(--font-serif)", "Georgia", "serif"],
        mono: ["var(--font-mono)", "Courier New", "monospace"],
      },
      backgroundImage: {
        'diagonal-stripes': 'repeating-linear-gradient(45deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px)',
        'dots': 'radial-gradient(circle, rgba(0,0,0,0.1) 1px, transparent 1px)',
        'crosshatch': 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px), repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px)',
        'pattern-primary': 'linear-gradient(45deg, var(--primary) 25%, transparent 25%), linear-gradient(-45deg, var(--primary) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, var(--primary) 75%), linear-gradient(-45deg, transparent 75%, var(--primary) 75%)',
        'pattern-secondary': 'radial-gradient(circle, var(--secondary) 2px, transparent 2px)',
        'pattern-accent': 'repeating-linear-gradient(90deg, var(--accent), var(--accent) 2px, transparent 2px, transparent 8px)',
      },
      backgroundSize: {
        'pattern-primary': '8px 8px',
        'pattern-secondary': '10px 10px',
        'pattern-accent': '12px 4px',
      },
      backgroundPosition: {
        'pattern-primary': '0 0, 0 4px, 4px -4px, -4px 0px',
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        "pulse-glow": {
          "0%, 100%": {
            opacity: "1",
            transform: "scale(1)",
          },
          "50%": {
            opacity: "0.8",
            transform: "scale(1.05)",
          },
        },
        "clue-discovered": {
          "0%": {
            transform: "scale(1) rotate(0deg)",
            opacity: "0.8",
          },
          "50%": {
            transform: "scale(1.1) rotate(5deg)",
            opacity: "1",
          },
          "100%": {
            transform: "scale(1) rotate(0deg)",
            opacity: "1",
          },
        },
        "hotspot-pulse": {
          "0%": {
            transform: "scale(1)",
            boxShadow: "0 0 0 0 rgba(25, 118, 210, 0.7)",
          },
          "70%": {
            transform: "scale(1.05)",
            boxShadow: "0 0 0 10px rgba(25, 118, 210, 0)",
          },
          "100%": {
            transform: "scale(1)",
            boxShadow: "0 0 0 0 rgba(25, 118, 210, 0)",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-glow": "pulse-glow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "clue-discovered": "clue-discovered 0.5s ease-out",
        "hotspot-pulse": "hotspot-pulse 2s infinite",
      },
      scale: {
        '102': '1.02',
      },
      spacing: {
        '18': '4.5rem',
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"), 
    require("@tailwindcss/typography"),
    // Custom plugin for accessibility patterns
    function({ addUtilities }: any) {
      const newUtilities = {
        '.pattern-primary': {
          backgroundImage: 'linear-gradient(45deg, var(--primary) 25%, transparent 25%), linear-gradient(-45deg, var(--primary) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, var(--primary) 75%), linear-gradient(-45deg, transparent 75%, var(--primary) 75%)',
          backgroundSize: '8px 8px',
          backgroundPosition: '0 0, 0 4px, 4px -4px, -4px 0px',
        },
        '.pattern-secondary': {
          backgroundImage: 'radial-gradient(circle, var(--secondary) 2px, transparent 2px)',
          backgroundSize: '10px 10px',
        },
        '.pattern-accent': {
          backgroundImage: 'repeating-linear-gradient(90deg, var(--accent), var(--accent) 2px, transparent 2px, transparent 8px)',
        },
        '.high-contrast': {
          filter: 'contrast(150%) brightness(1.1)',
        },
        '.focus-visible': {
          outline: '3px solid var(--accent)',
          outlineOffset: '2px',
        },
      }
      addUtilities(newUtilities)
    }
  ],
} satisfies Config;
