echo "# MysteryLingua" >> README.md 
git init 
git add README.md 
git commit -m "คอมมิทครั้งแรก" 
git branch -M main 
git remote add origin git@github.com:t1prawanta/MysteryLingua.git
 git push -u origin main