import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const games = pgTable("games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  level: integer("level").notNull().default(1),
  maxPlayers: integer("max_players").notNull().default(6),
  currentTurn: integer("current_turn").notNull().default(1),
  maxTurns: integer("max_turns").notNull().default(12),
  timeLeft: integer("time_left").notNull().default(600), // seconds
  status: text("status").notNull().default("waiting"), // waiting, active, completed
  mysteryScenario: jsonb("mystery_scenario").$type<MysteryScenario>().notNull(),
  discoveredClues: jsonb("discovered_clues").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const players = pgTable("players", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").notNull().references(() => games.id),
  username: text("username").notNull(),
  characterType: text("character_type").notNull(), // detective, linguist, historian
  isActive: boolean("is_active").notNull().default(true),
  score: integer("score").notNull().default(0),
  abilities: jsonb("abilities").$type<CharacterAbility[]>().notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").notNull().references(() => games.id),
  playerId: varchar("player_id").notNull().references(() => players.id),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const vocabularyWords = pgTable("vocabulary_words", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  word: text("word").notNull(),
  language: text("language").notNull(),
  pronunciation: text("pronunciation").notNull(),
  meaning: text("meaning").notNull(),
  difficulty: text("difficulty").notNull(), // beginner, intermediate, advanced
  category: text("category").notNull(), // crime, investigation, etc.
});

export const playerProgress = pgTable("player_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().references(() => players.id),
  wordId: varchar("word_id").notNull().references(() => vocabularyWords.id),
  mastered: boolean("mastered").notNull().default(false),
  attempts: integer("attempts").notNull().default(0),
  lastPracticed: timestamp("last_practiced").defaultNow(),
});

// Type definitions
export interface MysteryScenario {
  title: string;
  description: string;
  sceneImage: string;
  sceneDescription: string;
  clues: Clue[];
  solution: string;
}

export interface Clue {
  id: string;
  type: 'physical' | 'witness' | 'document' | 'digital';
  title: string;
  description: string;
  language?: string;
  content: string;
  position?: { x: number; y: number };
  requiredCharacter?: string;
  vocabularyWords: string[];
  discovered: boolean;
}

export interface CharacterAbility {
  id: string;
  name: string;
  description: string;
  cooldown: number;
  ready: boolean;
}

// Zod schemas
export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  createdAt: true,
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  joinedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  timestamp: true,
});

export const insertVocabularyWordSchema = createInsertSchema(vocabularyWords).omit({
  id: true,
});

export const insertPlayerProgressSchema = createInsertSchema(playerProgress).omit({
  id: true,
  lastPracticed: true,
});

// Types
export type Game = typeof games.$inferSelect;
export type Player = typeof players.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type VocabularyWord = typeof vocabularyWords.$inferSelect;
export type PlayerProgress = typeof playerProgress.$inferSelect;

export type InsertGame = z.infer<typeof insertGameSchema>;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertVocabularyWord = z.infer<typeof insertVocabularyWordSchema>;
export type InsertPlayerProgress = z.infer<typeof insertPlayerProgressSchema>;
