{pkgs}: {
  deps = [
    pkgs.rPackages.org_Rn_eg_db
  ];
}
