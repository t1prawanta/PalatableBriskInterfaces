import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GameLobby } from '../components/games/GameLobby'
import { BusinessMatcherGame } from '../components/games/BusinessMatcherGame'
import { PriceGuesserGame } from '../components/games/PriceGuesserGame'
import { GameResults } from '../components/games/GameResults'
import { GameLeaderboard } from '../components/games/GameLeaderboard'
// import { LineIntegration } from '../components/LineIntegration' // Available for future LINE integration
import { GameType, GameSession, LeaderboardEntry, GameStats } from '../../../shared/game-schema'
import { apiRequest } from '../lib/queryClient'

type GameState = 'lobby' | 'playing' | 'results' | 'leaderboard'

export function GamesPage() {
  const [gameState, setGameState] = useState<GameState>('lobby')
  const [currentGameType, setCurrentGameType] = useState<GameType | null>(null)
  const [currentSession, setCurrentSession] = useState<GameSession | null>(null)
  const [gameQuestions, setGameQuestions] = useState<any[]>([])
  const queryClient = useQueryClient()

  // Fetch leaderboard
  const { data: leaderboard = [] } = useQuery({
    queryKey: ['/api/games/leaderboard'],
    queryFn: () => apiRequest<LeaderboardEntry[]>('/games/leaderboard')
  })

  // Fetch game stats
  const { data: gameStats } = useQuery({
    queryKey: ['/api/games/stats'],
    queryFn: () => apiRequest<GameStats>('/games/stats')
  })

  // Generate questions mutation
  const generateQuestionsMutation = useMutation({
    mutationFn: async ({ gameType, count }: { gameType: GameType, count: number }) => {
      return apiRequest<any[]>(`/games/questions/${gameType}?count=${count}`)
    }
  })

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async ({ gameType, playerName, questions }: { gameType: GameType, playerName: string, questions: any[] }) => {
      return apiRequest<GameSession>('/games/sessions', {
        method: 'POST',
        body: JSON.stringify({ gameType, playerName, questions })
      })
    }
  })

  // Complete session mutation
  const completeSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      return apiRequest<GameSession>(`/games/sessions/${sessionId}/complete`, {
        method: 'POST'
      })
    },
    onSuccess: () => {
      // Invalidate leaderboard and stats queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/games/leaderboard'] })
      queryClient.invalidateQueries({ queryKey: ['/api/games/stats'] })
    }
  })

  const handleStartGame = async (gameType: GameType, playerName: string) => {
    try {
      setCurrentGameType(gameType)
      
      // Determine question count based on game type
      const questionCounts = {
        'business-matcher': 10,
        'price-guesser': 8,
        'rating-predictor': 6
      }
      
      const questions = await generateQuestionsMutation.mutateAsync({
        gameType,
        count: questionCounts[gameType]
      })
      
      const session = await createSessionMutation.mutateAsync({
        gameType,
        playerName,
        questions
      })

      setGameQuestions(questions)
      setCurrentSession(session)
      setGameState('playing')
    } catch (error) {
      console.error('Failed to start game:', error)
      // Could show error toast here
    }
  }

  const handleGameComplete = async (score: number, answers: any[]) => {
    if (!currentSession) return

    try {
      // Update session with final answers and score
      await apiRequest(`/games/sessions/${currentSession.id}`, {
        method: 'PUT',
        body: JSON.stringify({ answers, score })
      })

      // Complete the session
      const completedSession = await completeSessionMutation.mutateAsync(currentSession.id)
      
      setCurrentSession(completedSession)
      setGameState('results')
    } catch (error) {
      console.error('Failed to complete game:', error)
    }
  }

  const handlePlayAgain = () => {
    setGameState('lobby')
    setCurrentSession(null)
    setGameQuestions([])
    setCurrentGameType(null)
  }

  const handleBackToLobby = () => {
    setGameState('lobby')
    setCurrentSession(null)
    setGameQuestions([])
    setCurrentGameType(null)
  }

  const handleViewLeaderboard = () => {
    setGameState('leaderboard')
  }

  const handleBackFromLeaderboard = () => {
    setGameState('lobby')
  }

  // Loading state
  if (generateQuestionsMutation.isPending || createSessionMutation.isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-lg font-medium">Setting up your game...</p>
          <p className="text-muted-foreground">This will just take a moment</p>
        </div>
      </div>
    )
  }

  // Render appropriate game state
  switch (gameState) {
    case 'lobby':
      return (
        <GameLobby
          onStartGame={handleStartGame}
          onViewLeaderboard={handleViewLeaderboard}
          gameStats={gameStats}
        />
      )

    case 'playing':
      if (!currentGameType || !gameQuestions.length) {
        return <div>Error loading game</div>
      }

      switch (currentGameType) {
        case 'business-matcher':
          return (
            <BusinessMatcherGame
              questions={gameQuestions}
              onGameComplete={handleGameComplete}
            />
          )
        case 'price-guesser':
          return (
            <PriceGuesserGame
              questions={gameQuestions}
              onGameComplete={handleGameComplete}
            />
          )
        case 'rating-predictor':
          // Would implement RatingPredictorGame component
          return <div>Rating Predictor Game - Coming Soon!</div>
        default:
          return <div>Unknown game type</div>
      }

    case 'results':
      if (!currentSession) {
        return <div>Error: No game session found</div>
      }
      return (
        <GameResults
          gameSession={currentSession}
          onPlayAgain={handlePlayAgain}
          onBackToLobby={handleBackToLobby}
          onViewLeaderboard={handleViewLeaderboard}
        />
      )

    case 'leaderboard':
      return (
        <GameLeaderboard
          leaderboard={leaderboard}
          onBack={handleBackFromLeaderboard}
        />
      )

    default:
      return <div>Unknown game state</div>
  }
}