import { useState, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { useLocation, useSearch } from 'wouter'
import { BusinessCard } from '../components/BusinessCard'
import { SearchFilter } from '../components/SearchFilter'
import { Button } from '../components/ui/button'
import { Card, CardContent } from '../components/ui/card'
import { Business, ServiceCategory, SearchFilters } from '@shared/schema'
import { apiRequest } from '../lib/queryClient'

export function SearchPage() {
  const { t } = useTranslation()
  const [, setLocation] = useLocation()
  const searchParams = useSearch()
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    sortBy: 'relevance',
    language: 'en'
  })

  // Parse URL parameters on mount
  useEffect(() => {
    const params = new URLSearchParams(searchParams)
    const filters: SearchFilters = {
      sortBy: 'relevance',
      language: 'en'
    }

    if (params.get('q')) filters.query = params.get('q')!
    if (params.get('category')) filters.categoryId = params.get('category')!
    if (params.get('rating')) filters.rating = Number(params.get('rating'))
    if (params.get('sort')) filters.sortBy = params.get('sort') as SearchFilters['sortBy']

    setSearchFilters(filters)
  }, [searchParams])

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: () => apiRequest<ServiceCategory[]>('/categories')
  })

  // Fetch search results
  const { data: searchResults, isLoading, refetch } = useQuery({
    queryKey: ['/api/search', searchFilters],
    queryFn: () => {
      const params = new URLSearchParams()
      if (searchFilters.query) params.set('query', searchFilters.query)
      if (searchFilters.categoryId) params.set('categoryId', searchFilters.categoryId)
      if (searchFilters.rating) params.set('rating', searchFilters.rating.toString())
      if (searchFilters.sortBy) params.set('sortBy', searchFilters.sortBy)
      if (searchFilters.priceRange) params.set('priceRange', searchFilters.priceRange.join(','))

      return apiRequest<{
        businesses: Business[]
        total: number
        query: string
        filters: Partial<SearchFilters>
      }>(`/search?${params.toString()}`)
    }
  })

  const businesses = searchResults?.businesses || []
  const totalResults = searchResults?.total || 0

  const handleBusinessView = (business: Business) => {
    setLocation(`/business/${business.id}`)
  }

  const handleSearch = () => {
    // Update URL with search parameters
    const params = new URLSearchParams()
    if (searchFilters.query) params.set('q', searchFilters.query)
    if (searchFilters.categoryId) params.set('category', searchFilters.categoryId)
    if (searchFilters.rating) params.set('rating', searchFilters.rating.toString())
    if (searchFilters.sortBy) params.set('sort', searchFilters.sortBy)

    setLocation(`/search${params.toString() ? `?${params.toString()}` : ''}`)
    refetch()
  }

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">
          {searchFilters.query ? 
            `Search results for "${searchFilters.query}"` : 
            'Search Local Businesses'
          }
        </h1>
        {totalResults > 0 && (
          <p className="text-muted-foreground">
            {totalResults} {totalResults === 1 ? 'business' : 'businesses'} found
          </p>
        )}
      </div>

      {/* Search Filters */}
      <SearchFilter
        filters={searchFilters}
        onFiltersChange={setSearchFilters}
        categories={categories}
        onSearch={handleSearch}
      />

      {/* Results */}
      <div>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-200 dark:bg-gray-700 h-64 rounded-lg"></div>
              </div>
            ))}
          </div>
        ) : businesses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {businesses.map((business) => (
              <BusinessCard
                key={business.id}
                business={business}
                onViewDetails={handleBusinessView}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold mb-2">
                {t('common.noResults')}
              </h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search criteria or browse categories
              </p>
              <Button onClick={() => setLocation('/')}>
                Browse Categories
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Load More - Future Enhancement */}
      {businesses.length > 0 && businesses.length < totalResults && (
        <div className="text-center">
          <Button variant="outline" size="lg">
            Load More Results
          </Button>
        </div>
      )}
    </div>
  )
}