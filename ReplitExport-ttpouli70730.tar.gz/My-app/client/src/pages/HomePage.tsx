import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { BusinessCard } from '../components/BusinessCard'
import { CategoryGrid } from '../components/CategoryGrid'
import { SearchFilter } from '../components/SearchFilter'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Business, ServiceCategory, SearchFilters } from '@shared/schema'
import { apiRequest } from '../lib/queryClient'
import { useLocation } from 'wouter'

export function HomePage() {
  const { t } = useTranslation()
  const [, setLocation] = useLocation()
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    sortBy: 'relevance',
    language: 'en'
  })

  // Fetch categories
  const { data: categories = [], isLoading: categoriesLoading } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: () => apiRequest<ServiceCategory[]>('/categories')
  })

  // Fetch businesses
  const { data: businessData, isLoading: businessesLoading, refetch } = useQuery({
    queryKey: ['/api/businesses', searchFilters],
    queryFn: () => apiRequest<{ businesses: Business[], total: number }>('/businesses', {
      method: 'GET',
    })
  })

  const businesses = businessData?.businesses || []
  const featuredBusinesses = businesses.filter(b => b.featured).slice(0, 4)

  const handleCategorySelect = (categoryId: string) => {
    setSearchFilters(prev => ({ ...prev, categoryId }))
    setLocation('/search')
  }

  const handleBusinessView = (business: Business) => {
    setLocation(`/business/${business.id}`)
  }

  const handleSearch = () => {
    refetch()
    if (searchFilters.query || searchFilters.categoryId) {
      setLocation('/search')
    }
  }

  if (categoriesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">{t('common.loading')}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="text-center py-12 bg-gradient-to-r from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-900 rounded-lg">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            {t('home.title')}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            {t('home.subtitle')}
          </p>
          
          {/* Search Section */}
          <div className="max-w-2xl mx-auto">
            <SearchFilter
              filters={searchFilters}
              onFiltersChange={setSearchFilters}
              categories={categories}
              onSearch={handleSearch}
            />
          </div>

          {/* Games Quick Access */}
          <div className="flex justify-center mt-8">
            <Button
              onClick={() => setLocation('/games')}
              size="lg"
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 text-lg"
            >
              🎮 Play Business Knowledge Games
            </Button>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section>
        <Card>
          <CardHeader>
            <CardTitle>{t('home.popularCategories')}</CardTitle>
          </CardHeader>
          <CardContent>
            <CategoryGrid
              categories={categories}
              onCategorySelect={handleCategorySelect}
            />
          </CardContent>
        </Card>
      </section>

      {/* Featured Businesses */}
      {featuredBusinesses.length > 0 && (
        <section>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>{t('home.featuredBusinesses')}</CardTitle>
              <Button
                variant="outline"
                onClick={() => setLocation('/search')}
              >
                View All
              </Button>
            </CardHeader>
            <CardContent>
              {businessesLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 dark:bg-gray-700 h-64 rounded-lg"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {featuredBusinesses.map((business) => (
                    <BusinessCard
                      key={business.id}
                      business={business}
                      onViewDetails={handleBusinessView}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      )}

      {/* Statistics or Additional Info */}
      <section>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2">
                {businesses.length}+
              </div>
              <p className="text-muted-foreground">Local Businesses</p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2">
                {categories.length}
              </div>
              <p className="text-muted-foreground">Service Categories</p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2">
                4.5★
              </div>
              <p className="text-muted-foreground">Average Rating</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}