import { Card, CardContent } from './ui/card'
import { ServiceCategory } from '@shared/schema'
import { useTranslation } from 'react-i18next'
import * as Icons from 'lucide-react'

interface CategoryGridProps {
  categories: ServiceCategory[]
  onCategorySelect: (categoryId: string) => void
}

export function CategoryGrid({ categories, onCategorySelect }: CategoryGridProps) {
  const { i18n } = useTranslation()
  const currentLang = i18n.language as keyof ServiceCategory['name']

  const getIcon = (iconName: string) => {
    const IconComponent = Icons[iconName as keyof typeof Icons] as any
    return IconComponent || Icons.Store
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {categories.map((category) => {
        const IconComponent = getIcon(category.icon)
        
        return (
          <Card
            key={category.id}
            className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1"
            onClick={() => onCategorySelect(category.id)}
          >
            <CardContent className="p-6 text-center">
              <IconComponent className="category-icon" />
              <h3 className="font-semibold text-sm">
                {category.name[currentLang] || category.name.en}
              </h3>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                {category.description[currentLang] || category.description.en}
              </p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}