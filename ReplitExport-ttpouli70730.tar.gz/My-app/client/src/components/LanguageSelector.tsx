import { Globe } from 'lucide-react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { SupportedLanguages, SupportedLanguage } from '@shared/schema'
import { useTranslation } from 'react-i18next'

export function LanguageSelector() {
  const { i18n } = useTranslation()

  const handleLanguageChange = (language: string) => {
    i18n.changeLanguage(language)
  }

  const currentLanguage = i18n.language as SupportedLanguage
  const languageEntries = Object.entries(SupportedLanguages) as [SupportedLanguage, string][]

  return (
    <div className="flex items-center space-x-2">
      <Globe className="w-4 h-4 text-muted-foreground" />
      <Select value={currentLanguage} onValueChange={handleLanguageChange}>
        <SelectTrigger className="w-auto border-none shadow-none">
          <SelectValue>
            {SupportedLanguages[currentLanguage]}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {languageEntries.map(([code, name]) => (
            <SelectItem key={code} value={code}>
              {name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}