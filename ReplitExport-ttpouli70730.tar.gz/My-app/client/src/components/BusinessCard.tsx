import { Star, MapPin, Clock, Phone, ExternalLink, Check } from 'lucide-react'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Business } from '@shared/schema'
import { formatPrice, formatRating, isBusinessOpen } from '@/lib/utils'
import { useTranslation } from 'react-i18next'

interface BusinessCardProps {
  business: Business
  onViewDetails: (business: Business) => void
}

export function BusinessCard({ business, onViewDetails }: BusinessCardProps) {
  const { t, i18n } = useTranslation()
  const currentLang = i18n.language as keyof typeof business.description
  
  const isOpen = isBusinessOpen(business.hours)
  const description = business.description[currentLang] || business.description.en || ''

  return (
    <Card className="business-card h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold line-clamp-2">
              {business.name}
            </CardTitle>
            <div className="flex items-center mt-2 space-x-2">
              <div className="flex items-center">
                <Star className="w-4 h-4 fill-current text-yellow-400" />
                <span className="ml-1 text-sm font-medium">
                  {formatRating(business.rating)}
                </span>
                <span className="text-sm text-muted-foreground ml-1">
                  ({business.reviewCount} {t('common.reviews')})
                </span>
              </div>
              <div className="price-range-indicator">
                <span className="text-sm font-medium text-green-600">
                  {business.priceRange}
                </span>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end space-y-1">
            {business.featured && (
              <Badge variant="secondary" className="text-xs">
                {t('business.featured')}
              </Badge>
            )}
            {business.verified && (
              <div className="flex items-center text-xs text-green-600">
                <Check className="w-3 h-3 mr-1" />
                {t('business.verified')}
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 pt-0">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {description}
        </p>

        <div className="space-y-2">
          <div className="flex items-center text-sm">
            <MapPin className="w-4 h-4 mr-2 text-muted-foreground shrink-0" />
            <span className="line-clamp-1">{business.address}</span>
          </div>

          <div className="flex items-center text-sm">
            <Clock className="w-4 h-4 mr-2 text-muted-foreground shrink-0" />
            <span className={`font-medium ${isOpen ? 'text-green-600' : 'text-red-600'}`}>
              {isOpen ? t('business.openNow') : t('business.closed')}
            </span>
          </div>

          {business.services.length > 0 && (
            <div className="mt-3">
              <p className="text-xs font-medium text-muted-foreground mb-2">
                {t('business.services')}:
              </p>
              <div className="space-y-1">
                {business.services.slice(0, 2).map((service, index) => (
                  <div key={index} className="flex justify-between items-center text-sm">
                    <span className="line-clamp-1">
                      {service.name[currentLang] || service.name.en}
                    </span>
                    <span className="font-medium text-green-600 ml-2">
                      {formatPrice(service.price, service.currency)}
                    </span>
                  </div>
                ))}
                {business.services.length > 2 && (
                  <p className="text-xs text-muted-foreground">
                    +{business.services.length - 2} more services
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="pt-0 space-x-2">
        <Button
          variant="outline"
          size="sm"
          className="flex-1"
          onClick={() => onViewDetails(business)}
        >
          {t('common.viewDetails')}
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open(`tel:${business.phone}`, '_self')}
        >
          <Phone className="w-4 h-4" />
        </Button>
        
        {business.website && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.open(business.website, '_blank')}
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}