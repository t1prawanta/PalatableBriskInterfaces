import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { Timer, Trophy, Target } from 'lucide-react'
import { BusinessMatcherQuestion } from '@shared/game-schema'
import { useTranslation } from 'react-i18next'

interface BusinessMatcherGameProps {
  questions: BusinessMatcherQuestion[]
  onGameComplete: (score: number, answers: any[]) => void
}

export function BusinessMatcherGame({ questions, onGameComplete }: BusinessMatcherGameProps) {
  const { t, i18n } = useTranslation()
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [score, setScore] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [answers, setAnswers] = useState<any[]>([])
  const [timeLeft, setTimeLeft] = useState(30) // 30 seconds per question
  const [gameStartTime] = useState(Date.now())

  const currentQuestion = questions[currentQuestionIndex]
  const currentLang = i18n.language as keyof Record<string, string>

  useEffect(() => {
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0) {
      handleTimeUp()
    }
  }, [timeLeft, showResult])

  const handleTimeUp = () => {
    if (selectedAnswer === null) {
      handleAnswerSubmit('') // Submit empty answer for timeout
    }
  }

  const handleAnswerSelect = (categoryId: string) => {
    setSelectedAnswer(categoryId)
  }

  const handleAnswerSubmit = (answer: string) => {
    const isCorrect = answer === currentQuestion.correctCategoryId
    const timeToAnswer = 30 - timeLeft
    
    const answerRecord = {
      questionId: currentQuestion.id,
      playerAnswer: answer,
      correctAnswer: currentQuestion.correctCategoryId,
      isCorrect,
      timeToAnswer
    }

    setAnswers([...answers, answerRecord])

    if (isCorrect) {
      const timeBonus = Math.max(0, timeLeft * 2) // Bonus points for speed
      setScore(score + 100 + timeBonus)
    }

    setShowResult(true)

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1)
        setSelectedAnswer(null)
        setShowResult(false)
        setTimeLeft(30)
      } else {
        // Game completed
        onGameComplete(score, [...answers, answerRecord])
      }
    }, 2000)
  }

  const getResultColor = () => {
    if (!showResult) return ''
    const isCorrect = selectedAnswer === currentQuestion.correctCategoryId
    return isCorrect ? 'text-green-600' : 'text-red-600'
  }

  const progressPercentage = ((currentQuestionIndex + 1) / questions.length) * 100

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Game Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5" />
              <span>Business Matcher</span>
            </CardTitle>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-1">
                <Trophy className="w-4 h-4" />
                <span>{score}</span>
              </Badge>
              <Badge variant={timeLeft <= 10 ? "destructive" : "outline"} className="flex items-center space-x-1">
                <Timer className="w-4 h-4" />
                <span>{timeLeft}s</span>
              </Badge>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground">
            Question {currentQuestionIndex + 1} of {questions.length}
          </p>
        </CardHeader>
      </Card>

      {/* Question Card */}
      <Card>
        <CardHeader>
          <CardTitle>Match this business to the correct category:</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Business Info */}
          <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <h3 className="text-xl font-bold mb-2">{currentQuestion.businessName}</h3>
            <p className="text-muted-foreground">{currentQuestion.description}</p>
          </div>

          {/* Category Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentQuestion.options.map((option) => {
              const isSelected = selectedAnswer === option.categoryId
              const isCorrect = option.categoryId === currentQuestion.correctCategoryId
              const isWrong = showResult && isSelected && !isCorrect
              const showCorrect = showResult && isCorrect

              return (
                <Button
                  key={option.categoryId}
                  variant={isSelected ? "default" : "outline"}
                  className={`p-6 h-auto text-left justify-start ${
                    showCorrect ? 'bg-green-100 border-green-500 text-green-800' :
                    isWrong ? 'bg-red-100 border-red-500 text-red-800' : ''
                  }`}
                  onClick={() => !showResult && handleAnswerSelect(option.categoryId)}
                  disabled={showResult}
                >
                  <div>
                    <div className="font-semibold">
                      {option.categoryName[currentLang] || option.categoryName.en}
                    </div>
                    {showResult && isCorrect && (
                      <div className="text-sm mt-1 text-green-600">
                        ✓ Correct Answer
                      </div>
                    )}
                    {showResult && isWrong && (
                      <div className="text-sm mt-1 text-red-600">
                        ✗ Wrong Answer
                      </div>
                    )}
                  </div>
                </Button>
              )
            })}
          </div>

          {/* Submit Button */}
          {selectedAnswer && !showResult && (
            <Button 
              onClick={() => handleAnswerSubmit(selectedAnswer)}
              className="w-full"
              size="lg"
            >
              Submit Answer
            </Button>
          )}

          {/* Result Message */}
          {showResult && (
            <div className={`text-center p-4 rounded-lg ${getResultColor()}`}>
              {selectedAnswer === currentQuestion.correctCategoryId ? (
                <div>
                  <p className="text-lg font-bold">🎉 Correct!</p>
                  <p>You earned {100 + Math.max(0, timeLeft * 2)} points!</p>
                </div>
              ) : (
                <div>
                  <p className="text-lg font-bold">❌ Incorrect</p>
                  <p>The correct answer was {
                    currentQuestion.options.find(o => o.categoryId === currentQuestion.correctCategoryId)
                      ?.categoryName[currentLang] || 
                    currentQuestion.options.find(o => o.categoryId === currentQuestion.correctCategoryId)
                      ?.categoryName.en
                  }</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}