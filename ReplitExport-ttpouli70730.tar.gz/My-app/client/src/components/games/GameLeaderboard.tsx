import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { 
  Trophy, 
  Medal, 
  Target, 
  Clock, 
  TrendingUp,
  Crown,
  ArrowLeft,
  Filter
} from 'lucide-react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { LeaderboardEntry, GameType } from '@shared/game-schema'
import { useTranslation } from 'react-i18next'

interface GameLeaderboardProps {
  leaderboard: LeaderboardEntry[]
  onBack: () => void
}

export function GameLeaderboard({ leaderboard, onBack }: GameLeaderboardProps) {
  const { t } = useTranslation()
  const [selectedGameType, setSelectedGameType] = useState<GameType | 'all'>('all')
  const [sortBy, setSortBy] = useState<'score' | 'accuracy' | 'speed'>('score')

  const getGameTypeDisplay = (gameType: GameType) => {
    switch (gameType) {
      case 'business-matcher': return 'Business Matcher'
      case 'price-guesser': return 'Price Guesser'
      case 'rating-predictor': return 'Rating Predictor'
      default: return gameType
    }
  }

  const filteredLeaderboard = leaderboard
    .filter(entry => selectedGameType === 'all' || entry.gameType === selectedGameType)
    .sort((a, b) => {
      switch (sortBy) {
        case 'score':
          return b.score - a.score
        case 'accuracy':
          return b.accuracy - a.accuracy
        case 'speed':
          return a.averageTimePerQuestion - b.averageTimePerQuestion
        default:
          return b.score - a.score
      }
    })
    .slice(0, 50) // Top 50 entries

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-500" />
      case 2: return <Medal className="w-6 h-6 text-gray-400" />
      case 3: return <Medal className="w-6 h-6 text-amber-600" />
      default: return <div className="w-6 h-6 flex items-center justify-center text-sm font-bold text-muted-foreground">{rank}</div>
    }
  }

  const getRankBackgroundColor = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-gradient-to-r from-yellow-50 to-yellow-100 dark:from-yellow-950 dark:to-yellow-900 border-yellow-200'
      case 2: return 'bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border-gray-200'
      case 3: return 'bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-950 dark:to-amber-900 border-amber-200'
      default: return 'bg-background'
    }
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(date))
  }

  const gameTypeOptions = [
    { value: 'all', label: 'All Games' },
    { value: 'business-matcher', label: 'Business Matcher' },
    { value: 'price-guesser', label: 'Price Guesser' },
    { value: 'rating-predictor', label: 'Rating Predictor' }
  ]

  const sortOptions = [
    { value: 'score', label: 'Score', icon: Trophy },
    { value: 'accuracy', label: 'Accuracy', icon: Target },
    { value: 'speed', label: 'Speed', icon: Clock }
  ]

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="icon" onClick={onBack}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="w-6 h-6 text-yellow-500" />
                  <span>Leaderboard</span>
                </CardTitle>
                <p className="text-muted-foreground">
                  Top players in local business knowledge games
                </p>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium mb-1 block">Game Type</label>
              <Select value={selectedGameType} onValueChange={(value) => setSelectedGameType(value as GameType | 'all')}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {gameTypeOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1">
              <label className="text-sm font-medium mb-1 block">Sort By</label>
              <Select value={sortBy} onValueChange={(value) => setSortBy(value as 'score' | 'accuracy' | 'speed')}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map(option => {
                    const Icon = option.icon
                    return (
                      <SelectItem key={option.value} value={option.value}>
                        <div className="flex items-center space-x-2">
                          <Icon className="w-4 h-4" />
                          <span>{option.label}</span>
                        </div>
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Rankings</span>
            <Badge variant="outline">
              {filteredLeaderboard.length} players
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredLeaderboard.length === 0 ? (
            <div className="text-center py-12">
              <Trophy className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg font-semibold">No scores yet</p>
              <p className="text-muted-foreground">Be the first to play and set a high score!</p>
            </div>
          ) : (
            <div className="space-y-1">
              {filteredLeaderboard.map((entry, index) => {
                const rank = index + 1
                return (
                  <div
                    key={entry.id}
                    className={`flex items-center p-4 border-b last:border-b-0 ${getRankBackgroundColor(rank)}`}
                  >
                    {/* Rank */}
                    <div className="flex items-center justify-center w-12">
                      {getRankIcon(rank)}
                    </div>

                    {/* Player Info */}
                    <div className="flex-1 min-w-0 ml-4">
                      <div className="flex items-center space-x-2">
                        <p className="font-semibold truncate">{entry.playerName}</p>
                        <Badge variant="outline" className="text-xs">
                          {getGameTypeDisplay(entry.gameType)}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(entry.completedAt)}
                      </p>
                    </div>

                    {/* Stats */}
                    <div className="text-right space-y-1">
                      <div className="font-bold text-lg">{entry.score}</div>
                      <div className="text-xs text-muted-foreground space-x-3">
                        <span>{entry.accuracy.toFixed(1)}% accuracy</span>
                        <span>{entry.averageTimePerQuestion.toFixed(1)}s avg</span>
                      </div>
                    </div>

                    {/* Performance Indicators */}
                    <div className="ml-4 flex flex-col items-center space-y-1">
                      {entry.accuracy >= 90 && (
                        <Badge className="text-xs bg-green-100 text-green-800">
                          <Target className="w-3 h-3 mr-1" />
                          Expert
                        </Badge>
                      )}
                      {entry.averageTimePerQuestion <= 10 && (
                        <Badge className="text-xs bg-blue-100 text-blue-800">
                          <Clock className="w-3 h-3 mr-1" />
                          Speed
                        </Badge>
                      )}
                      {entry.score >= 1000 && (
                        <Badge className="text-xs bg-purple-100 text-purple-800">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          High Score
                        </Badge>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats Summary */}
      {filteredLeaderboard.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="text-center p-6">
              <Trophy className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
              <div className="text-2xl font-bold">{Math.max(...filteredLeaderboard.map(e => e.score))}</div>
              <div className="text-sm text-muted-foreground">Highest Score</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="text-center p-6">
              <Target className="w-8 h-8 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold">
                {(filteredLeaderboard.reduce((sum, e) => sum + e.accuracy, 0) / filteredLeaderboard.length).toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">Avg Accuracy</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="text-center p-6">
              <Clock className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <div className="text-2xl font-bold">
                {(filteredLeaderboard.reduce((sum, e) => sum + e.averageTimePerQuestion, 0) / filteredLeaderboard.length).toFixed(1)}s
              </div>
              <div className="text-sm text-muted-foreground">Avg Time</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}