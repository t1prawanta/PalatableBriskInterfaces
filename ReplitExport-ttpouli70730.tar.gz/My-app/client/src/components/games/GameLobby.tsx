import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { Input } from '../ui/input'
import { 
  Target, 
  DollarSign, 
  Star, 
  Trophy, 
  Users, 
  Clock,
  Play,
  BarChart3
} from 'lucide-react'
import { GameType } from '@shared/game-schema'
import { useTranslation } from 'react-i18next'

interface GameLobbyProps {
  onStartGame: (gameType: GameType, playerName: string) => void
  onViewLeaderboard: () => void
  gameStats?: {
    totalGamesPlayed: number
    bestScore: number
    favoriteGameType?: GameType
  }
}

export function GameLobby({ onStartGame, onViewLeaderboard, gameStats }: GameLobbyProps) {
  const { t } = useTranslation()
  const [playerName, setPlayerName] = useState('')
  const [selectedGame, setSelectedGame] = useState<GameType | null>(null)

  const games = [
    {
      type: 'business-matcher' as GameType,
      title: 'Business Matcher',
      description: 'Match businesses to their correct categories. Test your knowledge of local business types!',
      icon: Target,
      difficulty: 'Easy',
      estimatedTime: '3-5 minutes',
      color: 'bg-blue-500',
      features: ['10 Questions', 'Category Knowledge', 'Time Bonus']
    },
    {
      type: 'price-guesser' as GameType,
      title: 'Price Guesser',
      description: 'Guess the prices of local services. Learn about fair pricing in your area!',
      icon: DollarSign,
      difficulty: 'Medium',
      estimatedTime: '5-8 minutes',
      color: 'bg-green-500',
      features: ['8 Questions', 'Price Accuracy', 'Market Knowledge']
    },
    {
      type: 'rating-predictor' as GameType,
      title: 'Rating Predictor',
      description: 'Predict business ratings based on features. Understand what makes customers happy!',
      icon: Star,
      difficulty: 'Hard',
      estimatedTime: '6-10 minutes',
      color: 'bg-purple-500',
      features: ['6 Questions', 'Feature Analysis', 'Customer Insights']
    }
  ]

  const handleStartGame = () => {
    if (selectedGame && playerName.trim()) {
      onStartGame(selectedGame, playerName.trim())
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy': return 'text-green-600 bg-green-100'
      case 'medium': return 'text-yellow-600 bg-yellow-100'
      case 'hard': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold flex items-center justify-center space-x-3">
          <Trophy className="w-10 h-10 text-yellow-500" />
          <span>Local Business Games</span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Test your knowledge about local businesses, pricing, and customer preferences through fun mini-games!
        </p>
      </div>

      {/* Stats Card */}
      {gameStats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5" />
              <span>Your Game Stats</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{gameStats.totalGamesPlayed}</div>
                <div className="text-sm text-muted-foreground">Games Played</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{gameStats.bestScore}</div>
                <div className="text-sm text-muted-foreground">Best Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {gameStats.favoriteGameType ? 
                    games.find(g => g.type === gameStats.favoriteGameType)?.title || 'N/A' : 
                    'N/A'
                  }
                </div>
                <div className="text-sm text-muted-foreground">Favorite Game</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Player Name Input */}
      <Card>
        <CardHeader>
          <CardTitle>Enter Your Name</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4 max-w-md">
            <Input
              placeholder="Your name..."
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              className="flex-1"
            />
            <Button
              variant="outline"
              onClick={onViewLeaderboard}
              className="flex items-center space-x-2"
            >
              <Trophy className="w-4 h-4" />
              <span>Leaderboard</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Game Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {games.map((game) => {
          const Icon = game.icon
          const isSelected = selectedGame === game.type
          
          return (
            <Card 
              key={game.type}
              className={`cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1 ${
                isSelected ? 'ring-2 ring-primary bg-primary/5' : ''
              }`}
              onClick={() => setSelectedGame(game.type)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className={`w-12 h-12 rounded-lg ${game.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <Badge className={getDifficultyColor(game.difficulty)}>
                    {game.difficulty}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{game.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm">
                  {game.description}
                </p>
                
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{game.estimatedTime}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Features:</p>
                  <div className="flex flex-wrap gap-1">
                    {game.features.map((feature, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>

                {isSelected && (
                  <Button 
                    className="w-full mt-4"
                    onClick={handleStartGame}
                    disabled={!playerName.trim()}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start Game
                  </Button>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>How to Play</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="font-semibold mb-2">📚 Learn</h4>
              <p className="text-muted-foreground">
                Each game teaches you about different aspects of local businesses - categories, pricing, and customer satisfaction.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">⚡ Speed Matters</h4>
              <p className="text-muted-foreground">
                Answer quickly to earn bonus points! But accuracy is more important than speed.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">🏆 Compete</h4>
              <p className="text-muted-foreground">
                Check the leaderboard to see how you rank against other players in your knowledge of local businesses.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}