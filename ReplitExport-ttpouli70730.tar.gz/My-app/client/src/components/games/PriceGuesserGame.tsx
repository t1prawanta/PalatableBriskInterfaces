import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { Input } from '../ui/input'
import { Timer, Trophy, DollarSign, Target } from 'lucide-react'
import { PriceGuesserQuestion } from '@shared/game-schema'
import { useTranslation } from 'react-i18next'
import { formatPrice } from '@/lib/utils'

interface PriceGuesserGameProps {
  questions: PriceGuesserQuestion[]
  onGameComplete: (score: number, answers: any[]) => void
}

export function PriceGuesserGame({ questions, onGameComplete }: PriceGuesserGameProps) {
  const { t, i18n } = useTranslation()
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [score, setScore] = useState(0)
  const [guessedPrice, setGuessedPrice] = useState('')
  const [showResult, setShowResult] = useState(false)
  const [answers, setAnswers] = useState<any[]>([])
  const [timeLeft, setTimeLeft] = useState(45) // 45 seconds per question

  const currentQuestion = questions[currentQuestionIndex]
  const currentLang = i18n.language as keyof Record<string, string>

  useEffect(() => {
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0) {
      handleTimeUp()
    }
  }, [timeLeft, showResult])

  const handleTimeUp = () => {
    if (guessedPrice === '') {
      handleAnswerSubmit(0) // Submit 0 for timeout
    } else {
      handleAnswerSubmit(parseFloat(guessedPrice) || 0)
    }
  }

  const handleAnswerSubmit = (guess: number) => {
    const correctPrice = currentQuestion.correctPrice
    const difference = Math.abs(guess - correctPrice)
    const percentageDifference = (difference / correctPrice) * 100
    
    // Scoring: Perfect = 200 points, within 10% = 150, within 25% = 100, within 50% = 50
    let points = 0
    if (percentageDifference === 0) {
      points = 200 + timeLeft * 3 // Perfect guess bonus
    } else if (percentageDifference <= 10) {
      points = 150 + timeLeft * 2
    } else if (percentageDifference <= 25) {
      points = 100 + timeLeft
    } else if (percentageDifference <= 50) {
      points = 50
    }

    const timeToAnswer = 45 - timeLeft
    const answerRecord = {
      questionId: currentQuestion.id,
      playerAnswer: guess,
      correctAnswer: correctPrice,
      isCorrect: percentageDifference <= 25, // Consider within 25% as "correct"
      timeToAnswer,
      percentageDifference
    }

    setAnswers([...answers, answerRecord])
    setScore(score + points)
    setShowResult(true)

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1)
        setGuessedPrice('')
        setShowResult(false)
        setTimeLeft(45)
      } else {
        onGameComplete(score + points, [...answers, answerRecord])
      }
    }, 3000)
  }

  const handleSubmit = () => {
    const guess = parseFloat(guessedPrice) || 0
    handleAnswerSubmit(guess)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600'
      case 'medium': return 'text-yellow-600'
      case 'hard': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getResultMessage = () => {
    if (!showResult) return ''
    
    const guess = parseFloat(guessedPrice) || 0
    const correct = currentQuestion.correctPrice
    const difference = Math.abs(guess - correct)
    const percentageDifference = (difference / correct) * 100

    if (percentageDifference === 0) {
      return '🎯 Perfect! Exactly right!'
    } else if (percentageDifference <= 10) {
      return '🎉 Excellent! Very close!'
    } else if (percentageDifference <= 25) {
      return '👍 Good guess! Pretty close!'
    } else if (percentageDifference <= 50) {
      return '📊 Not bad, but room for improvement'
    } else {
      return '💭 Keep learning about local pricing!'
    }
  }

  const progressPercentage = ((currentQuestionIndex + 1) / questions.length) * 100

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Game Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center space-x-2">
              <DollarSign className="w-5 h-5" />
              <span>Price Guesser</span>
            </CardTitle>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-1">
                <Trophy className="w-4 h-4" />
                <span>{score}</span>
              </Badge>
              <Badge variant={timeLeft <= 15 ? "destructive" : "outline"} className="flex items-center space-x-1">
                <Timer className="w-4 h-4" />
                <span>{timeLeft}s</span>
              </Badge>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground">
            Question {currentQuestionIndex + 1} of {questions.length}
          </p>
        </CardHeader>
      </Card>

      {/* Question Card */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Guess the price for this service:</CardTitle>
            <Badge className={getDifficultyColor(currentQuestion.difficulty)}>
              {currentQuestion.difficulty.toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Service Info */}
          <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 rounded-lg">
            <h3 className="text-xl font-bold mb-2">{currentQuestion.businessName}</h3>
            <h4 className="text-lg font-semibold text-primary mb-2">
              {currentQuestion.serviceName[currentLang] || currentQuestion.serviceName.en}
            </h4>
            <p className="text-muted-foreground mb-4">{currentQuestion.serviceDescription}</p>
            
            <div className="text-sm text-muted-foreground">
              <p>💡 Hint: Price range is between {formatPrice(currentQuestion.priceRange.min, currentQuestion.currency)} - {formatPrice(currentQuestion.priceRange.max, currentQuestion.currency)}</p>
            </div>
          </div>

          {/* Price Input */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Your Price Guess ({currentQuestion.currency}):
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="number"
                  value={guessedPrice}
                  onChange={(e) => setGuessedPrice(e.target.value)}
                  placeholder="0.00"
                  className="pl-10 text-lg"
                  min={currentQuestion.priceRange.min}
                  max={currentQuestion.priceRange.max}
                  step="0.01"
                  disabled={showResult}
                />
              </div>
            </div>

            {/* Submit Button */}
            {guessedPrice && !showResult && (
              <Button 
                onClick={handleSubmit}
                className="w-full"
                size="lg"
              >
                Submit Guess
              </Button>
            )}
          </div>

          {/* Result */}
          {showResult && (
            <div className="text-center p-6 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className="text-lg font-bold mb-2">
                {getResultMessage()}
              </div>
              <div className="space-y-2">
                <p>Your guess: <span className="font-semibold">{formatPrice(parseFloat(guessedPrice) || 0, currentQuestion.currency)}</span></p>
                <p>Correct price: <span className="font-semibold text-green-600">{formatPrice(currentQuestion.correctPrice, currentQuestion.currency)}</span></p>
                <p>Difference: <span className="font-semibold">
                  {Math.abs((parseFloat(guessedPrice) || 0) - currentQuestion.correctPrice).toFixed(2)} {currentQuestion.currency}
                  ({((Math.abs((parseFloat(guessedPrice) || 0) - currentQuestion.correctPrice) / currentQuestion.correctPrice) * 100).toFixed(1)}%)
                </span></p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}