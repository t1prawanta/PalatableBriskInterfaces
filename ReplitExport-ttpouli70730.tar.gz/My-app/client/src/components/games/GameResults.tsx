import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { 
  Trophy, 
  Target, 
  Clock, 
  TrendingUp, 
  RotateCcw, 
  Home,
  Share2,
  Star
} from 'lucide-react'
import { GameType, GameSession } from '@shared/game-schema'
import { useTranslation } from 'react-i18next'

interface GameResultsProps {
  gameSession: GameSession
  onPlayAgain: () => void
  onBackToLobby: () => void
  onViewLeaderboard: () => void
}

export function GameResults({ gameSession, onPlayAgain, onBackToLobby, onViewLeaderboard }: GameResultsProps) {
  const { t } = useTranslation()
  
  const correctAnswers = gameSession.answers.filter(a => a.isCorrect).length
  const accuracy = (correctAnswers / gameSession.totalQuestions) * 100
  const averageTimePerQuestion = gameSession.timeSpent / gameSession.totalQuestions
  
  const getGameTypeDisplay = (gameType: GameType) => {
    switch (gameType) {
      case 'business-matcher': return 'Business Matcher'
      case 'price-guesser': return 'Price Guesser'
      case 'rating-predictor': return 'Rating Predictor'
      default: return gameType
    }
  }

  const getPerformanceLevel = () => {
    if (accuracy >= 90) return { level: 'Excellent', color: 'text-green-600', emoji: '🏆' }
    if (accuracy >= 75) return { level: 'Great', color: 'text-blue-600', emoji: '🎉' }
    if (accuracy >= 60) return { level: 'Good', color: 'text-yellow-600', emoji: '👍' }
    if (accuracy >= 40) return { level: 'Fair', color: 'text-orange-600', emoji: '📈' }
    return { level: 'Keep Learning', color: 'text-red-600', emoji: '📚' }
  }

  const performance = getPerformanceLevel()

  const shareResults = () => {
    const text = `I just scored ${gameSession.score} points in ${getGameTypeDisplay(gameSession.gameType)} on LocalCompare! 🏆\n\nAccuracy: ${accuracy.toFixed(1)}%\nQuestions: ${correctAnswers}/${gameSession.totalQuestions}\n\nCan you beat my score?`
    
    if (navigator.share) {
      navigator.share({
        title: 'LocalCompare Game Results',
        text: text,
        url: window.location.origin
      })
    } else {
      navigator.clipboard.writeText(text)
      // Could show a toast notification here
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Main Results Card */}
      <Card className="text-center">
        <CardHeader>
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mb-4">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl">Game Complete!</CardTitle>
          <p className="text-xl text-muted-foreground">
            {getGameTypeDisplay(gameSession.gameType)}
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Performance Badge */}
          <div className="flex items-center justify-center space-x-2">
            <span className="text-4xl">{performance.emoji}</span>
            <Badge className={`text-lg px-4 py-2 ${performance.color}`}>
              {performance.level}
            </Badge>
          </div>

          {/* Score Display */}
          <div>
            <div className="text-5xl font-bold text-primary mb-2">
              {gameSession.score}
            </div>
            <p className="text-lg text-muted-foreground">Total Points</p>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="text-center p-6">
            <Target className="w-8 h-8 mx-auto mb-2 text-green-600" />
            <div className="text-2xl font-bold">{correctAnswers}/{gameSession.totalQuestions}</div>
            <div className="text-sm text-muted-foreground">Correct</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="text-center p-6">
            <TrendingUp className="w-8 h-8 mx-auto mb-2 text-blue-600" />
            <div className="text-2xl font-bold">{accuracy.toFixed(1)}%</div>
            <div className="text-sm text-muted-foreground">Accuracy</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="text-center p-6">
            <Clock className="w-8 h-8 mx-auto mb-2 text-purple-600" />
            <div className="text-2xl font-bold">{averageTimePerQuestion.toFixed(1)}s</div>
            <div className="text-sm text-muted-foreground">Avg Time</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="text-center p-6">
            <Star className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
            <div className="text-2xl font-bold">{Math.round(gameSession.score / gameSession.totalQuestions)}</div>
            <div className="text-sm text-muted-foreground">Points/Q</div>
          </CardContent>
        </Card>
      </div>

      {/* Question-by-Question Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Question Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {gameSession.answers.map((answer, index) => (
              <div 
                key={answer.questionId}
                className={`flex items-center justify-between p-3 rounded-lg ${
                  answer.isCorrect ? 'bg-green-50 dark:bg-green-950' : 'bg-red-50 dark:bg-red-950'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                    answer.isCorrect ? 'bg-green-500' : 'bg-red-500'
                  }`}>
                    {index + 1}
                  </div>
                  <span className={answer.isCorrect ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}>
                    {answer.isCorrect ? '✓ Correct' : '✗ Incorrect'}
                  </span>
                </div>
                <div className="text-sm text-muted-foreground">
                  {answer.timeToAnswer.toFixed(1)}s
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Improvement Tips */}
      <Card>
        <CardHeader>
          <CardTitle>Tips for Improvement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {gameSession.gameType === 'business-matcher' && (
              <>
                <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-semibold mb-2">📚 Study Categories</h4>
                  <p className="text-sm text-muted-foreground">
                    Learn more about different business types and their typical services to improve accuracy.
                  </p>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-semibold mb-2">🔍 Read Descriptions</h4>
                  <p className="text-sm text-muted-foreground">
                    Pay attention to key words in business descriptions that hint at their category.
                  </p>
                </div>
              </>
            )}
            
            {gameSession.gameType === 'price-guesser' && (
              <>
                <div className="p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                  <h4 className="font-semibold mb-2">💰 Research Local Prices</h4>
                  <p className="text-sm text-muted-foreground">
                    Browse our business listings to get familiar with typical pricing in your area.
                  </p>
                </div>
                <div className="p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <h4 className="font-semibold mb-2">📊 Consider Factors</h4>
                  <p className="text-sm text-muted-foreground">
                    Think about business location, quality level, and service complexity when guessing prices.
                  </p>
                </div>
              </>
            )}

            {accuracy < 60 && (
              <div className="p-4 bg-orange-50 dark:bg-orange-950 rounded-lg md:col-span-2">
                <h4 className="font-semibold mb-2">🎯 Practice Makes Perfect</h4>
                <p className="text-sm text-muted-foreground">
                  Keep playing to improve your knowledge! Each game teaches you more about local businesses and pricing.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button onClick={onPlayAgain} size="lg" className="flex items-center space-x-2">
          <RotateCcw className="w-4 h-4" />
          <span>Play Again</span>
        </Button>
        
        <Button variant="outline" onClick={onBackToLobby} size="lg" className="flex items-center space-x-2">
          <Home className="w-4 h-4" />
          <span>Back to Games</span>
        </Button>
        
        <Button variant="outline" onClick={onViewLeaderboard} size="lg" className="flex items-center space-x-2">
          <Trophy className="w-4 h-4" />
          <span>Leaderboard</span>
        </Button>
        
        <Button variant="outline" onClick={shareResults} size="lg" className="flex items-center space-x-2">
          <Share2 className="w-4 h-4" />
          <span>Share</span>
        </Button>
      </div>
    </div>
  )
}