import { Store, Menu } from 'lucide-react'
import { Button } from './ui/button'
import { LanguageSelector } from './LanguageSelector'
import { useTranslation } from 'react-i18next'
import { Link, useLocation } from 'wouter'

export function Header() {
  const { t } = useTranslation()
  const [location] = useLocation()

  const navigation = [
    { name: t('navigation.home'), href: '/' },
    { name: t('navigation.search'), href: '/search' },
    { name: t('navigation.categories'), href: '/categories' },
    { name: 'Games', href: '/games' },
  ]

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <Store className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold">
                LocalCompare
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button
                  variant={location === item.href ? "default" : "ghost"}
                  className="text-sm font-medium"
                >
                  {item.name}
                </Button>
              </Link>
            ))}
          </nav>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            <LanguageSelector />
            
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}