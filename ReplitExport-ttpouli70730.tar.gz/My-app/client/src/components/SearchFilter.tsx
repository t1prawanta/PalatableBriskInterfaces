import { useState } from 'react'
import { Search, SlidersHorizontal } from 'lucide-react'
import { Input } from './ui/input'
import { Button } from './ui/button'
import { Card, CardContent } from './ui/card'
import { Badge } from './ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { SearchFilters } from '@shared/schema'
import { useTranslation } from 'react-i18next'

interface SearchFilterProps {
  filters: SearchFilters
  onFiltersChange: (filters: SearchFilters) => void
  categories: Array<{ id: string; name: Record<string, string> }>
  onSearch: () => void
}

export function SearchFilter({ filters, onFiltersChange, categories, onSearch }: SearchFilterProps) {
  const { t, i18n } = useTranslation()
  const [showAdvanced, setShowAdvanced] = useState(false)
  const currentLang = i18n.language as keyof Record<string, string>

  const priceRanges = ['$', '$$', '$$$', '$$$$'] as const
  const sortOptions = [
    { value: 'relevance', label: t('common.relevance') },
    { value: 'rating', label: t('common.rating') },
    { value: 'price', label: t('common.price') },
    { value: 'name', label: t('common.name') },
  ]

  const handleQueryChange = (query: string) => {
    onFiltersChange({ ...filters, query })
  }

  const handleCategoryChange = (categoryId: string) => {
    onFiltersChange({ 
      ...filters, 
      categoryId: categoryId === 'all' ? undefined : categoryId 
    })
  }

  const handlePriceRangeToggle = (priceRange: typeof priceRanges[number]) => {
    const currentRanges = filters.priceRange || []
    const newRanges = currentRanges.includes(priceRange)
      ? currentRanges.filter(r => r !== priceRange)
      : [...currentRanges, priceRange]
    
    onFiltersChange({
      ...filters,
      priceRange: newRanges.length > 0 ? newRanges : undefined
    })
  }

  const handleSortChange = (sortBy: SearchFilters['sortBy']) => {
    onFiltersChange({ ...filters, sortBy })
  }

  const handleRatingChange = (rating: number) => {
    onFiltersChange({
      ...filters,
      rating: filters.rating === rating ? undefined : rating
    })
  }

  const clearFilters = () => {
    onFiltersChange({
      query: '',
      sortBy: 'relevance',
      language: filters.language
    })
  }

  const activeFilterCount = [
    filters.categoryId,
    filters.priceRange?.length,
    filters.rating
  ].filter(Boolean).length

  return (
    <Card className="w-full">
      <CardContent className="p-4 space-y-4">
        {/* Search Bar */}
        <div className="flex space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder={t('home.searchPlaceholder')}
              value={filters.query || ''}
              onChange={(e) => handleQueryChange(e.target.value)}
              className="pl-10"
              onKeyPress={(e) => e.key === 'Enter' && onSearch()}
            />
          </div>
          <Button onClick={onSearch}>
            {t('common.search')}
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="relative"
          >
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            {t('common.filter')}
            {activeFilterCount > 0 && (
              <Badge variant="destructive" className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
        </div>

        {/* Quick Category Selection */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={!filters.categoryId ? "default" : "outline"}
            size="sm"
            onClick={() => handleCategoryChange('all')}
          >
            All Categories
          </Button>
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={filters.categoryId === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => handleCategoryChange(category.id)}
            >
              {category.name[currentLang] || category.name.en}
            </Button>
          ))}
        </div>

        {/* Advanced Filters */}
        {showAdvanced && (
          <div className="border-t pt-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Price Range */}
              <div>
                <label className="text-sm font-medium mb-2 block">
                  {t('common.price')}
                </label>
                <div className="flex flex-wrap gap-1">
                  {priceRanges.map((range) => (
                    <Button
                      key={range}
                      variant={filters.priceRange?.includes(range) ? "default" : "outline"}
                      size="sm"
                      onClick={() => handlePriceRangeToggle(range)}
                    >
                      {range}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Rating */}
              <div>
                <label className="text-sm font-medium mb-2 block">
                  {t('common.rating')}
                </label>
                <div className="flex flex-wrap gap-1">
                  {[4, 3, 2, 1].map((rating) => (
                    <Button
                      key={rating}
                      variant={filters.rating === rating ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleRatingChange(rating)}
                    >
                      {rating}+ ⭐
                    </Button>
                  ))}
                </div>
              </div>

              {/* Sort By */}
              <div>
                <label className="text-sm font-medium mb-2 block">
                  {t('common.sort')}
                </label>
                <Select value={filters.sortBy} onValueChange={handleSortChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Clear Filters */}
              <div className="flex items-end">
                <Button
                  variant="ghost"
                  onClick={clearFilters}
                  disabled={activeFilterCount === 0}
                  className="w-full"
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}