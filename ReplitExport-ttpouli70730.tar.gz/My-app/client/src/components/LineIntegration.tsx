import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Input } from './ui/input'

import { 
  MessageCircle, 
  Bell, 
  Share2, 
  QrCode,
  CheckCircle,
  AlertCircle,
  ExternalLink
} from 'lucide-react'
import { useMutation } from '@tanstack/react-query'
import { apiRequest } from '../lib/queryClient'

import { Business } from '../../../shared/schema'

interface LineIntegrationProps {
  business?: Business
  gameScore?: { score: number, gameType: string }
  onClose?: () => void
}

export function LineIntegration({ business, gameScore, onClose }: LineIntegrationProps) {
  const [lineUserId, setLineUserId] = useState('')
  const [isConnected, setIsConnected] = useState(false)

  // Mutation for sending LINE notifications
  const sendNotificationMutation = useMutation({
    mutationFn: async (data: { type: string, businessId?: string, score?: number, gameType?: string }) => {
      if (!lineUserId) throw new Error('LINE User ID required')
      
      if (data.type === 'business' && data.businessId) {
        return apiRequest('/line/notify/business', {
          method: 'POST',
          body: JSON.stringify({
            userId: lineUserId,
            businessId: data.businessId,
            notificationType: 'business_review'
          })
        })
      } else if (data.type === 'game' && data.score !== undefined && data.gameType) {
        return apiRequest('/line/game/result', {
          method: 'POST',
          body: JSON.stringify({
            userId: lineUserId,
            score: data.score,
            gameType: data.gameType
          })
        })
      }
    }
  })

  // Mutation for managing subscriptions
  const subscriptionMutation = useMutation({
    mutationFn: async ({ action, types }: { action: 'subscribe' | 'unsubscribe', types: string[] }) => {
      return apiRequest('/line/subscription', {
        method: 'POST',
        body: JSON.stringify({
          userId: lineUserId,
          action,
          notificationTypes: types
        })
      })
    }
  })

  const handleConnect = () => {
    if (lineUserId.trim()) {
      setIsConnected(true)
    }
  }

  const handleSendBusinessInfo = () => {
    if (business) {
      sendNotificationMutation.mutate({
        type: 'business',
        businessId: business.id
      })
    }
  }

  const handleSendGameResult = () => {
    if (gameScore) {
      sendNotificationMutation.mutate({
        type: 'game',
        score: gameScore.score,
        gameType: gameScore.gameType
      })
    }
  }

  const handleSubscribe = (types: string[]) => {
    subscriptionMutation.mutate({
      action: 'subscribe',
      types
    })
  }

  const handleShareToLine = () => {
    const url = window.location.href
    const text = business 
      ? `Check out ${business.name} on LocalCompare!`
      : gameScore
      ? `I just scored ${gameScore.score} points in ${gameScore.gameType} on LocalCompare!`
      : 'Check out LocalCompare for local business comparison!'
    
    const lineUrl = `https://line.me/R/msg/text/?${encodeURIComponent(text + ' ' + url)}`
    window.open(lineUrl, '_blank')
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MessageCircle className="w-5 h-5 text-green-500" />
          <span>LINE Integration</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!isConnected ? (
          // Connection Setup
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-3">
                Connect your LINE account to receive notifications and share content easily.
              </p>
              <div className="space-y-2">
                <Input
                  placeholder="Enter your LINE User ID"
                  value={lineUserId}
                  onChange={(e) => setLineUserId(e.target.value)}
                />
                <Button 
                  onClick={handleConnect}
                  disabled={!lineUserId.trim()}
                  className="w-full"
                >
                  Connect LINE Account
                </Button>
              </div>
            </div>

            {/* QR Code Section */}
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <QrCode className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium">Add our LINE Bot</p>
              <p className="text-xs text-muted-foreground mb-2">
                @localcompare-bot
              </p>
              <Button variant="outline" size="sm" asChild>
                <a 
                  href="https://line.me/R/ti/p/@localcompare-bot" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center space-x-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>Add Bot</span>
                </a>
              </Button>
            </div>
          </div>
        ) : (
          // Connected Features
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm font-medium">Connected to LINE</span>
            </div>

            {/* Business Actions */}
            {business && (
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Business Actions</h4>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSendBusinessInfo}
                    disabled={sendNotificationMutation.isPending}
                    className="w-full justify-start"
                  >
                    <Bell className="w-4 h-4 mr-2" />
                    Send Business Info to LINE
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleShareToLine}
                    className="w-full justify-start"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share Business
                  </Button>
                </div>
              </div>
            )}

            {/* Game Actions */}
            {gameScore && (
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Game Results</h4>
                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <p className="text-sm font-medium">{gameScore.gameType}</p>
                  <p className="text-lg font-bold text-blue-600">{gameScore.score} points</p>
                </div>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSendGameResult}
                    disabled={sendNotificationMutation.isPending}
                    className="w-full justify-start"
                  >
                    <Bell className="w-4 h-4 mr-2" />
                    Send Result to LINE
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleShareToLine}
                    className="w-full justify-start"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share Achievement
                  </Button>
                </div>
              </div>
            )}

            {/* Subscription Management */}
            <div className="space-y-3">
              <h4 className="font-medium text-sm">Notifications</h4>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleSubscribe(['business_review', 'price_update'])}
                  disabled={subscriptionMutation.isPending}
                  className="w-full justify-start text-xs"
                >
                  <Bell className="w-3 h-3 mr-2" />
                  Subscribe to Business Updates
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleSubscribe(['game_achievement'])}
                  disabled={subscriptionMutation.isPending}
                  className="w-full justify-start text-xs"
                >
                  <Bell className="w-3 h-3 mr-2" />
                  Subscribe to Game Achievements
                </Button>
              </div>
            </div>

            {/* Status Messages */}
            {sendNotificationMutation.isSuccess && (
              <div className="flex items-center space-x-2 text-green-600 text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>Message sent successfully!</span>
              </div>
            )}

            {sendNotificationMutation.isError && (
              <div className="flex items-center space-x-2 text-red-600 text-sm">
                <AlertCircle className="w-4 h-4" />
                <span>Failed to send message</span>
              </div>
            )}

            {subscriptionMutation.isSuccess && (
              <div className="flex items-center space-x-2 text-green-600 text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>Subscription updated!</span>
              </div>
            )}
          </div>
        )}

        {/* Close Button */}
        {onClose && (
          <Button variant="ghost" onClick={onClose} className="w-full">
            Close
          </Button>
        )}
      </CardContent>
    </Card>
  )
}