import { QueryClientProvider } from '@tanstack/react-query'
import { Router, Route, Switch } from 'wouter'
import { queryClient } from './lib/queryClient'
import { Header } from './components/Header'
import { HomePage } from './pages/HomePage'
import { SearchPage } from './pages/SearchPage'
import { GamesPage } from './pages/GamesPage'
import './lib/i18n'
import './index.css'

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-background">
          <Header />
          <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/search" component={SearchPage} />
              <Route path="/categories" component={HomePage} />
              <Route path="/games" component={GamesPage} />
              <Route path="/business/:id">
                {(params) => (
                  <div className="text-center py-12">
                    <h1 className="text-2xl font-bold">
                      Business Details: {params.id}
                    </h1>
                    <p className="text-muted-foreground mt-2">
                      Business detail page coming soon...
                    </p>
                  </div>
                )}
              </Route>
              <Route>
                <div className="text-center py-12">
                  <h1 className="text-2xl font-bold">404 - Page Not Found</h1>
                  <p className="text-muted-foreground mt-2">
                    The page you're looking for doesn't exist.
                  </p>
                </div>
              </Route>
            </Switch>
          </main>
        </div>
      </Router>
    </QueryClientProvider>
  )
}

export default App