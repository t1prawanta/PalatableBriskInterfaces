import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import LanguageDetector from 'i18next-browser-languagedetector'

const resources = {
  en: {
    translation: {
      common: {
        search: 'Search',
        filter: 'Filter',
        sort: 'Sort',
        loading: 'Loading...',
        error: 'Error',
        tryAgain: 'Try Again',
        viewDetails: 'View Details',
        readMore: 'Read More',
        showLess: 'Show Less',
        noResults: 'No results found',
        category: 'Category',
        rating: 'Rating',
        price: 'Price',
        distance: 'Distance',
        name: 'Name',
        relevance: 'Relevance',
        reviews: 'Reviews',
        hours: 'Hours',
        contact: 'Contact',
        website: 'Website',
        phone: 'Phone',
        email: 'Email',
        address: 'Address'
      },
      navigation: {
        home: 'Home',
        categories: 'Categories',
        search: 'Search',
        games: 'Games',
        about: 'About'
      },
      home: {
        title: 'Find & Compare Local Services',
        subtitle: 'Discover the best local businesses with transparent pricing and genuine reviews',
        searchPlaceholder: 'Search for services, businesses...',
        featuredBusinesses: 'Featured Businesses',
        popularCategories: 'Popular Categories'
      },
      categories: {
        restaurants: 'Restaurants',
        autoRepair: 'Auto Repair',
        beautySalon: 'Beauty & Salon',
        homeServices: 'Home Services'
      },
      business: {
        services: 'Services',
        priceRange: 'Price Range',
        openNow: 'Open Now',
        closed: 'Closed',
        verified: 'Verified',
        featured: 'Featured',
        writeReview: 'Write a Review',
        callNow: 'Call Now',
        visitWebsite: 'Visit Website',
        getDirections: 'Get Directions'
      },
      reviews: {
        customerReviews: 'Customer Reviews',
        writeReview: 'Write a Review',
        rating: 'Rating',
        yourReview: 'Your Review',
        serviceUsed: 'Service Used',
        submitReview: 'Submit Review',
        helpful: 'Helpful',
        verified: 'Verified Purchase'
      }
    }
  },
  es: {
    translation: {
      common: {
        search: 'Buscar',
        filter: 'Filtrar',
        sort: 'Ordenar',
        loading: 'Cargando...',
        error: 'Error',
        tryAgain: 'Intentar de nuevo',
        viewDetails: 'Ver detalles',
        readMore: 'Leer más',
        showLess: 'Mostrar menos',
        noResults: 'No se encontraron resultados',
        category: 'Categoría',
        rating: 'Calificación',
        price: 'Precio',
        distance: 'Distancia',
        name: 'Nombre',
        relevance: 'Relevancia',
        reviews: 'Reseñas',
        hours: 'Horarios',
        contact: 'Contacto',
        website: 'Sitio web',
        phone: 'Teléfono',
        email: 'Correo',
        address: 'Dirección'
      },
      navigation: {
        home: 'Inicio',
        categories: 'Categorías',
        search: 'Buscar',
        about: 'Acerca de'
      },
      home: {
        title: 'Encuentra y Compara Servicios Locales',
        subtitle: 'Descubre los mejores negocios locales con precios transparentes y reseñas genuinas',
        searchPlaceholder: 'Buscar servicios, negocios...',
        featuredBusinesses: 'Negocios Destacados',
        popularCategories: 'Categorías Populares'
      }
    }
  },
  fr: {
    translation: {
      common: {
        search: 'Rechercher',
        filter: 'Filtrer',
        sort: 'Trier',
        loading: 'Chargement...',
        error: 'Erreur',
        tryAgain: 'Réessayer',
        viewDetails: 'Voir les détails',
        readMore: 'Lire plus',
        showLess: 'Réduire',
        noResults: 'Aucun résultat trouvé',
        category: 'Catégorie',
        rating: 'Note',
        price: 'Prix',
        distance: 'Distance',
        name: 'Nom',
        relevance: 'Pertinence',
        reviews: 'Avis',
        hours: 'Horaires',
        contact: 'Contact',
        website: 'Site web',
        phone: 'Téléphone',
        email: 'Email',
        address: 'Adresse'
      },
      navigation: {
        home: 'Accueil',
        categories: 'Catégories',
        search: 'Rechercher',
        about: 'À propos'
      },
      home: {
        title: 'Trouvez et Comparez les Services Locaux',
        subtitle: 'Découvrez les meilleures entreprises locales avec des prix transparents et des avis authentiques',
        searchPlaceholder: 'Rechercher des services, entreprises...',
        featuredBusinesses: 'Entreprises en Vedette',
        popularCategories: 'Catégories Populaires'
      }
    }
  }
}

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: false,
    interpolation: {
      escapeValue: false
    },
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage']
    }
  })

export default i18n