import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(price: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
  }).format(price)
}

export function formatRating(rating: number): string {
  return rating.toFixed(1)
}

export function getPriceRangeDisplay(priceRange: '$' | '$$' | '$$$' | '$$$$'): string {
  return priceRange
}

export function isBusinessOpen(hours: Record<string, string | undefined>): boolean {
  const now = new Date()
  const dayName = now.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase()
  const currentTime = now.getHours() * 100 + now.getMinutes()
  
  const todayHours = hours[dayName]
  if (!todayHours || todayHours.toLowerCase() === 'closed') {
    return false
  }
  
  // Parse hours like "9:00 AM - 5:00 PM"
  const hoursMatch = todayHours.match(/(\d{1,2}):(\d{2})\s*(AM|PM)\s*-\s*(\d{1,2}):(\d{2})\s*(AM|PM)/)
  if (!hoursMatch) {
    return false
  }
  
  const [, openHour, openMin, openPeriod, closeHour, closeMin, closePeriod] = hoursMatch
  
  let openTime = parseInt(openHour) * 100 + parseInt(openMin)
  let closeTime = parseInt(closeHour) * 100 + parseInt(closeMin)
  
  if (openPeriod === 'PM' && parseInt(openHour) !== 12) {
    openTime += 1200
  }
  if (closePeriod === 'PM' && parseInt(closeHour) !== 12) {
    closeTime += 1200
  }
  if (openPeriod === 'AM' && parseInt(openHour) === 12) {
    openTime = parseInt(openMin)
  }
  if (closePeriod === 'AM' && parseInt(closeHour) === 12) {
    closeTime = parseInt(closeMin)
  }
  
  return currentTime >= openTime && currentTime <= closeTime
}

export function getDistanceFromCoords(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371 // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}