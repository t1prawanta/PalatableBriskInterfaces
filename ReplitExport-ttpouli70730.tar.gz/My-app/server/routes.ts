import { Router } from 'express'
import { IStorage } from './storage.js'
import { insertBusinessSchema, insertReviewSchema, SearchFiltersSchema } from '../shared/schema.js'

export function createRoutes(storage: IStorage) {
  const router = Router()

  // Categories
  router.get('/categories', async (_req, res) => {
    try {
      const categories = await storage.getCategories()
      res.json(categories)
    } catch (error) {
      console.error('Error fetching categories:', error)
      res.status(500).json({ error: 'Failed to fetch categories' })
    }
  })

  router.get('/categories/:id', async (req, res) => {
    try {
      const category = await storage.getCategoryById(req.params.id)
      if (!category) {
        return res.status(404).json({ error: 'Category not found' })
      }
      res.json(category)
    } catch (error) {
      console.error('Error fetching category:', error)
      res.status(500).json({ error: 'Failed to fetch category' })
    }
  })

  // Businesses
  router.get('/businesses', async (req, res) => {
    try {
      const filters = SearchFiltersSchema.partial().parse(req.query)
      // Provide defaults for required fields
      const searchFilters = {
        sortBy: 'relevance' as const,
        language: 'en',
        ...filters
      }
      const result = await storage.getBusinesses(searchFilters)
      
      res.json({
        businesses: result.businesses,
        total: result.total,
        page: 1,
        limit: result.total,
        hasMore: false
      })
    } catch (error) {
      console.error('Error fetching businesses:', error)
      res.status(500).json({ error: 'Failed to fetch businesses' })
    }
  })

  router.get('/businesses/:id', async (req, res) => {
    try {
      const business = await storage.getBusinessById(req.params.id)
      if (!business) {
        return res.status(404).json({ error: 'Business not found' })
      }
      res.json(business)
    } catch (error) {
      console.error('Error fetching business:', error)
      res.status(500).json({ error: 'Failed to fetch business' })
    }
  })

  router.post('/businesses', async (req, res) => {
    try {
      const businessData = insertBusinessSchema.parse(req.body)
      const business = await storage.createBusiness(businessData)
      res.status(201).json(business)
    } catch (error) {
      console.error('Error creating business:', error)
      if (error instanceof Error && error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid business data', details: error })
      }
      res.status(500).json({ error: 'Failed to create business' })
    }
  })

  router.put('/businesses/:id', async (req, res) => {
    try {
      const businessData = insertBusinessSchema.partial().parse(req.body)
      const business = await storage.updateBusiness(req.params.id, businessData)
      if (!business) {
        return res.status(404).json({ error: 'Business not found' })
      }
      res.json(business)
    } catch (error) {
      console.error('Error updating business:', error)
      if (error instanceof Error && error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid business data', details: error })
      }
      res.status(500).json({ error: 'Failed to update business' })
    }
  })

  router.delete('/businesses/:id', async (req, res) => {
    try {
      const success = await storage.deleteBusiness(req.params.id)
      if (!success) {
        return res.status(404).json({ error: 'Business not found' })
      }
      res.status(204).send()
    } catch (error) {
      console.error('Error deleting business:', error)
      res.status(500).json({ error: 'Failed to delete business' })
    }
  })

  // Reviews
  router.get('/businesses/:id/reviews', async (req, res) => {
    try {
      const reviews = await storage.getReviewsByBusinessId(req.params.id)
      res.json(reviews)
    } catch (error) {
      console.error('Error fetching reviews:', error)
      res.status(500).json({ error: 'Failed to fetch reviews' })
    }
  })

  router.post('/businesses/:id/reviews', async (req, res) => {
    try {
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        businessId: req.params.id
      })
      const review = await storage.createReview(reviewData)
      res.status(201).json(review)
    } catch (error) {
      console.error('Error creating review:', error)
      if (error instanceof Error && error.name === 'ZodError') {
        return res.status(400).json({ error: 'Invalid review data', details: error })
      }
      res.status(500).json({ error: 'Failed to create review' })
    }
  })

  // Search endpoint
  router.get('/search', async (req, res) => {
    try {
      const filters = SearchFiltersSchema.parse(req.query)
      const result = await storage.getBusinesses(filters)
      
      res.json({
        businesses: result.businesses,
        total: result.total,
        query: filters.query || '',
        filters: {
          categoryId: filters.categoryId,
          priceRange: filters.priceRange,
          rating: filters.rating,
          sortBy: filters.sortBy
        }
      })
    } catch (error) {
      console.error('Error searching businesses:', error)
      res.status(500).json({ error: 'Failed to search businesses' })
    }
  })

  return router
}