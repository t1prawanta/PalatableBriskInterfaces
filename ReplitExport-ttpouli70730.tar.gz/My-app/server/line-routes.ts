import { Router } from 'express'

import { ILineService } from './line-service.js'
import { IStorage } from './storage.js'
import { LineWebhookEvent } from '../shared/line-schema.js'

export function createLineRoutes(lineService: ILineService, storage: IStorage) {
  const router = Router()

  // LINE webhook endpoint
  router.post('/webhook', async (req, res) => {
    try {
      const signature = req.headers['x-line-signature'] as string
      const body = req.body instanceof Buffer ? req.body.toString() : JSON.stringify(req.body)

      // Verify signature
      if (!lineService.verifySignature(body, signature)) {
        console.error('Invalid LINE signature')
        return res.status(401).send('Unauthorized')
      }

      const bodyData = req.body instanceof Buffer ? JSON.parse(body) : req.body
      const events: LineWebhookEvent[] = bodyData.events || []

      // Process each event
      await Promise.all(events.map(event => handleLineEvent(event, lineService, storage)))

      res.status(200).send('OK')
    } catch (error) {
      console.error('LINE webhook error:', error)
      res.status(500).send('Internal Server Error')
    }
  })

  // Send business notification
  router.post('/notify/business', async (req, res) => {
    try {
      const { userId, businessId, notificationType } = req.body

      if (!userId || !businessId || !notificationType) {
        return res.status(400).json({ error: 'Missing required fields' })
      }

      const business = await storage.getBusinessById(businessId)
      if (!business) {
        return res.status(404).json({ error: 'Business not found' })
      }

      await lineService.sendBusinessNotification(userId, business, notificationType)
      res.json({ success: true })
    } catch (error) {
      console.error('Send business notification error:', error)
      res.status(500).json({ error: 'Failed to send notification' })
    }
  })

  // Send business recommendations
  router.post('/recommend', async (req, res) => {
    try {
      const { userId, categoryId, limit = 5 } = req.body

      if (!userId) {
        return res.status(400).json({ error: 'userId is required' })
      }

      const businessData = await storage.getBusinesses({ 
        categoryId, 
        sortBy: 'name', 
        language: 'en' 
      })
      const businesses = businessData.businesses.slice(0, limit)

      if (businesses.length === 0) {
        await lineService.pushMessage(userId, [{
          type: 'text',
          text: 'No businesses found matching your criteria. Try a different category!'
        }])
      } else {
        await lineService.sendBusinessCarousel(userId, businesses)
      }

      res.json({ success: true, count: businesses.length })
    } catch (error) {
      console.error('Send recommendations error:', error)
      res.status(500).json({ error: 'Failed to send recommendations' })
    }
  })

  // Send game invitation
  router.post('/game/invite', async (req, res) => {
    try {
      const { userId, gameType } = req.body

      if (!userId || !gameType) {
        return res.status(400).json({ error: 'Missing required fields' })
      }

      await lineService.sendGameInvite(userId, gameType)
      res.json({ success: true })
    } catch (error) {
      console.error('Send game invite error:', error)
      res.status(500).json({ error: 'Failed to send game invite' })
    }
  })

  // Send game result
  router.post('/game/result', async (req, res) => {
    try {
      const { userId, score, gameType } = req.body

      if (!userId || score === undefined || !gameType) {
        return res.status(400).json({ error: 'Missing required fields' })
      }

      await lineService.sendGameResult(userId, score, gameType)
      res.json({ success: true })
    } catch (error) {
      console.error('Send game result error:', error)
      res.status(500).json({ error: 'Failed to send game result' })
    }
  })

  // Manage subscription
  router.post('/subscription', async (req, res) => {
    try {
      const { userId, action, notificationTypes } = req.body

      if (!userId || !action || !Array.isArray(notificationTypes)) {
        return res.status(400).json({ error: 'Missing required fields' })
      }

      if (!['subscribe', 'unsubscribe'].includes(action)) {
        return res.status(400).json({ error: 'Invalid action' })
      }

      await lineService.handleSubscription(userId, action, notificationTypes)
      res.json({ success: true })
    } catch (error) {
      console.error('Manage subscription error:', error)
      res.status(500).json({ error: 'Failed to manage subscription' })
    }
  })

  // Broadcast message (admin only)
  router.post('/broadcast', async (req, res) => {
    try {
      const { message, adminKey } = req.body

      // Simple admin authentication (in production, use proper auth)
      if (adminKey !== process.env.LINE_ADMIN_KEY) {
        return res.status(401).json({ error: 'Unauthorized' })
      }

      if (!message) {
        return res.status(400).json({ error: 'Message is required' })
      }

      await lineService.broadcastMessage([{
        type: 'text',
        text: message
      }])

      res.json({ success: true })
    } catch (error) {
      console.error('Broadcast message error:', error)
      res.status(500).json({ error: 'Failed to broadcast message' })
    }
  })

  return router
}

async function handleLineEvent(event: any, lineService: ILineService, storage: IStorage) {
  const replyToken = event.replyToken
  const userId = event.source.userId

  if (!userId) {
    console.log('No userId in event, skipping')
    return
  }

  try {
    switch (event.type) {
      case 'message':
        if (event.message.type === 'text') {
          await handleTextMessage(event, lineService, storage)
        }
        break

      case 'postback':
        await handlePostback(event, lineService, storage)
        break

      case 'follow':
        await handleFollow(event, lineService, storage)
        break

      default:
        console.log('Unhandled event type:', event.type)
    }
  } catch (error) {
    console.error('Error handling LINE event:', error)
    
    // Send error message to user
    try {
      await lineService.replyMessage(replyToken, [{
        type: 'text',
        text: 'Sorry, I encountered an error. Please try again later.'
      }])
    } catch (replyError) {
      console.error('Error sending error message:', replyError)
    }
  }
}

async function handleTextMessage(event: any, lineService: ILineService, storage: IStorage) {
  const text = event.message.text.toLowerCase().trim()
  const replyToken = event.replyToken

  // Command handling
  if (text.startsWith('/')) {
    const command = text.substring(1)
    
    switch (command) {
      case 'help':
        await lineService.replyMessage(replyToken, [{
          type: 'text',
          text: `🤖 LocalCompare LINE Bot Commands:

/search [keyword] - Search businesses
/categories - Browse business categories  
/games - Play knowledge games
/subscribe - Manage notifications
/help - Show this help message

You can also just type what you're looking for!`
        }])
        break

      case 'categories':
        const categories = await storage.getCategories()
        await lineService.sendCategoryMenu(event.source.userId!, categories)
        break

      case 'games':
        await lineService.replyMessage(replyToken, [{
          type: 'template',
          altText: 'Play games',
          template: {
            type: 'buttons',
            title: '🎮 Business Knowledge Games',
            text: 'Test your knowledge and compete with others!',
            actions: [
              {
                type: 'uri',
                label: 'Business Matcher',
                uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/games?type=business-matcher`
              },
              {
                type: 'uri',
                label: 'Price Guesser',
                uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/games?type=price-guesser`
              }
            ]
          }
        }])
        break

      case 'subscribe':
        await lineService.replyMessage(replyToken, [{
          type: 'template',
          altText: 'Notification settings',
          template: {
            type: 'buttons',
            title: '🔔 Notification Settings',
            text: 'Choose what notifications you want to receive:',
            actions: [
              {
                type: 'postback',
                label: 'New Reviews',
                data: 'action=subscribe&type=business_review'
              },
              {
                type: 'postback',
                label: 'Price Updates',
                data: 'action=subscribe&type=price_update'
              },
              {
                type: 'postback',
                label: 'New Businesses',
                data: 'action=subscribe&type=new_business'
              }
            ]
          }
        }])
        break

      default:
        if (command.startsWith('search ')) {
          const query = command.substring(7)
          await handleSearch(query, event.source.userId!, lineService, storage)
        } else {
          await lineService.replyMessage(replyToken, [{
            type: 'text',
            text: 'Unknown command. Type /help for available commands.'
          }])
        }
    }
  } else {
    // Natural language processing - simple keyword matching
    if (text.includes('restaurant') || text.includes('food') || text.includes('eat')) {
      await handleSearch('restaurant', event.source.userId!, lineService, storage)
    } else if (text.includes('game') || text.includes('play')) {
      await lineService.sendGameInvite(event.source.userId!, 'business-matcher')
    } else {
      // General search
      await handleSearch(text, event.source.userId!, lineService, storage)
    }
  }
}

async function handlePostback(event: any, lineService: ILineService, storage: IStorage) {
  const data = event.postback.data
  const params = new URLSearchParams(data)
  const action = params.get('action')

  switch (action) {
    case 'category':
      const categoryId = params.get('categoryId')
      if (categoryId) {
        const businessData = await storage.getBusinesses({ 
          categoryId, 
          sortBy: 'name', 
          language: 'en' 
        })
        await lineService.sendBusinessCarousel(event.source.userId!, businessData.businesses.slice(0, 5))
      }
      break

    case 'info':
      const businessId = params.get('businessId')
      if (businessId) {
        const business = await storage.getBusinessById(businessId)
        if (business) {
          await lineService.replyMessage(event.replyToken, [{
            type: 'text',
            text: `📍 ${business.name}
⭐ ${business.rating}/5 (${business.reviewCount} reviews)
💰 ${business.priceRange}
📞 ${business.phone || 'Phone not available'}
🌐 ${business.website || 'Website not available'}

${business.description.en || Object.values(business.description)[0] || 'No description available'}`
          }])
        }
      }
      break

    case 'subscribe':
      const type = params.get('type')
      if (type) {
        await lineService.handleSubscription(event.source.userId!, 'subscribe', [type as any])
      }
      break

    case 'favorite':
      // Handle favorite business (would need user storage)
      await lineService.replyMessage(event.replyToken, [{
        type: 'text',
        text: '❤️ Business added to your favorites!'
      }])
      break

    default:
      console.log('Unknown postback action:', action)
  }
}

async function handleFollow(event: any, lineService: ILineService, _storage: IStorage) {
  const welcomeMessage = {
    type: 'text' as const,
    text: `🎉 Welcome to LocalCompare!

I can help you:
• 🔍 Find local businesses
• 💰 Compare prices and services  
• 🎮 Play business knowledge games
• 🔔 Get notifications about deals

Type /help to see all commands, or just tell me what you're looking for!`
  }

  await lineService.replyMessage(event.replyToken, [welcomeMessage])
}

async function handleSearch(query: string, userId: string, lineService: ILineService, storage: IStorage) {
  const businessData = await storage.getBusinesses({ 
    query, 
    sortBy: 'relevance', 
    language: 'en' 
  })
  
  if (businessData.businesses.length === 0) {
    await lineService.pushMessage(userId, [{
      type: 'text',
      text: `No businesses found for "${query}". Try a different search term or browse categories using /categories`
    }])
  } else {
    await lineService.sendBusinessCarousel(userId, businessData.businesses.slice(0, 5))
  }
}