import { Business, ServiceCategory, Review, InsertBusiness, InsertServiceCategory, InsertReview, SearchFilters } from '../shared/schema.js'


export interface IStorage {
  // Service Categories
  getCategories(): Promise<ServiceCategory[]>
  getCategoryById(id: string): Promise<ServiceCategory | null>
  createCategory(category: InsertServiceCategory): Promise<ServiceCategory>
  
  // Businesses
  getBusinesses(filters?: SearchFilters): Promise<{ businesses: Business[], total: number }>
  getBusinessById(id: string): Promise<Business | null>
  createBusiness(business: InsertBusiness): Promise<Business>
  updateBusiness(id: string, business: Partial<InsertBusiness>): Promise<Business | null>
  deleteBusiness(id: string): Promise<boolean>
  
  // Reviews
  getReviewsByBusinessId(businessId: string): Promise<Review[]>
  createReview(review: InsertReview): Promise<Review>
  updateBusinessRating(businessId: string): Promise<void>
}

export class MemStorage implements IStorage {
  private categories: ServiceCategory[] = []
  private businesses: Business[] = []
  private reviews: Review[] = []

  constructor() {
    this.seedData()
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9)
  }

  private seedData() {
    // Seed Categories
    const categories: ServiceCategory[] = [
      {
        id: 'restaurants',
        name: {
          en: 'Restaurants',
          es: 'Restaurantes',
          fr: 'Restaurants',
          de: 'Restaurants',
          zh: '餐厅',
          ja: 'レストラン',
          th: 'ร้านอาหาร'
        },
        icon: 'utensils',
        description: {
          en: 'Local dining establishments',
          es: 'Establecimientos locales de comida',
          fr: 'Établissements de restauration locaux',
          de: 'Lokale Restaurants',
          zh: '当地餐饮场所',
          ja: '地元の飲食店',
          th: 'สถานที่รับประทานอาหารท้องถิ่น'
        },
        createdAt: new Date()
      },
      {
        id: 'auto-repair',
        name: {
          en: 'Auto Repair',
          es: 'Reparación de Autos',
          fr: 'Réparation Auto',
          de: 'Autoreparatur',
          zh: '汽车维修',
          ja: '自動車修理',
          th: 'ซ่อมรถ'
        },
        icon: 'car',
        description: {
          en: 'Vehicle maintenance and repair services',
          es: 'Servicios de mantenimiento y reparación de vehículos',
          fr: 'Services d\'entretien et de réparation de véhicules',
          de: 'Fahrzeugwartung und Reparaturdienste',
          zh: '车辆维护和维修服务',
          ja: '車両のメンテナンスと修理サービス',
          th: 'บริการซ่อมบำรุงรถยนต์'
        },
        createdAt: new Date()
      },
      {
        id: 'beauty-salon',
        name: {
          en: 'Beauty & Salon',
          es: 'Belleza y Salón',
          fr: 'Beauté et Salon',
          de: 'Schönheit & Salon',
          zh: '美容美发',
          ja: '美容・サロン',
          th: 'ความงามและร้านเสริมสวย'
        },
        icon: 'scissors',
        description: {
          en: 'Hair, beauty, and wellness services',
          es: 'Servicios de cabello, belleza y bienestar',
          fr: 'Services de coiffure, beauté et bien-être',
          de: 'Haar-, Schönheits- und Wellness-Services',
          zh: '美发、美容和健康服务',
          ja: 'ヘア、美容、ウェルネスサービス',
          th: 'บริการดูแลผม ความงาม และสุขภาพ'
        },
        createdAt: new Date()
      },
      {
        id: 'home-services',
        name: {
          en: 'Home Services',
          es: 'Servicios del Hogar',
          fr: 'Services à Domicile',
          de: 'Hausdienstleistungen',
          zh: '家庭服务',
          ja: 'ホームサービス',
          th: 'บริการบ้าน'
        },
        icon: 'home',
        description: {
          en: 'Cleaning, repair, and maintenance services',
          es: 'Servicios de limpieza, reparación y mantenimiento',
          fr: 'Services de nettoyage, réparation et maintenance',
          de: 'Reinigungs-, Reparatur- und Wartungsdienste',
          zh: '清洁、维修和维护服务',
          ja: '清掃、修理、メンテナンスサービス',
          th: 'บริการทำความสะอาด ซ่อมแซม และบำรุงรักษา'
        },
        createdAt: new Date()
      }
    ]

    this.categories = categories

    // Seed Businesses
    const businesses: Business[] = [
      {
        id: 'marios-pizza',
        name: 'Mario\'s Pizza Palace',
        categoryId: 'restaurants',
        description: {
          en: 'Authentic Italian pizza with fresh ingredients',
          es: 'Pizza italiana auténtica con ingredientes frescos',
          fr: 'Pizza italienne authentique avec des ingrédients frais',
          de: 'Authentische italienische Pizza mit frischen Zutaten',
          zh: '使用新鲜食材的正宗意大利比萨',
          ja: '新鮮な食材を使った本格的なイタリアンピザ',
          th: 'พิซซ่าอิตาเลียนแท้ ๆ ด้วยวัตถุดิบสด'
        },
        address: '123 Main St, Downtown',
        phone: '+1 (555) 123-4567',
        email: 'info@mariospizza.com',
        website: 'https://mariospizza.com',
        priceRange: '$$',
        rating: 4.5,
        reviewCount: 127,
        services: [
          {
            name: { en: 'Margherita Pizza', es: 'Pizza Margherita', fr: 'Pizza Margherita', de: 'Margherita Pizza', zh: '玛格丽特比萨', ja: 'マルゲリータピザ', th: 'พิซซ่ามาร์เกอริต้า' },
            price: 14.99,
            unit: 'per pizza',
            currency: 'USD'
          },
          {
            name: { en: 'Pepperoni Pizza', es: 'Pizza de Pepperoni', fr: 'Pizza Pepperoni', de: 'Pepperoni Pizza', zh: '意式辣香肠比萨', ja: 'ペパロニピザ', th: 'พิซซ่าเป็ปเปอโรนี่' },
            price: 16.99,
            unit: 'per pizza',
            currency: 'USD'
          }
        ],
        coordinates: { lat: 40.7128, lng: -74.0060 },
        hours: {
          monday: '11:00 AM - 10:00 PM',
          tuesday: '11:00 AM - 10:00 PM',
          wednesday: '11:00 AM - 10:00 PM',
          thursday: '11:00 AM - 10:00 PM',
          friday: '11:00 AM - 11:00 PM',
          saturday: '11:00 AM - 11:00 PM',
          sunday: '12:00 PM - 9:00 PM'
        },
        featured: true,
        verified: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 'quick-fix-auto',
        name: 'QuickFix Auto Repair',
        categoryId: 'auto-repair',
        description: {
          en: 'Professional automotive repair and maintenance',
          es: 'Reparación y mantenimiento automotriz profesional',
          fr: 'Réparation et entretien automobile professionnel',
          de: 'Professionelle Autoreparatur und -wartung',
          zh: '专业汽车维修和保养',
          ja: 'プロの自動車修理・メンテナンス',
          th: 'บริการซ่อมและบำรุงรักษารถยนต์มืออาชีพ'
        },
        address: '456 Industrial Blvd, Auto District',
        phone: '+1 (555) 234-5678',
        email: 'service@quickfixauto.com',
        website: 'https://quickfixauto.com',
        priceRange: '$$',
        rating: 4.2,
        reviewCount: 89,
        services: [
          {
            name: { en: 'Oil Change', es: 'Cambio de Aceite', fr: 'Vidange', de: 'Ölwechsel', zh: '换机油', ja: 'オイル交換', th: 'เปลี่ยนน้ำมันเครื่อง' },
            price: 39.99,
            unit: 'per service',
            currency: 'USD'
          },
          {
            name: { en: 'Brake Inspection', es: 'Inspección de Frenos', fr: 'Inspection des Freins', de: 'Bremseninspektion', zh: '刹车检查', ja: 'ブレーキ点検', th: 'ตรวจสอบเบรค' },
            price: 59.99,
            unit: 'per service',
            currency: 'USD'
          }
        ],
        coordinates: { lat: 40.7589, lng: -73.9851 },
        hours: {
          monday: '8:00 AM - 6:00 PM',
          tuesday: '8:00 AM - 6:00 PM',
          wednesday: '8:00 AM - 6:00 PM',
          thursday: '8:00 AM - 6:00 PM',
          friday: '8:00 AM - 6:00 PM',
          saturday: '9:00 AM - 4:00 PM',
          sunday: 'Closed'
        },
        featured: false,
        verified: true,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ]

    this.businesses = businesses

    // Seed Reviews
    const reviews: Review[] = [
      {
        id: 'review-1',
        businessId: 'marios-pizza',
        customerName: 'Sarah Johnson',
        rating: 5,
        comment: 'Amazing pizza! The crust is perfect and ingredients are so fresh.',
        serviceUsed: 'Margherita Pizza',
        date: new Date('2024-01-15'),
        verified: true,
        helpful: 12
      },
      {
        id: 'review-2',
        businessId: 'marios-pizza',
        customerName: 'Mike Chen',
        rating: 4,
        comment: 'Great food, but delivery took a bit longer than expected.',
        serviceUsed: 'Pepperoni Pizza',
        date: new Date('2024-01-10'),
        verified: true,
        helpful: 8
      },
      {
        id: 'review-3',
        businessId: 'quick-fix-auto',
        customerName: 'David Wilson',
        rating: 5,
        comment: 'Honest mechanics with fair prices. Fixed my brakes quickly.',
        serviceUsed: 'Brake Inspection',
        date: new Date('2024-01-12'),
        verified: true,
        helpful: 15
      }
    ]

    this.reviews = reviews
  }

  async getCategories(): Promise<ServiceCategory[]> {
    return this.categories
  }

  async getCategoryById(id: string): Promise<ServiceCategory | null> {
    return this.categories.find(c => c.id === id) || null
  }

  async createCategory(category: InsertServiceCategory): Promise<ServiceCategory> {
    const newCategory: ServiceCategory = {
      id: this.generateId(),
      ...category,
      createdAt: new Date()
    }
    this.categories.push(newCategory)
    return newCategory
  }

  async getBusinesses(filters?: SearchFilters): Promise<{ businesses: Business[], total: number }> {
    let filtered = [...this.businesses]

    if (filters) {
      if (filters.query) {
        const query = filters.query.toLowerCase()
        filtered = filtered.filter(b => 
          b.name.toLowerCase().includes(query) ||
          Object.values(b.description).some(desc => desc.toLowerCase().includes(query))
        )
      }

      if (filters.categoryId) {
        filtered = filtered.filter(b => b.categoryId === filters.categoryId)
      }

      if (filters.priceRange && filters.priceRange.length > 0) {
        filtered = filtered.filter(b => filters.priceRange!.includes(b.priceRange))
      }

      if (filters.rating) {
        filtered = filtered.filter(b => b.rating >= filters.rating!)
      }

      // Sort businesses
      switch (filters.sortBy) {
        case 'rating':
          filtered.sort((a, b) => b.rating - a.rating)
          break
        case 'price':
          const priceOrder = { '$': 1, '$$': 2, '$$$': 3, '$$$$': 4 }
          filtered.sort((a, b) => priceOrder[a.priceRange] - priceOrder[b.priceRange])
          break
        case 'name':
          filtered.sort((a, b) => a.name.localeCompare(b.name))
          break
        default:
          // Relevance - featured first, then by rating
          filtered.sort((a, b) => {
            if (a.featured && !b.featured) return -1
            if (!a.featured && b.featured) return 1
            return b.rating - a.rating
          })
      }
    }

    return {
      businesses: filtered,
      total: filtered.length
    }
  }

  async getBusinessById(id: string): Promise<Business | null> {
    return this.businesses.find(b => b.id === id) || null
  }

  async createBusiness(business: InsertBusiness): Promise<Business> {
    const newBusiness: Business = {
      id: this.generateId(),
      ...business,
      createdAt: new Date(),
      updatedAt: new Date()
    }
    this.businesses.push(newBusiness)
    return newBusiness
  }

  async updateBusiness(id: string, business: Partial<InsertBusiness>): Promise<Business | null> {
    const index = this.businesses.findIndex(b => b.id === id)
    if (index === -1) return null

    this.businesses[index] = {
      ...this.businesses[index],
      ...business,
      updatedAt: new Date()
    }
    return this.businesses[index]
  }

  async deleteBusiness(id: string): Promise<boolean> {
    const index = this.businesses.findIndex(b => b.id === id)
    if (index === -1) return false

    this.businesses.splice(index, 1)
    return true
  }

  async getReviewsByBusinessId(businessId: string): Promise<Review[]> {
    return this.reviews.filter(r => r.businessId === businessId)
      .sort((a, b) => b.date.getTime() - a.date.getTime())
  }

  async createReview(review: InsertReview): Promise<Review> {
    const newReview: Review = {
      id: this.generateId(),
      ...review,
      date: new Date()
    }
    this.reviews.push(newReview)
    await this.updateBusinessRating(review.businessId)
    return newReview
  }

  async updateBusinessRating(businessId: string): Promise<void> {
    const businessReviews = await this.getReviewsByBusinessId(businessId)
    const business = this.businesses.find(b => b.id === businessId)
    
    if (business && businessReviews.length > 0) {
      const totalRating = businessReviews.reduce((sum, r) => sum + r.rating, 0)
      business.rating = Number((totalRating / businessReviews.length).toFixed(1))
      business.reviewCount = businessReviews.length
      business.updatedAt = new Date()
    }
  }
}