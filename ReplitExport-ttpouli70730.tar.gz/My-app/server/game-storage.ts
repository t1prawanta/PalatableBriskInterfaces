import { 
  BusinessMatcherQuestion, 
  PriceGuesserQuestion, 
  RatingPredictorQuestion,
  GameSession,
  LeaderboardEntry,
  GameType,
  GameStats
} from '../shared/game-schema.js'
import { Business, ServiceCategory } from '../shared/schema.js'

export interface IGameStorage {
  // Game Questions Generation
  generateBusinessMatcherQuestions(count: number): Promise<BusinessMatcherQuestion[]>
  generatePriceGuesserQuestions(count: number): Promise<PriceGuesserQuestion[]>
  generateRatingPredictorQuestions(count: number): Promise<RatingPredictorQuestion[]>
  
  // Game Sessions
  createGameSession(gameType: GameType, playerName: string, questions: any[]): Promise<GameSession>
  updateGameSession(sessionId: string, answers: any[], score: number): Promise<GameSession | null>
  completeGameSession(sessionId: string): Promise<GameSession | null>
  
  // Leaderboard
  getLeaderboard(gameType?: GameType, limit?: number): Promise<LeaderboardEntry[]>
  addLeaderboardEntry(entry: Omit<LeaderboardEntry, 'id'>): Promise<LeaderboardEntry>
  
  // Stats
  getGameStats(playerName?: string): Promise<GameStats>
}

export class MemGameStorage implements IGameStorage {
  private gameSessions: GameSession[] = []
  private leaderboard: LeaderboardEntry[] = []
  private businesses: Business[] = []
  private categories: ServiceCategory[] = []

  constructor(businesses: Business[], categories: ServiceCategory[]) {
    this.businesses = businesses
    this.categories = categories
    this.seedLeaderboard()
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9)
  }

  private seedLeaderboard() {
    const sampleEntries: LeaderboardEntry[] = [
      {
        id: '1',
        playerName: 'BusinessExpert',
        gameType: 'business-matcher',
        score: 1250,
        totalQuestions: 10,
        accuracy: 95,
        averageTimePerQuestion: 8.5,
        completedAt: new Date('2024-01-20T15:30:00Z')
      },
      {
        id: '2',
        playerName: 'PriceWiz',
        gameType: 'price-guesser',
        score: 1180,
        totalQuestions: 8,
        accuracy: 87.5,
        averageTimePerQuestion: 12.3,
        completedAt: new Date('2024-01-19T10:15:00Z')
      },
      {
        id: '3',
        playerName: 'LocalGuru',
        gameType: 'business-matcher',
        score: 1100,
        totalQuestions: 10,
        accuracy: 90,
        averageTimePerQuestion: 10.2,
        completedAt: new Date('2024-01-18T14:45:00Z')
      },
      {
        id: '4',
        playerName: 'QuickThinker',
        gameType: 'price-guesser',
        score: 980,
        totalQuestions: 8,
        accuracy: 75,
        averageTimePerQuestion: 7.8,
        completedAt: new Date('2024-01-17T09:20:00Z')
      },
      {
        id: '5',
        playerName: 'ServiceSeeker',
        gameType: 'business-matcher',
        score: 920,
        totalQuestions: 10,
        accuracy: 80,
        averageTimePerQuestion: 15.1,
        completedAt: new Date('2024-01-16T16:30:00Z')
      }
    ]
    
    this.leaderboard = sampleEntries
  }

  async generateBusinessMatcherQuestions(count: number): Promise<BusinessMatcherQuestion[]> {
    const questions: BusinessMatcherQuestion[] = []
    const shuffledBusinesses = [...this.businesses].sort(() => Math.random() - 0.5)

    for (let i = 0; i < Math.min(count, shuffledBusinesses.length); i++) {
      const business = shuffledBusinesses[i]
      const correctCategory = this.categories.find(c => c.id === business.categoryId)
      
      if (!correctCategory) continue

      // Get 3 random wrong categories
      const wrongCategories = this.categories
        .filter(c => c.id !== business.categoryId)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)

      const options = [
        {
          categoryId: correctCategory.id,
          categoryName: correctCategory.name
        },
        ...wrongCategories.map(cat => ({
          categoryId: cat.id,
          categoryName: cat.name
        }))
      ].sort(() => Math.random() - 0.5)

      questions.push({
        id: this.generateId(),
        businessName: business.name,
        description: business.description.en || Object.values(business.description)[0],
        correctCategoryId: correctCategory.id,
        options
      })
    }

    return questions
  }

  async generatePriceGuesserQuestions(count: number): Promise<PriceGuesserQuestion[]> {
    const questions: PriceGuesserQuestion[] = []
    const businessesWithServices = this.businesses.filter(b => b.services.length > 0)
    
    const allServices = businessesWithServices.flatMap(business => 
      business.services.map(service => ({
        business,
        service
      }))
    )

    const shuffledServices = allServices.sort(() => Math.random() - 0.5)

    for (let i = 0; i < Math.min(count, shuffledServices.length); i++) {
      const { business, service } = shuffledServices[i]
      
      // Determine difficulty based on price range
      let difficulty: 'easy' | 'medium' | 'hard' = 'medium'
      if (service.price <= 50) difficulty = 'easy'
      else if (service.price <= 200) difficulty = 'medium'
      else difficulty = 'hard'

      // Create price range hint
      const variance = service.price * 0.5 // 50% variance
      const priceRange = {
        min: Math.max(1, service.price - variance),
        max: service.price + variance
      }

      questions.push({
        id: this.generateId(),
        businessName: business.name,
        serviceName: service.name,
        serviceDescription: `${business.priceRange} price range business offering quality service`,
        correctPrice: service.price,
        currency: service.currency,
        priceRange,
        difficulty
      })
    }

    return questions
  }

  async generateRatingPredictorQuestions(count: number): Promise<RatingPredictorQuestion[]> {
    const questions: RatingPredictorQuestion[] = []
    const shuffledBusinesses = [...this.businesses].sort(() => Math.random() - 0.5)

    for (let i = 0; i < Math.min(count, shuffledBusinesses.length); i++) {
      const business = shuffledBusinesses[i]
      const category = this.categories.find(c => c.id === business.categoryId)
      
      if (!category) continue

      // Generate features based on business data
      const features = [
        `${business.priceRange} price range`,
        business.verified ? 'Verified business' : 'Unverified business',
        business.featured ? 'Featured listing' : 'Standard listing',
        `${business.reviewCount} customer reviews`,
        business.website ? 'Has website' : 'No website'
      ].filter(Boolean)

      // Generate rating options around the correct rating
      const correctRating = business.rating
      const options = [
        Math.max(1, correctRating - 1),
        Math.max(1, correctRating - 0.5),
        correctRating,
        Math.min(5, correctRating + 0.5),
        Math.min(5, correctRating + 1)
      ].filter((value, index, array) => array.indexOf(value) === index)
        .sort((a, b) => a - b)

      questions.push({
        id: this.generateId(),
        businessName: business.name,
        category: category.name.en || Object.values(category.name)[0],
        priceRange: business.priceRange,
        reviewCount: business.reviewCount,
        features,
        correctRating,
        options
      })
    }

    return questions
  }

  async createGameSession(gameType: GameType, playerName: string, questions: any[]): Promise<GameSession> {
    const session: GameSession = {
      id: this.generateId(),
      gameType,
      playerName,
      score: 0,
      totalQuestions: questions.length,
      currentQuestion: 0,
      timeSpent: 0,
      startedAt: new Date(),
      questions,
      answers: []
    }

    this.gameSessions.push(session)
    return session
  }

  async updateGameSession(sessionId: string, answers: any[], score: number): Promise<GameSession | null> {
    const sessionIndex = this.gameSessions.findIndex(s => s.id === sessionId)
    if (sessionIndex === -1) return null

    this.gameSessions[sessionIndex].answers = answers
    this.gameSessions[sessionIndex].score = score
    this.gameSessions[sessionIndex].currentQuestion = answers.length

    return this.gameSessions[sessionIndex]
  }

  async completeGameSession(sessionId: string): Promise<GameSession | null> {
    const sessionIndex = this.gameSessions.findIndex(s => s.id === sessionId)
    if (sessionIndex === -1) return null

    const session = this.gameSessions[sessionIndex]
    session.completedAt = new Date()
    session.timeSpent = (session.completedAt.getTime() - session.startedAt.getTime()) / 1000

    // Add to leaderboard
    const correctAnswers = session.answers.filter(a => a.isCorrect).length
    const accuracy = (correctAnswers / session.totalQuestions) * 100
    const averageTimePerQuestion = session.timeSpent / session.totalQuestions

    await this.addLeaderboardEntry({
      playerName: session.playerName,
      gameType: session.gameType,
      score: session.score,
      totalQuestions: session.totalQuestions,
      accuracy,
      averageTimePerQuestion,
      completedAt: session.completedAt
    })

    return session
  }

  async getLeaderboard(gameType?: GameType, limit: number = 50): Promise<LeaderboardEntry[]> {
    let filtered = [...this.leaderboard]
    
    if (gameType) {
      filtered = filtered.filter(entry => entry.gameType === gameType)
    }

    return filtered
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
  }

  async addLeaderboardEntry(entry: Omit<LeaderboardEntry, 'id'>): Promise<LeaderboardEntry> {
    const newEntry: LeaderboardEntry = {
      id: this.generateId(),
      ...entry
    }

    this.leaderboard.push(newEntry)
    return newEntry
  }

  async getGameStats(playerName?: string): Promise<GameStats> {
    let entries = this.leaderboard
    
    if (playerName) {
      entries = entries.filter(e => e.playerName === playerName)
    }

    if (entries.length === 0) {
      return {
        totalGamesPlayed: 0,
        averageScore: 0,
        bestScore: 0,
        totalTimeSpent: 0,
        accuracyByGameType: {},
        gamesPlayedByType: {}
      }
    }

    const totalGamesPlayed = entries.length
    const averageScore = entries.reduce((sum, e) => sum + e.score, 0) / totalGamesPlayed
    const bestScore = Math.max(...entries.map(e => e.score))
    const totalTimeSpent = entries.reduce((sum, e) => sum + (e.averageTimePerQuestion * e.totalQuestions), 0)

    // Group by game type
    const gameTypes = ['business-matcher', 'price-guesser', 'rating-predictor'] as GameType[]
    const accuracyByGameType: Record<GameType, number> = {} as Record<GameType, number>
    const gamesPlayedByType: Record<GameType, number> = {} as Record<GameType, number>

    gameTypes.forEach(type => {
      const typeEntries = entries.filter(e => e.gameType === type)
      gamesPlayedByType[type] = typeEntries.length
      accuracyByGameType[type] = typeEntries.length > 0 
        ? typeEntries.reduce((sum, e) => sum + e.accuracy, 0) / typeEntries.length 
        : 0
    })

    // Find favorite game type
    const favoriteGameType = Object.entries(gamesPlayedByType)
      .sort(([,a], [,b]) => b - a)[0]?.[0] as GameType | undefined

    return {
      totalGamesPlayed,
      averageScore,
      bestScore,
      totalTimeSpent,
      favoriteGameType,
      accuracyByGameType,
      gamesPlayedByType
    }
  }
}