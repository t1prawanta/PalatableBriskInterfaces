import { Router } from 'express'
import { IGameStorage } from './game-storage.js'
import { GameTypeSchema } from '../shared/game-schema.js'

export function createGameRoutes(gameStorage: IGameStorage) {
  const router = Router()

  // Generate questions for a specific game type
  router.get('/questions/:gameType', async (req, res) => {
    try {
      const gameType = GameTypeSchema.parse(req.params.gameType)
      const count = Math.min(parseInt(req.query.count as string) || 10, 20) // Max 20 questions

      let questions
      switch (gameType) {
        case 'business-matcher':
          questions = await gameStorage.generateBusinessMatcherQuestions(count)
          break
        case 'price-guesser':
          questions = await gameStorage.generatePriceGuesserQuestions(count)
          break
        case 'rating-predictor':
          questions = await gameStorage.generateRatingPredictorQuestions(count)
          break
        default:
          return res.status(400).json({ error: 'Invalid game type' })
      }

      res.json(questions)
    } catch (error) {
      console.error('Error generating questions:', error)
      res.status(500).json({ error: 'Failed to generate questions' })
    }
  })

  // Start a new game session
  router.post('/sessions', async (req, res) => {
    try {
      const { gameType, playerName, questions } = req.body

      if (!GameTypeSchema.safeParse(gameType).success) {
        return res.status(400).json({ error: 'Invalid game type' })
      }

      if (!playerName || typeof playerName !== 'string' || playerName.trim().length === 0) {
        return res.status(400).json({ error: 'Player name is required' })
      }

      if (!Array.isArray(questions) || questions.length === 0) {
        return res.status(400).json({ error: 'Questions are required' })
      }

      const session = await gameStorage.createGameSession(gameType, playerName.trim(), questions)
      res.status(201).json(session)
    } catch (error) {
      console.error('Error creating game session:', error)
      res.status(500).json({ error: 'Failed to create game session' })
    }
  })

  // Update game session with answers
  router.put('/sessions/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params
      const { answers, score } = req.body

      if (!Array.isArray(answers)) {
        return res.status(400).json({ error: 'Answers must be an array' })
      }

      if (typeof score !== 'number' || score < 0) {
        return res.status(400).json({ error: 'Score must be a non-negative number' })
      }

      const session = await gameStorage.updateGameSession(sessionId, answers, score)
      if (!session) {
        return res.status(404).json({ error: 'Game session not found' })
      }

      res.json(session)
    } catch (error) {
      console.error('Error updating game session:', error)
      res.status(500).json({ error: 'Failed to update game session' })
    }
  })

  // Complete game session
  router.post('/sessions/:sessionId/complete', async (req, res) => {
    try {
      const { sessionId } = req.params

      const session = await gameStorage.completeGameSession(sessionId)
      if (!session) {
        return res.status(404).json({ error: 'Game session not found' })
      }

      res.json(session)
    } catch (error) {
      console.error('Error completing game session:', error)
      res.status(500).json({ error: 'Failed to complete game session' })
    }
  })

  // Get leaderboard
  router.get('/leaderboard', async (req, res) => {
    try {
      const gameType = req.query.gameType as string
      const limit = Math.min(parseInt(req.query.limit as string) || 50, 100) // Max 100 entries

      let parsedGameType
      if (gameType) {
        const result = GameTypeSchema.safeParse(gameType)
        if (!result.success) {
          return res.status(400).json({ error: 'Invalid game type' })
        }
        parsedGameType = result.data
      }

      const leaderboard = await gameStorage.getLeaderboard(parsedGameType, limit)
      res.json(leaderboard)
    } catch (error) {
      console.error('Error fetching leaderboard:', error)
      res.status(500).json({ error: 'Failed to fetch leaderboard' })
    }
  })

  // Get game statistics
  router.get('/stats', async (req, res) => {
    try {
      const playerName = req.query.playerName as string

      const stats = await gameStorage.getGameStats(playerName)
      res.json(stats)
    } catch (error) {
      console.error('Error fetching game stats:', error)
      res.status(500).json({ error: 'Failed to fetch game stats' })
    }
  })

  // Get available game types
  router.get('/types', async (_req, res) => {
    try {
      const gameTypes = [
        {
          type: 'business-matcher',
          name: 'Business Matcher',
          description: 'Match businesses to their correct categories',
          difficulty: 'Easy',
          estimatedTime: '3-5 minutes',
          maxQuestions: 15
        },
        {
          type: 'price-guesser',
          name: 'Price Guesser',
          description: 'Guess the prices of local services',
          difficulty: 'Medium',
          estimatedTime: '5-8 minutes',
          maxQuestions: 10
        },
        {
          type: 'rating-predictor',
          name: 'Rating Predictor',
          description: 'Predict business ratings based on features',
          difficulty: 'Hard',
          estimatedTime: '6-10 minutes',
          maxQuestions: 8
        }
      ]

      res.json(gameTypes)
    } catch (error) {
      console.error('Error fetching game types:', error)
      res.status(500).json({ error: 'Failed to fetch game types' })
    }
  })

  return router
}