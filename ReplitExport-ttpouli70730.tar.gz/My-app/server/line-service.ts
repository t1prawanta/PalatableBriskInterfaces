import * as line from '@line/bot-sdk'
import * as crypto from 'crypto'
import { Business, ServiceCategory } from '../shared/schema.js'
import { 
  LineMessage, 
  LineNotificationType,
  LineSubscription 
} from '../shared/line-schema.js'

export interface ILineService {
  // Core messaging
  replyMessage(replyToken: string, messages: LineMessage[]): Promise<void>
  pushMessage(userId: string, messages: LineMessage[]): Promise<void>
  broadcastMessage(messages: LineMessage[]): Promise<void>
  
  // Signature verification
  verifySignature(body: string, signature: string): boolean
  
  // Business-specific messages
  sendBusinessNotification(userId: string, business: Business, type: LineNotificationType): Promise<void>
  sendBusinessCarousel(userId: string, businesses: Business[]): Promise<void>
  sendCategoryMenu(userId: string, categories: ServiceCategory[]): Promise<void>
  
  // Game integration
  sendGameResult(userId: string, score: number, gameType: string): Promise<void>
  sendGameInvite(userId: string, gameType: string): Promise<void>
  
  // Subscription management
  handleSubscription(userId: string, action: 'subscribe' | 'unsubscribe', types: LineNotificationType[]): Promise<void>
}

export class LineService implements ILineService {
  private client: line.messagingApi.MessagingApiClient
  private config: line.ClientConfig
  private subscriptions: Map<string, LineSubscription> = new Map()

  constructor(channelAccessToken: string, channelSecret: string) {
    this.config = { 
      channelSecret,
      channelAccessToken 
    }
    this.client = new line.messagingApi.MessagingApiClient({
      channelAccessToken
    })
  }

  verifySignature(body: string, signature: string): boolean {
    if (!this.config.channelSecret) return false
    
    const generatedSignature = crypto
      .createHmac('sha256', this.config.channelSecret)
      .update(body, 'utf8')
      .digest('base64')
    
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(generatedSignature)
    )
  }

  async replyMessage(replyToken: string, messages: LineMessage[]): Promise<void> {
    try {
      await this.client.replyMessage({
        replyToken,
        messages: messages as any[]
      })
    } catch (error) {
      console.error('LINE reply message error:', error)
      throw error
    }
  }

  async pushMessage(userId: string, messages: LineMessage[]): Promise<void> {
    try {
      await this.client.pushMessage({
        to: userId,
        messages: messages as any[]
      })
    } catch (error) {
      console.error('LINE push message error:', error)
      throw error
    }
  }

  async broadcastMessage(messages: LineMessage[]): Promise<void> {
    try {
      await this.client.broadcast({
        messages: messages as any[]
      })
    } catch (error) {
      console.error('LINE broadcast message error:', error)
      throw error
    }
  }

  async sendBusinessNotification(userId: string, business: Business, type: LineNotificationType): Promise<void> {
    let message: LineMessage

    switch (type) {
      case 'business_review':
        message = {
          type: 'flex',
          altText: `New review for ${business.name}`,
          contents: this.createBusinessReviewFlexMessage(business)
        }
        break

      case 'price_update':
        message = {
          type: 'template',
          altText: `Price update for ${business.name}`,
          template: {
            type: 'buttons',
            title: 'Price Update',
            text: `${business.name} has updated their pricing. Check it out!`,
            actions: [
              {
                type: 'uri',
                label: 'View Details',
                uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/business/${business.id}`
              },
              {
                type: 'message',
                label: 'More Info',
                text: `Tell me more about ${business.name}`
              }
            ]
          }
        }
        break

      case 'new_business':
        message = {
          type: 'template',
          altText: `New business: ${business.name}`,
          template: {
            type: 'buttons',
            title: 'New Business Alert',
            text: `${business.name} just joined LocalCompare! Discover their services.`,
            actions: [
              {
                type: 'uri',
                label: 'Explore',
                uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/business/${business.id}`
              },
              {
                type: 'postback',
                label: 'Save to Favorites',
                data: `action=favorite&businessId=${business.id}`
              }
            ]
          }
        }
        break

      default:
        message = {
          type: 'text',
          text: `Update from ${business.name}: Check out the latest information!`
        }
    }

    await this.pushMessage(userId, [message])
  }

  async sendBusinessCarousel(userId: string, businesses: Business[]): Promise<void> {
    const columns = businesses.slice(0, 10).map(business => ({
      title: business.name,
      text: business.description.en || Object.values(business.description)[0] || 'Local business',
      actions: [
        {
          type: 'uri' as const,
          label: 'View Details',
          uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/business/${business.id}`
        },
        {
          type: 'postback' as const,
          label: 'Get Info',
          data: `action=info&businessId=${business.id}`
        }
      ]
    }))

    const carouselMessage: LineMessage = {
      type: 'template',
      altText: 'Business recommendations',
      template: {
        type: 'carousel',
        columns
      }
    }

    await this.pushMessage(userId, [carouselMessage])
  }

  async sendCategoryMenu(userId: string, categories: ServiceCategory[]): Promise<void> {
    const text = 'Choose a category to explore local businesses:'
    const actions = categories.slice(0, 4).map(category => ({
      type: 'postback' as const,
      label: category.name.en || Object.values(category.name)[0],
      data: `action=category&categoryId=${category.id}`
    }))

    const menuMessage: LineMessage = {
      type: 'template',
      altText: 'Business categories',
      template: {
        type: 'buttons',
        text,
        actions
      }
    }

    await this.pushMessage(userId, [menuMessage])
  }

  async sendGameResult(userId: string, score: number, gameType: string): Promise<void> {
    const gameNames = {
      'business-matcher': 'Business Matcher',
      'price-guesser': 'Price Guesser',
      'rating-predictor': 'Rating Predictor'
    }

    const gameName = gameNames[gameType as keyof typeof gameNames] || gameType

    let encouragement = 'Great job!'
    if (score >= 1000) encouragement = 'Outstanding performance! 🏆'
    else if (score >= 500) encouragement = 'Well done! 🎉'
    else if (score >= 200) encouragement = 'Good effort! 👍'

    const message: LineMessage = {
      type: 'flex',
      altText: `Game result: ${score} points`,
      contents: this.createGameResultFlexMessage(gameName, score, encouragement)
    }

    await this.pushMessage(userId, [message])
  }

  async sendGameInvite(userId: string, gameType: string): Promise<void> {
    const gameNames = {
      'business-matcher': 'Business Matcher',
      'price-guesser': 'Price Guesser',
      'rating-predictor': 'Rating Predictor'
    }

    const gameName = gameNames[gameType as keyof typeof gameNames] || gameType

    const message: LineMessage = {
      type: 'template',
      altText: `Play ${gameName}`,
      template: {
        type: 'buttons',
        title: `🎮 ${gameName}`,
        text: 'Test your local business knowledge and compete with others!',
        actions: [
          {
            type: 'uri',
            label: 'Play Now',
            uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/games?type=${gameType}`
          },
          {
            type: 'uri',
            label: 'View Leaderboard',
            uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/games`
          }
        ]
      }
    }

    await this.pushMessage(userId, [message])
  }

  async handleSubscription(userId: string, action: 'subscribe' | 'unsubscribe', types: LineNotificationType[]): Promise<void> {
    // In a real implementation, this would update a database
    const subscription = this.subscriptions.get(userId) || {
      id: Math.random().toString(36),
      userId,
      lineUserId: userId,
      notificationTypes: [],
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    if (action === 'subscribe') {
      subscription.notificationTypes = Array.from(new Set([...subscription.notificationTypes, ...types]))
      subscription.isActive = true
    } else {
      subscription.notificationTypes = subscription.notificationTypes.filter(t => !types.includes(t))
      subscription.isActive = subscription.notificationTypes.length > 0
    }

    subscription.updatedAt = new Date().toISOString()
    this.subscriptions.set(userId, subscription)

    const message: LineMessage = {
      type: 'text',
      text: action === 'subscribe' 
        ? `✅ Successfully subscribed to ${types.join(', ')} notifications!`
        : `✅ Successfully unsubscribed from ${types.join(', ')} notifications!`
    }

    await this.pushMessage(userId, [message])
  }

  private createBusinessReviewFlexMessage(business: Business): any {
    return {
      type: 'bubble',
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: business.name,
            weight: 'bold',
            size: 'xl'
          },
          {
            type: 'text',
            text: `⭐ ${business.rating}/5 (${business.reviewCount} reviews)`,
            size: 'sm',
            color: '#666666'
          },
          {
            type: 'text',
            text: business.description.en || Object.values(business.description)[0] || '',
            wrap: true,
            margin: 'md'
          }
        ]
      },
      footer: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'button',
            action: {
              type: 'uri',
              label: 'View Business',
              uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/business/${business.id}`
            }
          }
        ]
      }
    }
  }

  private createGameResultFlexMessage(gameName: string, score: number, encouragement: string): any {
    return {
      type: 'bubble',
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'text',
            text: '🎮 Game Complete!',
            weight: 'bold',
            size: 'xl',
            align: 'center'
          },
          {
            type: 'text',
            text: gameName,
            size: 'md',
            align: 'center',
            margin: 'md'
          },
          {
            type: 'text',
            text: `${score} Points`,
            size: 'xxl',
            weight: 'bold',
            align: 'center',
            color: '#FF6B35',
            margin: 'lg'
          },
          {
            type: 'text',
            text: encouragement,
            align: 'center',
            margin: 'md'
          }
        ]
      },
      footer: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'button',
            action: {
              type: 'uri',
              label: 'Play Again',
              uri: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/games`
            }
          }
        ]
      }
    }
  }
}