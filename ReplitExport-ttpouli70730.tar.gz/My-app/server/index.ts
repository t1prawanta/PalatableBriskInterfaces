import express from 'express'
import cors from 'cors'
import { createRoutes } from './routes.js'
import { MemStorage } from './storage.js'
import { createGameRoutes } from './game-routes.js'
import { MemGameStorage } from './game-storage.js'
import { createLineRoutes } from './line-routes.js'
import { LineService } from './line-service.js'

const app = express()
const PORT = Number(process.env.PORT) || 3000

// Initialize storage
const storage = new MemStorage()

// Initialize game storage after business storage is ready
const initGameStorage = async () => {
  const businesses = await storage.getBusinesses()
  const categories = await storage.getCategories()
  return new MemGameStorage(businesses.businesses, categories)
}
const gameStorage = await initGameStorage()

// Initialize LINE service
const lineService = new LineService(
  process.env.LINE_CHANNEL_ACCESS_TOKEN || '',
  process.env.LINE_CHANNEL_SECRET || ''
)

// Middleware
app.use(cors())

// Raw body middleware for LINE webhook signature verification
app.use('/api/line/webhook', express.raw({ type: 'application/json' }))
app.use(express.json())

// Routes
app.use('/api', createRoutes(storage))
app.use('/api/games', createGameRoutes(gameStorage))
app.use('/api/line', createLineRoutes(lineService, storage))

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`)
  console.log(`Health check: http://localhost:${PORT}/health`)
  console.log(`API available at: http://localhost:${PORT}/api`)
})