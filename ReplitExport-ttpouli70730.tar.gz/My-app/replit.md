# Local Business Service Comparison Platform

## Overview
A comprehensive web application that helps customers compare local business services and pricing across different categories with intuitive search functionality and multi-language support for global visitors.

## Project Architecture

### Frontend (React + Vite)
- Modern React application with TypeScript
- Multi-language support with i18n
- Responsive design with Tailwind CSS and shadcn/ui
- Service comparison interface with filtering and sorting
- Search functionality with category-based filtering
- Customer reviews and ratings system

### Backend (Express + Node.js)
- RESTful API for business data management
- In-memory storage for development
- Service categories and business data management
- Multi-language content support

### Key Features
- **Service Comparison**: Side-by-side comparison of local businesses
- **Multi-language Support**: English, Spanish, French, German, Chinese, Japanese, Thai
- **Search & Filter**: Category-based search with price/rating filters
- **Responsive Design**: Mobile-first approach
- **Customer Reviews**: Rating and review system
- **Pricing Comparison**: Clear pricing display with comparison tools
- **Mini Games**: Interactive business knowledge games with scoring and leaderboards
  - Business Matcher: Match businesses to correct categories
  - Price Guesser: Guess service prices to learn local market rates
  - Rating Predictor: Predict business ratings based on features

## Data Model
- **Business**: Service providers with details, pricing, and contact info
- **Service Category**: Different types of services (restaurants, repairs, etc.)
- **Review**: Customer feedback and ratings
- **Language**: Multi-language content support
- **Game System**: Mini-games for business knowledge testing
  - Game Sessions: Track player progress and scores
  - Leaderboard: High scores and player rankings
  - Game Questions: Business matching, price guessing, rating prediction

## Technology Stack
- Frontend: React, TypeScript, Tailwind CSS, shadcn/ui, Wouter, TanStack Query
- Backend: Express.js, Node.js, LINE Bot SDK (@line/bot-sdk)
- Storage: In-memory (development)
- Internationalization: react-i18next
- External APIs: LINE Messaging API for notifications and social features

## User Preferences
- Clean, professional interface
- Multi-language support for global accessibility
- Intuitive comparison tools
- Mobile-responsive design
- Gradual feature development - implement core functionality first, then iterate

## Recent Changes
- Initial project setup with full-stack architecture
- Multi-language support implementation
- Service comparison interface design
- Search and filtering system
- Added interactive mini-games system:
  - Business Matcher game: Test knowledge of business categories
  - Price Guesser game: Learn about local service pricing
  - Game lobby with player statistics and leaderboards
  - Complete scoring system with time bonuses
  - Leaderboard with player rankings and performance metrics
- Implemented comprehensive LINE Platform integration:
  - LINE Bot SDK integration with webhook authentication
  - Business notification system via LINE messages
  - Game result sharing and social features
  - Rich message templates (carousels, buttons, flex messages)
  - Subscription management for different notification types
  - HMAC-SHA256 signature verification for webhook security

## Next Steps
- Implement business data management
- Add customer review system
- Enhance search functionality
- Test and refine LINE Platform integration
- Deploy to production

## Implementation Status
- ✅ Core platform architecture (React + Express + TypeScript)
- ✅ Multi-language support (i18n with 7 languages)
- ✅ Mini-games system (Business Matcher + Price Guesser)
- ✅ LINE Platform integration (Bot SDK + rich messaging)
- 🔄 Business data management (in progress)
- 🔄 Customer review system (planned)
- 🔄 Advanced search features (planned)