import { z } from 'zod'

// Game Types
export const GameTypeSchema = z.enum(['business-matcher', 'price-guesser', 'rating-predictor'])
export type GameType = z.infer<typeof GameTypeSchema>

// Business Matcher Game
export const BusinessMatcherQuestionSchema = z.object({
  id: z.string(),
  businessName: z.string(),
  description: z.string(),
  correctCategoryId: z.string(),
  options: z.array(z.object({
    categoryId: z.string(),
    categoryName: z.record(z.string(), z.string())
  }))
})

export type BusinessMatcherQuestion = z.infer<typeof BusinessMatcherQuestionSchema>

// Price Guesser Game
export const PriceGuesserQuestionSchema = z.object({
  id: z.string(),
  businessName: z.string(),
  serviceName: z.record(z.string(), z.string()),
  serviceDescription: z.string(),
  correctPrice: z.number(),
  currency: z.string(),
  priceRange: z.object({
    min: z.number(),
    max: z.number()
  }),
  difficulty: z.enum(['easy', 'medium', 'hard'])
})

export type PriceGuesserQuestion = z.infer<typeof PriceGuesserQuestionSchema>

// Rating Predictor Game
export const RatingPredictorQuestionSchema = z.object({
  id: z.string(),
  businessName: z.string(),
  category: z.string(),
  priceRange: z.enum(['$', '$$', '$$$', '$$$$']),
  reviewCount: z.number(),
  features: z.array(z.string()),
  correctRating: z.number(),
  options: z.array(z.number())
})

export type RatingPredictorQuestion = z.infer<typeof RatingPredictorQuestionSchema>

// Game Session
export const GameSessionSchema = z.object({
  id: z.string(),
  gameType: GameTypeSchema,
  playerName: z.string(),
  score: z.number(),
  totalQuestions: z.number(),
  currentQuestion: z.number(),
  timeSpent: z.number(), // in seconds
  startedAt: z.date(),
  completedAt: z.date().optional(),
  questions: z.array(z.union([
    BusinessMatcherQuestionSchema,
    PriceGuesserQuestionSchema,
    RatingPredictorQuestionSchema
  ])),
  answers: z.array(z.object({
    questionId: z.string(),
    playerAnswer: z.union([z.string(), z.number()]),
    correctAnswer: z.union([z.string(), z.number()]),
    isCorrect: z.boolean(),
    timeToAnswer: z.number() // in seconds
  }))
})

export type GameSession = z.infer<typeof GameSessionSchema>

// Leaderboard Entry
export const LeaderboardEntrySchema = z.object({
  id: z.string(),
  playerName: z.string(),
  gameType: GameTypeSchema,
  score: z.number(),
  totalQuestions: z.number(),
  accuracy: z.number(), // percentage
  averageTimePerQuestion: z.number(),
  completedAt: z.date(),
  difficulty: z.enum(['easy', 'medium', 'hard']).optional()
})

export type LeaderboardEntry = z.infer<typeof LeaderboardEntrySchema>

// Game Statistics
export const GameStatsSchema = z.object({
  totalGamesPlayed: z.number(),
  averageScore: z.number(),
  bestScore: z.number(),
  totalTimeSpent: z.number(),
  favoriteGameType: GameTypeSchema.optional(),
  accuracyByGameType: z.record(GameTypeSchema, z.number()),
  gamesPlayedByType: z.record(GameTypeSchema, z.number())
})

export type GameStats = z.infer<typeof GameStatsSchema>