import { z } from 'zod'

// Service Category Schema
export const ServiceCategorySchema = z.object({
  id: z.string(),
  name: z.record(z.string(), z.string()), // Multi-language support
  icon: z.string(),
  description: z.record(z.string(), z.string()), // Multi-language support
  createdAt: z.date().default(() => new Date()),
})

export type ServiceCategory = z.infer<typeof ServiceCategorySchema>
export const insertServiceCategorySchema = ServiceCategorySchema.omit({ id: true, createdAt: true })
export type InsertServiceCategory = z.infer<typeof insertServiceCategorySchema>

// Business Schema
export const BusinessSchema = z.object({
  id: z.string(),
  name: z.string(),
  categoryId: z.string(),
  description: z.record(z.string(), z.string()), // Multi-language support
  address: z.string(),
  phone: z.string(),
  email: z.string().email(),
  website: z.string().url().optional(),
  image: z.string().optional(),
  priceRange: z.enum(['$', '$$', '$$$', '$$$$']),
  rating: z.number().min(0).max(5).default(0),
  reviewCount: z.number().default(0),
  services: z.array(z.object({
    name: z.record(z.string(), z.string()), // Multi-language support
    price: z.number(),
    unit: z.string(), // e.g., "per hour", "per item", "per service"
    currency: z.string().default('USD'),
  })),
  coordinates: z.object({
    lat: z.number(),
    lng: z.number(),
  }).optional(),
  hours: z.object({
    monday: z.string().optional(),
    tuesday: z.string().optional(),
    wednesday: z.string().optional(),
    thursday: z.string().optional(),
    friday: z.string().optional(),
    saturday: z.string().optional(),
    sunday: z.string().optional(),
  }),
  featured: z.boolean().default(false),
  verified: z.boolean().default(false),
  createdAt: z.date().default(() => new Date()),
  updatedAt: z.date().default(() => new Date()),
})

export type Business = z.infer<typeof BusinessSchema>
export const insertBusinessSchema = BusinessSchema.omit({ id: true, createdAt: true, updatedAt: true })
export type InsertBusiness = z.infer<typeof insertBusinessSchema>

// Review Schema
export const ReviewSchema = z.object({
  id: z.string(),
  businessId: z.string(),
  customerName: z.string(),
  rating: z.number().min(1).max(5),
  comment: z.string(),
  serviceUsed: z.string(),
  date: z.date().default(() => new Date()),
  verified: z.boolean().default(false),
  helpful: z.number().default(0),
})

export type Review = z.infer<typeof ReviewSchema>
export const insertReviewSchema = ReviewSchema.omit({ id: true, date: true })
export type InsertReview = z.infer<typeof insertReviewSchema>

// Search and Filter Schemas
export const SearchFiltersSchema = z.object({
  query: z.string().optional(),
  categoryId: z.string().optional(),
  priceRange: z.array(z.enum(['$', '$$', '$$$', '$$$$'])).optional(),
  rating: z.number().min(0).max(5).optional(),
  sortBy: z.enum(['relevance', 'rating', 'price', 'distance', 'name']).default('relevance'),
  language: z.string().default('en'),
  location: z.object({
    lat: z.number(),
    lng: z.number(),
    radius: z.number().default(10), // km
  }).optional(),
})

export type SearchFilters = z.infer<typeof SearchFiltersSchema>

// API Response Schemas
export const BusinessListResponseSchema = z.object({
  businesses: z.array(BusinessSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  hasMore: z.boolean(),
})

export type BusinessListResponse = z.infer<typeof BusinessListResponseSchema>

// Language Support
export const SupportedLanguages = {
  en: 'English',
  es: 'Español',
  fr: 'Français',
  de: 'Deutsch',
  zh: '中文',
  ja: '日本語',
  th: 'ไทย',
} as const

export type SupportedLanguage = keyof typeof SupportedLanguages