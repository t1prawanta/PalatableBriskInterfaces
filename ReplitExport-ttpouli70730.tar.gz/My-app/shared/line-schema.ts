import { z } from 'zod'

// LINE Message Types
export const LineTextMessageSchema = z.object({
  type: z.literal('text'),
  text: z.string()
})

export const LineImageMessageSchema = z.object({
  type: z.literal('image'),
  originalContentUrl: z.string().url(),
  previewImageUrl: z.string().url()
})

export const LineFlexMessageSchema = z.object({
  type: z.literal('flex'),
  altText: z.string(),
  contents: z.any() // Flex container JSON
})

export const LineButtonsTemplateSchema = z.object({
  type: z.literal('template'),
  altText: z.string(),
  template: z.object({
    type: z.literal('buttons'),
    title: z.string().optional(),
    text: z.string(),
    actions: z.array(z.object({
      type: z.enum(['message', 'uri', 'postback']),
      label: z.string(),
      text: z.string().optional(),
      uri: z.string().url().optional(),
      data: z.string().optional()
    }))
  })
})

export const LineCarouselTemplateSchema = z.object({
  type: z.literal('template'),
  altText: z.string(),
  template: z.object({
    type: z.literal('carousel'),
    columns: z.array(z.object({
      title: z.string(),
      text: z.string(),
      actions: z.array(z.object({
        type: z.enum(['message', 'uri', 'postback']),
        label: z.string(),
        text: z.string().optional(),
        uri: z.string().url().optional(),
        data: z.string().optional()
      }))
    }))
  })
})

export const LineMessageSchema = z.union([
  LineTextMessageSchema,
  LineImageMessageSchema,
  LineFlexMessageSchema,
  LineButtonsTemplateSchema,
  LineCarouselTemplateSchema
])

export type LineMessage = z.infer<typeof LineMessageSchema>

// LINE Webhook Events
export const LineTextEventSchema = z.object({
  type: z.literal('message'),
  message: z.object({
    type: z.literal('text'),
    text: z.string()
  }),
  source: z.object({
    type: z.enum(['user', 'group', 'room']),
    userId: z.string().optional(),
    groupId: z.string().optional(),
    roomId: z.string().optional()
  }),
  replyToken: z.string(),
  timestamp: z.number()
})

export const LinePostbackEventSchema = z.object({
  type: z.literal('postback'),
  postback: z.object({
    data: z.string(),
    params: z.record(z.string(), z.string()).optional()
  }),
  source: z.object({
    type: z.enum(['user', 'group', 'room']),
    userId: z.string().optional(),
    groupId: z.string().optional(),
    roomId: z.string().optional()
  }),
  replyToken: z.string(),
  timestamp: z.number()
})

export const LineFollowEventSchema = z.object({
  type: z.literal('follow'),
  source: z.object({
    type: z.literal('user'),
    userId: z.string()
  }),
  replyToken: z.string(),
  timestamp: z.number()
})

export const LineWebhookEventSchema = z.union([
  LineTextEventSchema,
  LinePostbackEventSchema,
  LineFollowEventSchema
])

export type LineWebhookEvent = z.infer<typeof LineWebhookEventSchema>

// LINE Notification Types
export const LineNotificationTypeSchema = z.enum([
  'business_review',
  'price_update',
  'new_business',
  'game_achievement',
  'daily_deals'
])

export type LineNotificationType = z.infer<typeof LineNotificationTypeSchema>

// LINE Subscription
export const LineSubscriptionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  lineUserId: z.string(),
  notificationTypes: z.array(LineNotificationTypeSchema),
  categories: z.array(z.string()).optional(), // Category IDs
  location: z.object({
    lat: z.number(),
    lng: z.number(),
    radius: z.number() // in kilometers
  }).optional(),
  isActive: z.boolean(),
  createdAt: z.string(),
  updatedAt: z.string()
})

export type LineSubscription = z.infer<typeof LineSubscriptionSchema>

// LINE Rich Menu
export const LineRichMenuSchema = z.object({
  size: z.object({
    width: z.number(),
    height: z.number()
  }),
  selected: z.boolean(),
  name: z.string(),
  chatBarText: z.string(),
  areas: z.array(z.object({
    bounds: z.object({
      x: z.number(),
      y: z.number(),
      width: z.number(),
      height: z.number()
    }),
    action: z.object({
      type: z.enum(['message', 'uri', 'postback']),
      text: z.string().optional(),
      uri: z.string().url().optional(),
      data: z.string().optional()
    })
  }))
})

export type LineRichMenu = z.infer<typeof LineRichMenuSchema>